from __future__ import annotations

import argparse
import copy
import math
import multiprocessing as mp
import os
import pickle
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict, replace
from pathlib import Path
from typing import Dict, List, Tuple
from warnings import warn

if __name__ in {"__main__", "__mp_main__"}:
    for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                     "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[variable] = "1"

import numpy as np
from pyvrp import Client, Depot, ProblemData, VehicleType
from pyvrp._pyvrp import Solution, CostEvaluator, RandomNumberGenerator
from pyvrp.GeneticAlgorithm import GeneticAlgorithm
from pyvrp.PenaltyManager import PenaltyManager, PenaltyParams
from pyvrp.Population import Population
from pyvrp.ProgressPrinter import ProgressPrinter
from pyvrp.Result import Result
from pyvrp.Statistics import Statistics
from pyvrp.exceptions import PenaltyBoundWarning
from pyvrp.search import (
    NODE_OPERATORS, ROUTE_OPERATORS, LocalSearch, NeighbourhoodParams,
    compute_neighbours, SwapStar,
)
from pyvrp.stop import MaxRuntime
from pyvrp.stop.StoppingCriterion import StoppingCriterion


__copyright__ = "Copyright © 2026 the TSCHPEA contributors."
__paper_title__ = (
    "A Two Stage Cooperative Heterogeneous Parallel Evolutionary Algorithm for Large-Scale "
    "Bi-objective Vehicle Routing Problem With Time Windows Under Fleet-Size Preferences"
)
__paper_authors__ = (
    "Zhiwei Xu", "Pingshan Wu", "Kai Zhang", "Quanyu Zhang",
    "Yiran Huang", "Juanjuan He", "Miqing Li", "Javier Del Ser",
)
__third_party_notice__ = """Portions of the genetic search implementation derive from PyVRP.

MIT License

- Copyright (c) 2020, Thibaut Vidal (HGS-CVRP)
- Copyright (c) 2022, ORTEC (HGS-DIMACS)
- Copyright (c) since 2022, PyVRP contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

SCALE = 10000


class HeterogeneousPenaltyManager(PenaltyManager):

    @classmethod
    def init_for_paper(
        cls,
        data,
        params: PenaltyParams,
        distance_scale: float = 1.0,
    ):
        if not math.isfinite(distance_scale) or distance_scale <= 0:
            raise ValueError("distance_scale must be finite and positive")
        manager = cls(([20.0] * data.num_load_dimensions, 6.0, 1.0), params)
        manager._distance_scale = float(distance_scale)
        return manager

    def _make_cost_evaluator(self, multiplier: float = 1.0):
        loads, time_warp, distance = self.penalties()
        scale = getattr(self, "_distance_scale", 1.0)
        return CostEvaluator(
            [penalty * multiplier * scale for penalty in loads],
            time_warp * multiplier,
            distance * multiplier,
        )

    def cost_evaluator(self):
        return self._make_cost_evaluator()

    def booster_cost_evaluator(self):
        return self._make_cost_evaluator(self._params.repair_booster)

    def _compute(
        self,
        penalty: float,
        feas_percentage: float,
    ) -> float:
        p = self._params
        min_feasible = p.target_feasible - p.feas_tolerance
        max_feasible = p.target_feasible + p.feas_tolerance
        if feas_percentage < min_feasible:
            new_penalty = (
                penalty * p.penalty_increase
            )
            if new_penalty >= p.max_penalty:
                warn(
                    "Penalty has reached its upper bound.",
                    PenaltyBoundWarning,
                )
        elif feas_percentage > max_feasible:
            new_penalty = (
                penalty * p.penalty_decrease
            )
            if new_penalty <= p.min_penalty:
                warn(
                    "Penalty has reached its lower bound.",
                    PenaltyBoundWarning,
                )
        else:
            return penalty

        return float(np.clip(
            new_penalty,
            p.min_penalty,
            p.max_penalty,
        ))


def make_island_penalty_params(
    island_id: int,
    num_islands: int,
    design_npe: int |None = None,
) -> PenaltyParams:

    if num_islands < 1:
        raise ValueError("num_islands must be at least 1")

    if design_npe is None:
        design_npe = num_islands


    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} must equal "
            f"num_islands={num_islands}"
        )

    if not 0 <= island_id < num_islands:
        raise ValueError(
            f"island_id={island_id} must be in "
            f"[0, {num_islands - 1}]"
        )

    original = PenaltyParams(
        solutions_between_updates=50,
        target_feasible=0.43,
        feas_tolerance=0.05,
        penalty_increase=1.34,
        penalty_decrease=0.32,
    )
    lower_init = (
        original.target_feasible
        - original.feas_tolerance
    )
    upper_init = (
        original.target_feasible
        + original.feas_tolerance
    )

    delta_ro = (
        upper_init - lower_init
    ) / design_npe

    if design_npe == 1:
        position = 0.0
    else:
        position = (
            island_id / (design_npe - 1)
        )

    delta_inc = (
        original.penalty_increase
        - original.penalty_decrease
    ) / design_npe
    delta_dec = (
                        original.penalty_increase
                        - original.penalty_decrease
                ) / design_npe


    ro_adjustment = (
        position * delta_ro
    )
    increase_adjustment = (
        position * delta_inc
    )
    decrease_adjustment = (
        position * delta_dec
    )

    return replace(
        original,
        target_feasible=(
            original.target_feasible
            + ro_adjustment
        ),
        penalty_increase=(
            original.penalty_increase
            + increase_adjustment
        ),
        penalty_decrease=(
            original.penalty_decrease
            + decrease_adjustment
        ),
    )


class MABParentSelection:
    def __init__(
            self, num_arms: int = 5, c: float = 1.0, initial_temperature: float = 1.0, cooling_rate: float = 0.9999,
            custom_vehicle_weight: float = 5.0,
            custom_distance_weight: float = 1.0):
        self.num_arms = num_arms
        self.c = c
        self.pulls = {}
        self.rewards = {}
        self.total_pulls = 0
        self.temperature = initial_temperature
        self.cooling_rate = cooling_rate
        self.best_routes_seen = float('inf')
        self.no_improvement_count = 0
        self.custom_vehicle_weight = custom_vehicle_weight
        self.custom_distance_weight = custom_distance_weight

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:

        self.temperature *= self.cooling_rate

        population._update_fitness(cost_evaluator)

        first_parent = self._select_one_parent(population, rng)

        second_parent = first_parent
        max_attempts = 10
        attempt = 0

        while id(second_parent) == id(first_parent) and attempt < max_attempts:
            second_parent = self._select_one_parent(population, rng)
            attempt += 1

        return first_parent, second_parent

    def _select_one_parent(self, population: Population, rng: RandomNumberGenerator) -> Solution:
        pop_size = len(population)
        if pop_size == 0:
            raise ValueError("Cannot select parents from an empty population")

        indices = [rng.randint(pop_size) for _ in range(min(self.num_arms, pop_size))]

        best_solution = None
        best_ucb = float('-inf')

        for idx in indices:
            if idx < population.num_feasible():
                solution = population._feas[idx].solution
            else:
                solution = population._infeas[idx - population.num_feasible()].solution

            solution_id = id(solution)

            if solution_id not in self.pulls:
                self.pulls[solution_id] = 0
                self.rewards[solution_id] = 0.0

            if self.pulls[solution_id] == 0:
                ucb = float('inf')
            else:
                exploitation = self.rewards[solution_id] / self.pulls[solution_id]

                effective_c = self.c * self.temperature
                exploration = effective_c * math.sqrt(math.log(self.total_pulls + 1) / self.pulls[solution_id])

                ucb = exploitation + exploration

            if ucb > best_ucb:
                best_ucb = ucb
                best_solution = solution

        if best_solution:
            solution_id = id(best_solution)
            self.pulls[solution_id] += 1
            self.total_pulls += 1

        return best_solution

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        solution_id = id(solution)

        if solution_id not in self.rewards:
            return

        parent_routes = len(solution.routes())
        parent_distance = solution.distance()
        parent_cost = cost_evaluator.penalised_cost(solution)
        parent_feasible = solution.is_feasible()

        offspring_routes = len(offspring.routes())
        offspring_distance = offspring.distance()
        offspring_cost = cost_evaluator.penalised_cost(offspring)
        offspring_feasible = offspring.is_feasible()

        if offspring_feasible and offspring_routes < self.best_routes_seen:
            self.best_routes_seen = offspring_routes
            self.no_improvement_count = 0
        else:
            self.no_improvement_count += 1

        reward = 0.0

        vehicle_weight = self.custom_vehicle_weight
        if self.no_improvement_count > 10000:
            vehicle_weight *= 0.8

        distance_weight = self.custom_distance_weight

        if offspring_routes < parent_routes:
            routes_improvement = (parent_routes - offspring_routes) / parent_routes
            reward += vehicle_weight * (1.0 + routes_improvement * 2)

            if offspring_feasible and offspring_routes == self.best_routes_seen:
                reward += 2.0
        elif offspring_routes == parent_routes:
            if offspring_distance < parent_distance:
                distance_improvement = (parent_distance - offspring_distance) / parent_distance
                if distance_improvement > 0.1:
                    reward += distance_weight * (0.8 + distance_improvement)
                else:
                    reward += distance_weight * (0.5 + distance_improvement)
            else:
                if offspring_cost < parent_cost:
                    cost_improvement = (parent_cost - offspring_cost) / parent_cost
                    reward += 0.2 * cost_improvement
                else:
                    reward += 0.05
        else:
            if offspring_cost < parent_cost:
                cost_improvement = (parent_cost - offspring_cost) / parent_cost
                if cost_improvement > 0.2:
                    reward += 0.15 * cost_improvement
                else:
                    reward += 0.05 * cost_improvement
            else:
                reward += 0.01

        if offspring_feasible and not parent_feasible:
            reward += 1.5
        elif not offspring_feasible and parent_feasible:
            reward -= 1.0

        if offspring_feasible:
            routes_gap = offspring_routes - self.best_routes_seen
            if routes_gap <= 2:
                reward += 0.2 * (3 - routes_gap)

        self.rewards[solution_id] += reward


class TournamentSelection:

    def __init__(self, tournament_size: int = 5):
        self.tournament_size = tournament_size

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:
        population._update_fitness(cost_evaluator)

        pop_size = len(population)
        num_feas = population.num_feasible()
        num_infeas = pop_size - num_feas

        if num_feas == 0:
            first_parent = self._select_one_parent(population, rng)
            second_parent = first_parent
            max_attempts = 10
            attempt = 0
            while id(second_parent) == id(first_parent) and attempt < max_attempts:
                second_parent = self._select_one_parent(population, rng)
                attempt += 1
            return first_parent, second_parent

        if num_feas == 1:
            first_parent = population._feas[0].solution

            if num_infeas > 0:
                num_to_sample_infeas = min(self.tournament_size, num_infeas)
                infeas_competitors = []
                for _ in range(num_to_sample_infeas):
                    idx = rng.randint(num_infeas)
                    solution = population._infeas[idx].solution
                    fitness = population._infeas[idx].fitness
                    infeas_competitors.append((solution, fitness))
                second_parent, _ = min(infeas_competitors, key=lambda x: x[1])
            else:
                second_parent = self._select_one_parent(population, rng)

            return first_parent, second_parent

        first_parent = self._select_one_parent(population, rng)
        second_parent = first_parent
        max_attempts = 10
        attempt = 0
        while id(second_parent) == id(first_parent) and attempt < max_attempts:
            second_parent = self._select_one_parent(population, rng)
            attempt += 1
        return first_parent, second_parent

    def _select_one_parent(self, population: Population, rng: RandomNumberGenerator) -> Solution:
        pop_size = len(population)
        if pop_size == 0:
            raise ValueError("Cannot select parents from an empty population")

        num_feas = population.num_feasible()
        num_infeas = pop_size - num_feas
        num_to_sample = min(self.tournament_size, pop_size)

        num_from_feas = min(num_feas, num_to_sample)
        num_from_infeas = num_to_sample - num_from_feas

        competitors = []

        for _ in range(num_from_feas):
            idx = rng.randint(num_feas)
            solution = population._feas[idx].solution
            fitness = population._feas[idx].fitness
            competitors.append((solution, fitness))

        for _ in range(num_from_infeas):
            idx = rng.randint(num_infeas)
            solution = population._infeas[idx].solution
            fitness = population._infeas[idx].fitness
            competitors.append((solution, fitness))

        best_solution, best_fitness = min(competitors, key=lambda x: x[1])
        return best_solution

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        pass


class HybridSelection:

    def __init__(
            self,
            switch_interval: int = 100,
            tournament_size: int = 5,
            mab_num_arms: int = 8,
            mab_c: float = 1.2,
            initial_temperature: float = 1.5,
            cooling_rate: float = 0.9998,
            custom_vehicle_weight: float = 5.0,
            custom_distance_weight: float = 0.0
    ):
        self.mab_selector = MABParentSelection(
            num_arms=mab_num_arms,
            c=mab_c,
            initial_temperature=initial_temperature,
            cooling_rate=cooling_rate,
            custom_vehicle_weight=custom_vehicle_weight,
            custom_distance_weight=custom_distance_weight
        )
        self.tournament_selector = TournamentSelection(tournament_size=tournament_size)

        self.switch_interval = switch_interval
        self.iterations = 0
        self.current_strategy = "mab"

        self.mab_performance = []
        self.tournament_performance = []
        self.strategy_history = []

        self.last_mab_best = None
        self.last_tournament_best = None

        self.current_best_cost = float('inf')
        self.iterations_without_improvement = 0

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:
        self.iterations += 1

        current_best_cost = self._get_best_cost(population, cost_evaluator)

        if current_best_cost < self.current_best_cost:
            self.current_best_cost = current_best_cost
            self.iterations_without_improvement = 0
        else:
            self.iterations_without_improvement += 1

        if self.iterations % self.switch_interval == 0:
            self._evaluate_and_switch_strategy(population, cost_evaluator)

        if self.current_strategy == "mab":
            return self.mab_selector.select(population, rng, cost_evaluator)
        else:
            return self.tournament_selector.select(population, rng, cost_evaluator)

    def _get_best_cost(self, population: Population, cost_evaluator: CostEvaluator) -> float:
        best_cost = float('inf')

        for i in range(population.num_feasible()):
            sol = population._feas[i].solution
            cost = cost_evaluator.cost(sol)
            if cost < best_cost:
                best_cost = cost

        if best_cost == float('inf') and len(population) > 0:
            for i in range(population.num_feasible(), len(population)):
                idx = i - population.num_feasible()
                sol = population._infeas[idx].solution
                cost = cost_evaluator.penalised_cost(sol)
                if cost < best_cost:
                    best_cost = cost

        return best_cost

    def _get_best_solution(self, population: Population, cost_evaluator: CostEvaluator) -> Tuple[Solution, float, int]:
        best_solution = None
        best_cost = float('inf')
        best_routes = float('inf')

        for i in range(population.num_feasible()):
            sol = population._feas[i].solution
            cost = cost_evaluator.cost(sol)
            if cost < best_cost:
                best_cost = cost
                best_solution = sol
                best_routes = len(sol.routes())

        if best_solution is None and len(population) > population.num_feasible():
            for i in range(population.num_feasible(), len(population)):
                idx = i - population.num_feasible()
                sol = population._infeas[idx].solution
                cost = cost_evaluator.penalised_cost(sol)
                if cost < best_cost:
                    best_cost = cost
                    best_solution = sol
                    best_routes = float('inf')

        return best_solution, best_cost, best_routes

    def _evaluate_and_switch_strategy(self, population: Population, cost_evaluator: CostEvaluator):
        best_solution, best_cost, best_routes = self._get_best_solution(population, cost_evaluator)

        if best_solution is None:
            return

        performance = {
            'cost': best_cost,
            'routes': best_routes,
            'iterations_without_improvement': self.iterations_without_improvement
        }

        if self.current_strategy == "mab":
            self.mab_performance.append(performance)
            self.last_mab_best = performance
        else:
            self.tournament_performance.append(performance)
            self.last_tournament_best = performance

        should_switch = False

        if self.last_mab_best and self.last_tournament_best:
            if self.last_mab_best['routes'] < self.last_tournament_best['routes']:
                should_switch = (self.current_strategy != "mab")
            elif self.last_tournament_best['routes'] < self.last_mab_best['routes']:
                should_switch = (self.current_strategy != "tournament")
            else:
                if self.last_mab_best['cost'] < self.last_tournament_best['cost']:
                    should_switch = (self.current_strategy != "mab")
                elif self.last_tournament_best['cost'] < self.last_mab_best['cost']:
                    should_switch = (self.current_strategy != "tournament")
                else:
                    if self.iterations_without_improvement > self.switch_interval // 2:
                        should_switch = True
        else:
            if not self.last_mab_best:
                should_switch = (self.current_strategy != "mab")
            elif not self.last_tournament_best:
                should_switch = (self.current_strategy != "tournament")

        if self.iterations_without_improvement > self.switch_interval * 2:
            should_switch = True

        if should_switch:
            self.current_strategy = "tournament" if self.current_strategy == "mab" else "mab"
            self.iterations_without_improvement = 0

        self.strategy_history.append(self.current_strategy)

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        if self.current_strategy == "mab":
            self.mab_selector.update_reward(solution, offspring, cost_evaluator)


class MABGeneticAlgorithm(GeneticAlgorithm):

    def __init__(self, *args, hybrid_params=None, **kwargs):
        super().__init__(*args, **kwargs)

        if hybrid_params is None:
            hybrid_params = {}

        self._selector = HybridSelection(
            switch_interval=hybrid_params.get('switch_interval', 100),
            tournament_size=hybrid_params.get('tournament_size', 5),
            mab_num_arms=hybrid_params.get('num_arms', 8),
            mab_c=hybrid_params.get('c', 1.2),
            initial_temperature=hybrid_params.get('initial_temperature', 1.5),
            cooling_rate=hybrid_params.get('cooling_rate', 0.9998),
            custom_vehicle_weight=hybrid_params.get('custom_vehicle_weight', 5.0),
            custom_distance_weight=hybrid_params.get('custom_distance_weight', 0.0)
        )

    def run(
            self,
            stop: StoppingCriterion,
            collect_stats: bool = True,
            display: bool = False,
            display_interval: float = 5.0,
    ):
        try:
            print_progress = ProgressPrinter(display, display_interval)
        except TypeError:
            print_progress = ProgressPrinter(display)

        print_progress.start(self._data)

        start = time.perf_counter()
        stats = Statistics(collect_stats=collect_stats)
        iters = 0
        iters_no_improvement = 1

        for sol in self._initial_solutions:
            self._pop.add(sol, self._cost_evaluator)

        if hasattr(stop, 'set_population_reference'):
            stop.set_population_reference(self._pop, self._cost_evaluator)

        restart_threshold = 20000
        try:
            restart_threshold = getattr(self._params, "num_iters_no_improvement", restart_threshold)
        except (AttributeError, TypeError):
            print("Using the default restart threshold of 20000")

        while not stop(self._cost_evaluator.cost(self._best)):
            iters += 1

            if iters_no_improvement == restart_threshold:
                print_progress.restart()

                iters_no_improvement = 1
                self._pop.clear()

                for sol in self._initial_solutions:
                    self._pop.add(sol, self._cost_evaluator)

            curr_best = self._cost_evaluator.cost(self._best)

            parents = self._selector.select(self._pop, self._rng, self._cost_evaluator)
            offspring = self._crossover(
                parents, self._data, self._cost_evaluator, self._rng
            )

            self._improve_offspring(offspring)

            for parent in parents:
                self._selector.update_reward(parent, offspring, self._cost_evaluator)

            new_best = self._cost_evaluator.cost(self._best)

            if new_best < curr_best:
                iters_no_improvement = 1
            else:
                iters_no_improvement += 1

            stats.collect_from(self._pop, self._cost_evaluator)
            print_progress.iteration(stats)

        end = time.perf_counter() - start
        res = Result(self._best, stats, iters, end)

        print_progress.end(res)

        return res


class IslandGeneticAlgorithm(MABGeneticAlgorithm):

    def __init__(self, *args, island_id=None, global_best=None,
                 global_best_lock=None, is_distance_optimization=False,
                 num_islands=None, runtime_limit=None,
                 shared_best_feasible=None, call_deadline=None,
                 overall_start_time=None, overall_runtime_limit=None,
                 iteration_callback=None,
                 egks_early_receive_interval=500,
                 egks_late_receive_interval=500,
                 egks_early_send_interval=None,
                 egks_late_send_interval=None,
                 egks_early_receive_fraction=1 / 3,
                 egks_wallclock_fraction=2 / 3,
                 egks_wallclock_interval_seconds=10.0,
                 egks_last_wall_slot=None, **kwargs):
        super().__init__(*args, **kwargs)
        if num_islands is None:
            raise ValueError("The actual num_islands is required")
        if runtime_limit is not None and runtime_limit <= 0:
            raise ValueError("runtime_limit must be positive")
        if overall_runtime_limit is not None and overall_runtime_limit <= 0:
            raise ValueError("overall_runtime_limit must be positive")
        if shared_best_feasible is not None and global_best_lock is None:
            raise ValueError("The shared feasible record requires global_best_lock")
        self.island_id = island_id
        self.global_best = global_best
        self.global_best_lock = global_best_lock
        self.shared_best_feasible = shared_best_feasible
        self.is_distance_optimization = is_distance_optimization
        self.num_islands = num_islands
        self.runtime_limit = runtime_limit
        self.call_deadline = call_deadline
        self.overall_start_time = overall_start_time
        self.overall_runtime_limit = overall_runtime_limit
        self.start_time = None
        self.migration_counter = 0
        self._current_iteration = 0
        self.completed_iterations = 0
        self.iteration_callback = iteration_callback
        self.successful_migrations = 0
        if any(not isinstance(value, int) or value <= 0 for value in
               (egks_early_receive_interval, egks_late_receive_interval)):
            raise ValueError("EGKS receive intervals must be positive integers")
        if not 0 <= egks_early_receive_fraction <= 1:
            raise ValueError("EGKS early fraction must be in [0, 1]")
        self.egks_early_receive_interval = egks_early_receive_interval
        self.egks_late_receive_interval = egks_late_receive_interval
        self.egks_early_receive_fraction = egks_early_receive_fraction
        send_intervals = (egks_early_send_interval, egks_late_send_interval)
        if any(value is not None for value in send_intervals):
            if any(not isinstance(value, int) or value <= 0 for value in send_intervals):
                raise ValueError("Both EGKS send intervals must be positive integers")
        self.egks_early_send_interval = egks_early_send_interval
        self.egks_late_send_interval = egks_late_send_interval
        if not egks_early_receive_fraction < egks_wallclock_fraction < 1:
            raise ValueError("EGKS wall-clock fraction must follow the iteration switch and precede 1")
        if (not math.isfinite(egks_wallclock_interval_seconds)
                or egks_wallclock_interval_seconds <= 0):
            raise ValueError("EGKS wall-clock interval must be finite and positive")
        if egks_last_wall_slot is not None and len(egks_last_wall_slot) != num_islands:
            raise ValueError("EGKS slot state must contain one entry per PE")
        self.egks_wallclock_fraction = egks_wallclock_fraction
        self.egks_wallclock_interval_seconds = float(egks_wallclock_interval_seconds)
        self.egks_last_wall_slot = egks_last_wall_slot
        self._last_wall_slot = -1
        self.egks_activity = {}
        self.egks_events = []
        self.egks_check_events = []
        self.egks_timing = {}
        self._egks_active_check = None
        self.stagnation_counter = 0
        self.last_best_cost = float('inf')
        self.iteration_history = []
        self._last_record_nv = None
        self._last_record_dist = None
        self._last_record_elapsed = None
        self.local_best_solution = None

    @staticmethod
    def _lex_key(solution):
        return len(solution.routes()), solution.distance()

    def _eligible(self, solution):
        if solution is None:
            return False
        routes = solution.routes()
        if len(routes) > self._data.num_vehicles:
            return False
        visits = [client for route in routes for client in route.visits()]
        expected = range(self._data.num_depots,
                         self._data.num_depots + self._data.num_clients)
        return len(visits) == self._data.num_clients and set(visits) == set(expected)

    def _sharing_key(self, solution, evaluator=None):
        if self.is_distance_optimization:
            return self._lex_key(solution)
        if evaluator is None:
            evaluator = self._cost_evaluator
        violation = evaluator.tw_penalty(solution.time_warp())
        violation += sum(
            evaluator.load_penalty(excess, 0, dimension)
            for dimension, excess in enumerate(solution.excess_load())
        )
        return (violation,)

    def _sharing_candidate(self, evaluator=None):
        if evaluator is None:
            evaluator = self._cost_evaluator
        candidates = (
            sol for sol in self._pop
            if self._eligible(sol)
            and (not self.is_distance_optimization or sol.is_feasible())
        )
        return min(candidates,
                   key=lambda solution: self._sharing_key(solution, evaluator),
                   default=None)

    def _deadline_reached(self):
        return (self.call_deadline is not None
                and time.perf_counter() >= self.call_deadline)

    def _feasibility_reached(self):
        if self.is_distance_optimization:
            return False
        if self.shared_best_feasible is None:
            return self.local_best_solution is not None
        with self.global_best_lock:
            return self.shared_best_feasible.get("routes") is not None

    def _should_stop(self, stop=None):
        if self._deadline_reached() or self._feasibility_reached():
            return True
        return stop is not None and stop(self._cost_evaluator.cost(self._best))

    def _solution_record(self, solution):
        return {
            "routes": [list(route.visits()) for route in solution.routes()],
            "num_vehicles": len(solution.routes()),
            "distance": solution.distance(),
            "owner_id": self.island_id,
            "timestamp": time.perf_counter(),
            "num_iterations": self._current_iteration,
            "completed_local_iterations": self.completed_iterations,
        }

    def _consider_feasible(self, solution):
        if (self._deadline_reached() or not solution.is_feasible()
                or not self._eligible(solution)):
            return
        if (self.local_best_solution is None
                or self._lex_key(solution) < self._lex_key(self.local_best_solution)):
            self.local_best_solution = Solution(
                self._data, [list(route.visits()) for route in solution.routes()]
            )
            self._best = self.local_best_solution
        if self.shared_best_feasible is None:
            return
        with self.global_best_lock:
            if self._deadline_reached():
                return
            incumbent = self.shared_best_feasible
            key = (incumbent.get("num_vehicles", float("inf")),
                   incumbent.get("distance", float("inf")))
            if incumbent.get("routes") is None or self._lex_key(solution) < key:
                incumbent.update(self._solution_record(solution))

    def _register_solution(self, solution):
        if self._deadline_reached():
            return False
        self._pop.add(solution, self._cost_evaluator)
        self._pm.register(solution)
        self._consider_feasible(solution)
        return True

    def _improve_offspring(self, solution, stop=None):
        if self._should_stop():
            return False
        solution = self._search(solution, self._cost_evaluator)
        if self._deadline_reached():
            return False
        self._register_solution(solution)
        if self._should_stop():
            return True
        if (not solution.is_feasible()
                and self._rng.rand() < self._params.repair_probability):
            repaired = self._search(solution, self._pm.booster_cost_evaluator())
            if not self._deadline_reached() and repaired.is_feasible():
                self._register_solution(repaired)
        return not self._deadline_reached()

    def _record_history(self, iteration, force=False):
        solution = self.local_best_solution
        if solution is None:
            return
        vehicles, distance = self._lex_key(solution)
        previous = (self._last_record_nv, self._last_record_dist)
        if not force and previous == (vehicles, distance):
            return
        elapsed = time.perf_counter() - self.start_time
        self.iteration_history.append([
            self.island_id if self.island_id is not None else -1,
            iteration, elapsed, vehicles, distance,
        ])
        self._last_record_nv, self._last_record_dist = vehicles, distance
        self._last_record_elapsed = elapsed

    def run(self, stop, collect_stats=True, display=False, display_interval=5.0):
        try:
            print_progress = ProgressPrinter(display, display_interval)
        except TypeError:
            print_progress = ProgressPrinter(display)
        print_progress.start(self._data)
        self.start_time = time.perf_counter()
        stats = Statistics(collect_stats=collect_stats)
        iters = 0
        self._current_iteration = 0
        self.completed_iterations = 0
        iters_no_improvement = 1

        for solution in self._initial_solutions:
            if self._deadline_reached():
                break
            self._pop.add(solution, self._cost_evaluator)
            self._consider_feasible(solution)
        self._record_history(0)
        if self.iteration_callback is not None and not self._deadline_reached():
            self.iteration_callback(self, 0)
        evaluator = self._cost_evaluator
        candidate = self._sharing_candidate(evaluator)
        if candidate is not None and not self._deadline_reached():
            self._write_global_best(candidate, evaluator)
        if hasattr(stop, 'set_population_reference'):
            stop.set_population_reference(self._pop, self._cost_evaluator)
        restart_threshold = getattr(
            self._params, "nb_iter_no_improvement",
            getattr(self._params, "num_iters_no_improvement", 20000),
        )
        tournament_selector = TournamentSelection(tournament_size=2)

        while not self._should_stop(stop):
            iters += 1
            self._current_iteration = iters
            self.migration_counter += 1
            if iters_no_improvement == restart_threshold:
                print_progress.restart()
                iters_no_improvement = 1
                self._pop.clear()
                for solution in self._initial_solutions:
                    self._pop.add(solution, self._cost_evaluator)
            before = (self._lex_key(self.local_best_solution)
                      if self.local_best_solution is not None else (math.inf, math.inf))
            self._update_stagnation_status(self._cost_evaluator.cost(self._best))
            parents = tournament_selector.select(self._pop, self._rng, self._cost_evaluator)
            offspring = self._crossover(parents, self._data, self._cost_evaluator, self._rng)
            completed = self._improve_offspring(offspring, stop)
            after = (self._lex_key(self.local_best_solution)
                     if self.local_best_solution is not None else (math.inf, math.inf))
            iters_no_improvement = 1 if after < before else iters_no_improvement + 1
            if not self._should_stop():
                self._communicate(iters)
            if completed and not self._deadline_reached():
                self.completed_iterations = iters
                if self.iteration_callback is not None:
                    self.iteration_callback(self, iters)
            self._record_history(iters)
            stats.collect_from(self._pop, self._cost_evaluator)
            print_progress.iteration(stats)

        if self.local_best_solution is not None:
            self._best = self.local_best_solution
            if not self.iteration_history or self.iteration_history[-1][1] != iters:
                self._record_history(iters, force=True)
        result = Result(self._best, stats, self.completed_iterations,
                        time.perf_counter() - self.start_time)
        print_progress.end(result)
        return result

    def _normalized_time(self):
        if self.runtime_limit is None or self.start_time is None:
            return 0.0
        start = (self.call_deadline - self.runtime_limit
                 if self.call_deadline is not None else self.start_time)
        return min(1.0, max(0.0, (time.perf_counter() - start) / self.runtime_limit))

    def _sharing_threshold(self):
        if self.overall_start_time is not None and self.overall_runtime_limit is not None:
            fraction = (time.perf_counter() - self.overall_start_time) / self.overall_runtime_limit
            fraction = min(1.0, max(0.0, fraction))
        else:
            fraction = self._normalized_time()
        return 0.05 * (0.01 / 0.05) ** fraction

    def _egks_clock(self, now=None):
        if now is None:
            now = time.perf_counter()
        if self.overall_start_time is not None and self.overall_runtime_limit is not None:
            return now - self.overall_start_time, self.overall_runtime_limit
        if self.start_time is None or self.runtime_limit is None:
            return 0.0, math.inf
        start = (self.call_deadline - self.runtime_limit
                 if self.call_deadline is not None else self.start_time)
        return now - start, self.runtime_limit

    def _egks_uses_wallclock(self, now=None):
        elapsed, budget = self._egks_clock(now)
        return elapsed >= budget * self.egks_wallclock_fraction

    def _communication_plan(self, iters, now=None):
        elapsed, budget = self._egks_clock(now)
        early = elapsed < budget * self.egks_early_receive_fraction
        if elapsed >= budget:
            return None
        if elapsed < budget * self.egks_wallclock_fraction:
            send = iters % self._send_interval(early) == 0
            receive_period = (self.egks_early_receive_interval if early
                              else self.egks_late_receive_interval)
            receive = iters % receive_period == 0
            if not send and not receive:
                return None
            return {"send": send, "receive": receive, "early": early,
                    "clock": "iterations", "phase": "early" if early else "middle",
                    "scheduled_time_s": None, "slot": None}
        interval = self.egks_wallclock_interval_seconds
        phase_offset = self.island_id * interval / self.num_islands
        first_slot_time = budget * self.egks_wallclock_fraction + phase_offset
        if elapsed < first_slot_time:
            return None
        slot = math.floor((elapsed - first_slot_time) / interval)
        previous = (self.egks_last_wall_slot[self.island_id]
                    if self.egks_last_wall_slot is not None else self._last_wall_slot)
        if slot <= previous:
            return None
        if self.egks_last_wall_slot is not None:
            self.egks_last_wall_slot[self.island_id] = slot
        self._last_wall_slot = slot
        return {"send": True, "receive": True, "early": False,
                "clock": "wallclock", "phase": "wallclock",
                "scheduled_time_s": first_slot_time + slot * interval,
                "slot": slot}

    def _communicate(self, iters):
        if self.global_best is None or self.global_best_lock is None or self._should_stop():
            return
        plan = self._communication_plan(iters)
        if plan is None:
            return
        for operation in ("send", "receive"):
            if not plan[operation]:
                continue
            start = time.perf_counter()
            elapsed, _ = self._egks_clock(start)
            event = {"mode": "DS" if self.is_distance_optimization else "FS",
                     "pe_id": self.island_id, "operation": operation,
                     "clock": plan["clock"], "phase": plan["phase"],
                     "scheduled_time_s": plan["scheduled_time_s"], "slot": plan["slot"],
                     "wall_time_s": elapsed, "local_iteration": iters,
                     "lock_wait_s": 0.0, "lock_held_s": 0.0}
            count_key = "send_checks" if operation == "send" else "receive_checks"
            before = self.egks_activity.get(count_key, 0)
            self._egks_active_check = event
            try:
                if operation == "send":
                    self._maybe_update_global_best(iters, due=True, early=plan["early"])
                else:
                    self._maybe_inject_global_best(iters, due=True, early=plan["early"],
                                                   clock=plan["clock"])
            finally:
                self._egks_active_check = None
                duration = time.perf_counter() - start
                if self.egks_activity.get(count_key, 0) > before:
                    event["elapsed_s"] = duration
                    self.egks_check_events.append(event)
                    key = operation + "_checks_timed"
                    self.egks_timing[key] = self.egks_timing.get(key, 0) + 1
                    key = operation + "_seconds"
                    self.egks_timing[key] = self.egks_timing.get(key, 0.0) + duration
                    key = operation + "_max_seconds"
                    self.egks_timing[key] = max(self.egks_timing.get(key, 0.0), duration)

    @contextmanager
    def _egks_lock(self, operation):
        start = time.perf_counter()
        self.global_best_lock.acquire()
        acquired = time.perf_counter()
        try:
            yield
        finally:
            released = time.perf_counter()
            self.global_best_lock.release()
            wait, held = acquired - start, released - acquired
            prefix = operation if self._egks_active_check is not None else "initial_" + operation
            for suffix, value in (("_lock_wait_seconds", wait), ("_lock_held_seconds", held),
                                  ("_lock_acquisitions", 1)):
                key = prefix + suffix
                self.egks_timing[key] = self.egks_timing.get(key, 0) + value
            if self._egks_active_check is not None:
                self._egks_active_check["lock_wait_s"] += wait
                self._egks_active_check["lock_held_s"] += held

    def _egks_is_early(self):
        if self.overall_start_time is not None and self.overall_runtime_limit is not None:
            return (time.perf_counter() - self.overall_start_time
                    < self.overall_runtime_limit * self.egks_early_receive_fraction)
        return self._normalized_time() < self.egks_early_receive_fraction

    def _receive_interval(self):
        return (self.egks_early_receive_interval if self._egks_is_early()
                else self.egks_late_receive_interval)

    def _send_interval(self, early=None):
        if self.egks_early_send_interval is None:
            return 200 if self._normalized_time() < 0.5 else 500
        if early is None:
            early = self._egks_is_early()
        return (self.egks_early_send_interval if early
                else self.egks_late_send_interval)

    def _egks_count(self, name, early=None):
        if early is None:
            early = self._egks_is_early()
        for key in (name, ("early_" if early else "late_") + name):
            self.egks_activity[key] = self.egks_activity.get(key, 0) + 1

    def _maybe_update_global_best(self, iters, due=None, early=None):
        if self.global_best is None or self.global_best_lock is None:
            return
        if early is None:
            early = self._egks_is_early()
        period = self._send_interval(early)
        if due is None:
            due = iters % period == 0
        if not due or self._should_stop():
            return
        self._egks_count("send_checks", early)
        evaluator = self._cost_evaluator
        candidate = self._sharing_candidate(evaluator)
        if candidate is not None:
            self._write_global_best(candidate, evaluator)

    def _write_global_best(self, candidate, evaluator=None):
        if self.global_best is None or self.global_best_lock is None:
            return
        if not self._eligible(candidate):
            return
        if self.is_distance_optimization and not candidate.is_feasible():
            return
        if evaluator is None:
            evaluator = self._cost_evaluator
        with self._egks_lock("send"):
            if self._deadline_reached():
                return
            elite = self.global_best
            empty = elite.get("routes") is None
            if self.is_distance_optimization:
                fleet, distance = self._lex_key(candidate)
                old_fleet = elite.get("num_vehicles", math.inf)
                old_distance = elite.get("distance", math.inf)
                better = empty or fleet < old_fleet
                if fleet == old_fleet and 0 < old_distance < math.inf:
                    delta = (old_distance - distance) / old_distance
                    if self._egks_uses_wallclock():
                        threshold = None
                        better = distance < old_distance
                    else:
                        threshold = self._sharing_threshold()
                        better = delta >= threshold
                        if 0 < delta < threshold:
                            self._egks_count("reject_threshold")
                    if self._egks_active_check is not None:
                        self._egks_active_check.update({
                            "relative_improvement": delta, "threshold": threshold,
                            "threshold_rejected": threshold is not None and 0 < delta < threshold,
                        })
            else:
                better = empty
                if not empty:
                    incumbent = Solution(self._data, copy.deepcopy(elite["routes"]))
                    better = (self._sharing_key(candidate, evaluator)
                              < self._sharing_key(incumbent, evaluator))
            if better:
                elite.update(self._solution_record(candidate))
                self._egks_count("elite_writes")
                if self._current_iteration == 0:
                    self._egks_count("initial_elite_writes")

    def _maybe_inject_global_best(self, iters, due=None, early=None, clock="iterations"):
        if self.global_best is None or self.global_best_lock is None:
            return
        if early is None:
            early = self._egks_is_early()
        period = (self.egks_early_receive_interval if early
                  else self.egks_late_receive_interval)
        if due is None:
            due = iters % period == 0
        if not due or self._should_stop():
            return
        self._egks_count("receive_checks", early)
        evaluator = self._cost_evaluator
        local = self._sharing_candidate(evaluator)
        with self._egks_lock("receive"):
            if self.global_best.get("routes") is None:
                self._egks_count("reject_empty", early)
                return
            if self.global_best.get("owner_id", -1) == self.island_id:
                self._egks_count("reject_own", early)
                return
            owner = self.global_best.get("owner_id", -1)
            timestamp = self.global_best.get("timestamp")
            routes = copy.deepcopy(self.global_best["routes"])
            migrated = Solution(self._data, routes)
            if not self._eligible(migrated):
                self._egks_count("reject_ineligible", early)
                return
            if self.is_distance_optimization and not migrated.is_feasible():
                self._egks_count("reject_infeasible_ds", early)
                return
            incoming_key = self._sharing_key(migrated, evaluator)
            local_key = self._sharing_key(local, evaluator) if local is not None else None
            if (local is not None
                    and incoming_key >= local_key):
                self._egks_count("reject_not_better", early)
                return
        if self._should_stop():
            self._egks_count("reject_stopped", early)
            return
        if self._register_solution(migrated):
            self.successful_migrations += 1
            self._egks_count("accepted", early)
            now = time.perf_counter()
            self.egks_events.append({
                "mode": "DS" if self.is_distance_optimization else "FS",
                "wall_time_s": now - (self.overall_start_time or self.start_time),
                "local_iteration": iters,
                "receive_interval": period if clock == "iterations" else None,
                "receive_interval_seconds": (self.egks_wallclock_interval_seconds
                                             if clock == "wallclock" else None),
                "communication_clock": clock,
                "early": early, "recipient_pe": self.island_id,
                "donor_pe": owner,
                "elite_age_s": now - timestamp if timestamp is not None else None,
                "local_key_before": local_key, "incoming_key": incoming_key,
                "incoming_fs": len(migrated.routes()),
                "incoming_distance_scaled": migrated.distance(),
                "incoming_feasible": migrated.is_feasible(),
            })
        else:
            self._egks_count("reject_stopped", early)

    def _update_stagnation_status(self, current_cost):
        if current_cost < self.last_best_cost:
            self.stagnation_counter = 0
            self.last_best_cost = current_cost
        else:
            self.stagnation_counter += 1


class DiverseSearchConfigGenerator:

    PYVRP_SWAP_STAR_TOLERANCE = 0.05

    @staticmethod
    def get_island_search_config(island_id, data=None, num_islands=None,
                                 population_size=50, alpha_min=1.0,
                                 alpha_max=2.0):

        if num_islands is None:
            raise ValueError(
                "The actual num_islands is required"
            )
        if num_islands < 1 or not 0 <= island_id < num_islands:
            raise ValueError("island_id must be in [0, num_islands)")
        if population_size < 1:
            raise ValueError("population_size must be positive")
        if (not math.isfinite(alpha_min) or not math.isfinite(alpha_max)
                or not 0 < alpha_min <= alpha_max):
            raise ValueError("Require finite 0 < alpha_min <= alpha_max")
        if data is not None:
            V = data.num_locations - data.num_depots
            num_depots = int(data.num_depots)
        else:
            V = 1000
            num_depots = 1

        M = V

        N = population_size
        ND = num_islands
        id_val = island_id % ND
        d = id_val + 1

        log_pop = math.log(N + 1)
        log_nd = math.log(ND + 1)
        sqrt_m_log_ratio = math.sqrt(M * log_pop / log_nd)
        ns_min = math.ceil(alpha_min * sqrt_m_log_ratio)
        ns_max = math.ceil(alpha_max * sqrt_m_log_ratio)
        denom = max(1, ND - 1)
        NSd_cont = ns_min + (d - 1) / denom * (ns_max - ns_min)
        M_id = math.floor(NSd_cont)
        M_id = max(3, min(150, M_id))

        ln_m = math.log(max(2.0, float(M)))
        ln_1_plus_n = math.log(1 + N)
        weight_wait_time = ln_m / ln_1_plus_n * (d / ND)
        warp_num = max(1.0, float(ND - d + 1))
        weight_time_warp = ln_m / ln_1_plus_n * (warp_num / ND)

        weight_wait_time = max(0.001, min(5.0, weight_wait_time))
        weight_time_warp = max(0.01, min(15.0, weight_time_warp))

        symmetric_proximity = (id_val % 5 == 4) or (id_val % 3 == 0)
        symmetric_neighbours = False

        neighbourhood_config = {
            'weight_wait_time': weight_wait_time,
            'weight_time_warp': weight_time_warp,
            'num_neighbours': M_id,
            'symmetric_proximity': symmetric_proximity,
            'symmetric_neighbours': symmetric_neighbours,
        }

        return {
            'operator_policy': 'pyvrp_default',
            'alpha_min': float(alpha_min),
            'alpha_max': float(alpha_max),
            'neighbourhood_params': NeighbourhoodParams(**neighbourhood_config),
            'node_operators': [operator.__name__ for operator in NODE_OPERATORS],
            'route_operators': [operator.__name__ for operator in ROUTE_OPERATORS],
            'swap_star_tolerance': DiverseSearchConfigGenerator.PYVRP_SWAP_STAR_TOLERANCE,
            'strategy_description': (
                f"NS_d(M={M_id},NSmin={ns_min},NSmax={ns_max},NSd_cont={NSd_cont:.3f}) "
                f"w_wait={weight_wait_time:.3f} w_warp={weight_time_warp:.3f} "
                "PyVRP default operators; Swap*=0.05"
            ),
        }

    @staticmethod
    def create_diverse_local_search(data, rng, island_id, num_islands=None,
                                   population_size=50, alpha_min=1.0,
                                   alpha_max=2.0,
                                   return_configuration=False):

        if num_islands is None:
            raise ValueError(
                "The actual num_islands is required"
            )

        search_config = DiverseSearchConfigGenerator.get_island_search_config(
            island_id, 
            data=data, 
            num_islands=num_islands, 
            population_size=population_size,
            alpha_min=alpha_min,
            alpha_max=alpha_max,
        )

        neighbours = compute_neighbours(data, search_config['neighbourhood_params'])
        ls = LocalSearch(data, rng, neighbours)

        for operator in NODE_OPERATORS:
            ls.add_node_operator(operator(data))
        for operator in ROUTE_OPERATORS:
            if operator.__name__ == 'SwapStar':
                ls.add_route_operator(SwapStar(
                    data, overlap_tolerance=search_config['swap_star_tolerance'],
                ))
            else:
                ls.add_route_operator(operator(data))

        if return_configuration:
            configuration = {
                'mode': 'heterogeneous',
                'operator_policy': search_config['operator_policy'],
                'heterogeneous_dimensions': ['neighbourhood_scale', 'neighbourhood_construction'],
                'alpha_min': search_config['alpha_min'],
                'alpha_max': search_config['alpha_max'],
                'neighbourhood': asdict(search_config['neighbourhood_params']),
                'node_operators': list(search_config['node_operators']),
                'route_operators': list(search_config['route_operators']),
                'swap_star_tolerance': search_config['swap_star_tolerance'],
                'neighbour_degree': DiverseSearchConfigGenerator.neighbour_degree(
                    data, neighbours),
            }
            return ls, configuration
        return ls

    @staticmethod
    def neighbour_degree(data, neighbours):
        degrees = [len(neighbours[idx]) for idx in
                   range(data.num_depots, data.num_locations)]
        return {
            'min': min(degrees, default=0),
            'max': max(degrees, default=0),
            'mean': sum(degrees) / len(degrees) if degrees else 0.0,
        }


class DiverseInitialSolutionGenerator:

    @staticmethod
    def _context(data):
        import numpy as np
        if data.num_depots != 1 or data.num_load_dimensions != 1:
            raise ValueError("DPPI requires one depot and one load dimension")
        vehicle, clients = data.vehicle_type(0), data.clients()
        depot = data.location(0)
        return {
            'n': data.num_clients,
            'distance': np.asarray(data.distance_matrix(0)),
            'duration': np.asarray(data.duration_matrix(0)),
            'early': np.array([0] + [c.tw_early for c in clients], dtype=np.int64),
            'late': np.array([0] + [c.tw_late for c in clients], dtype=np.int64),
            'service': np.array([0] + [c.service_duration for c in clients], dtype=np.int64),
            'demand': np.array([0] + [c.delivery[0] for c in clients], dtype=np.int64),
            'start_time': max(int(vehicle.tw_early), int(depot.tw_early)),
            'depot_late': min(int(vehicle.tw_late), int(depot.tw_late)),
            'shift_duration': int(vehicle.shift_duration),
        }

    @staticmethod
    def _insert_remaining(routes, remaining, distance):
        import numpy as np
        if not remaining:
            return
        if not routes:
            raise ValueError("No route exists for residual customer insertion")
        previous, following, route_ids, positions = [], [], [], []
        for rid, route in enumerate(routes):
            extended = [0, *route, 0]
            for pos in range(len(route) + 1):
                previous.append(extended[pos])
                following.append(extended[pos + 1])
                route_ids.append(rid)
                positions.append(pos)
        previous, following, route_ids, positions = [
            np.asarray(values, dtype=np.int64)
            for values in (previous, following, route_ids, positions)
        ]
        for cid in remaining:
            increments = (distance[previous, cid] + distance[cid, following]
                          - distance[previous, following])
            edge = int(np.argmin(increments))
            rid, pos = int(route_ids[edge]), int(positions[edge])
            old_next = int(following[edge])
            routes[rid].insert(pos, int(cid))
            positions[(route_ids == rid) & (positions > pos)] += 1
            following[edge] = cid
            previous = np.insert(previous, edge + 1, cid)
            following = np.insert(following, edge + 1, old_next)
            route_ids = np.insert(route_ids, edge + 1, rid)
            positions = np.insert(positions, edge + 1, pos + 1)

    @staticmethod
    def _construct(data, vehicle_capacity, max_routes, context,
                   ordering=None, strategy=None, distance_scale=1.0):
        import numpy as np
        if max_routes < 1 or distance_scale <= 0:
            raise ValueError("Fleet limit and distance scale must be positive")
        n = context['n']
        remaining = np.ones(n + 1, dtype=bool)
        remaining[0] = False
        distance, duration = context['distance'], context['duration']
        early, late = context['early'], context['late']
        service, demand = context['service'], context['demand']
        if ordering is not None:
            ordering = np.asarray(ordering, dtype=np.int64)
            if len(ordering) != n or set(ordering.tolist()) != set(range(1, n + 1)):
                raise ValueError("Customer ordering must be a permutation")
        routes = []
        while remaining.any() and len(routes) < max_routes:
            route = []
            current, load = 0, 0
            current_time = context['start_time']
            while True:
                ids = (np.flatnonzero(remaining) if ordering is None
                       else ordering[remaining[ordering]])
                if not len(ids):
                    break
                arrival = current_time + duration[current, ids]
                finish = np.maximum(arrival, early[ids]) + service[ids]
                return_time = finish + duration[ids, 0]
                admissible = ((load + demand[ids] <= vehicle_capacity)
                              & (arrival <= late[ids])
                              & (return_time <= context['depot_late'])
                              & (return_time - context['start_time'] <= context['shift_duration']))
                choices = np.flatnonzero(admissible)
                if not len(choices):
                    break
                if ordering is not None:
                    chosen = int(choices[0])
                else:
                    feasible_ids = ids[choices]
                    if strategy == 'earliest_due':
                        scores = late[feasible_ids]
                    elif strategy == 'largest_demand':
                        scores = -demand[feasible_ids]
                    elif strategy == 'nearest':
                        scores = distance[current, feasible_ids]
                    elif strategy == 'distance_urgency':
                        leg = distance[current, feasible_ids]
                        slack = np.maximum(float(distance_scale), late[feasible_ids] - arrival[choices])
                        scores = np.full(len(leg), np.inf, dtype=float)
                        np.divide(slack, leg, out=scores, where=leg > 0)
                    else:
                        raise ValueError(f"Unknown greedy strategy: {strategy}")
                    chosen = int(choices[int(np.argmin(scores))])
                cid = int(ids[chosen])
                route.append(cid)
                remaining[cid] = False
                load += int(demand[cid])
                current_time = int(finish[chosen])
                current = cid
            if not route:
                break
            routes.append(route)
        DiverseInitialSolutionGenerator._insert_remaining(
            routes, np.flatnonzero(remaining).tolist(), distance,
        )
        return Solution(data, routes)


    @staticmethod
    def construct_routes_from_order(data, rng, ordering, vehicle_capacity, max_routes):
        return DiverseInitialSolutionGenerator._construct(
            data, vehicle_capacity, max_routes,
            DiverseInitialSolutionGenerator._context(data), ordering=ordering,
        )

    @staticmethod
    def generate_greedy_solution(data, rng, strategy, vehicle_capacity, max_routes,
                                 distance_scale=1.0):
        return DiverseInitialSolutionGenerator._construct(
            data, vehicle_capacity, max_routes,
            DiverseInitialSolutionGenerator._context(data),
            strategy=strategy, distance_scale=distance_scale,
        )

    @staticmethod
    def build_random_order(data, rng):
        clients = list(range(1, len(data.clients()) + 1))
        temp_list = clients[:]
        for i in range(len(temp_list) - 1, 0, -1):
            j = rng.randint(i + 1)
            temp_list[i], temp_list[j] = temp_list[j], temp_list[i]
        return temp_list

    @staticmethod
    def build_sweep_order(data, rng):
        clients = list(range(data.num_depots, data.num_locations))
        if not clients:
            return []

        depot = data.location(0)
        angles = []

        for cid in clients:
            loc = data.location(cid)
            angle = math.atan2(loc.y - depot.y, loc.x - depot.x)
            angles.append((angle, cid))

        angles.sort()
        start_idx = rng.randint(len(angles))
        ordered = [angles[(start_idx + i) % len(angles)][1] for i in range(len(angles))]

        return ordered

    @staticmethod
    def build_cluster_order(data, rng):
        import numpy as np
        n = data.num_clients
        if not n:
            return []
        k = min(data.num_vehicles, n)
        generator = np.random.default_rng(int(rng.randint(2 ** 31 - 1)))
        points = np.array([(data.location(cid).x, data.location(cid).y)
                           for cid in range(1, n + 1)], dtype=float)
        centers = points[generator.choice(n, size=k, replace=False)].copy()
        previous_labels = None
        for _ in range(50):
            squared = ((points[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
            labels = squared.argmin(axis=1)
            if previous_labels is not None and np.array_equal(labels, previous_labels):
                break
            previous_labels = labels.copy()
            counts = np.bincount(labels, minlength=k)
            occupied = counts > 0
            for coordinate in range(2):
                totals = np.bincount(labels, weights=points[:, coordinate], minlength=k)
                centers[occupied, coordinate] = totals[occupied] / counts[occupied]
            empty = np.flatnonzero(~occupied)
            if len(empty):
                farthest = np.argsort(-squared[np.arange(n), labels], kind='stable')
                centers[empty] = points[farthest[:len(empty)]]
        squared = ((points[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        labels = squared.argmin(axis=1)
        ordering = []
        for cluster in generator.permutation(k):
            members = np.flatnonzero(labels == cluster) + 1
            ordering.extend(generator.permutation(members).tolist())
        return ordering

    @staticmethod
    def generate_random_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        ordering = DiverseInitialSolutionGenerator.build_random_order(data, rng)
        return DiverseInitialSolutionGenerator.construct_routes_from_order(
            data, rng, ordering, vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_nearest_neighbor_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        return DiverseInitialSolutionGenerator.generate_greedy_solution(
            data, rng, "nearest", vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_earliest_due_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        return DiverseInitialSolutionGenerator.generate_greedy_solution(
            data, rng, "earliest_due", vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_largest_demand_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        return DiverseInitialSolutionGenerator.generate_greedy_solution(
            data, rng, "largest_demand", vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_distance_urgency_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        return DiverseInitialSolutionGenerator.generate_greedy_solution(
            data, rng, "distance_urgency", vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_sweep_init_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        ordering = DiverseInitialSolutionGenerator.build_sweep_order(data, rng)
        return DiverseInitialSolutionGenerator.construct_routes_from_order(
            data, rng, ordering, vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_cluster_init_solution(data, rng):
        vehicle_capacity = data.vehicle_type(0).capacity[0]
        max_routes = data.num_vehicles
        ordering = DiverseInitialSolutionGenerator.build_cluster_order(data, rng)
        return DiverseInitialSolutionGenerator.construct_routes_from_order(
            data, rng, ordering, vehicle_capacity, max_routes
        )

    @staticmethod
    def generate_sweep_solution(data, rng):
        return DiverseInitialSolutionGenerator.generate_sweep_init_solution(data, rng)

    @staticmethod
    def generate_clustered_solution(data, rng):
        return DiverseInitialSolutionGenerator.generate_cluster_init_solution(data, rng)

    @staticmethod
    def generate_diverse_initial_solutions(data, rng, population_size, island_id=None,
                                           distance_scale=1.0):
        if population_size < 4:
            raise ValueError("Algorithm 3 requires population_size >= 4")
        methods = ['earliest_due', 'largest_demand', 'nearest', 'distance_urgency']
        ordering_methods = ['cluster', 'sweep', 'random']
        counts = {name: 0 for name in methods + ordering_methods}
        context = DiverseInitialSolutionGenerator._context(data)
        capacity, max_routes = data.vehicle_type(0).capacity[0], data.num_vehicles
        solutions = []
        for i in range(population_size):
            strategy = methods[i] if i < 4 else ordering_methods[rng.randint(3)]
            try:
                if i < 4:
                    sol = DiverseInitialSolutionGenerator._construct(
                        data, capacity, max_routes, context,
                        strategy=strategy, distance_scale=distance_scale,
                    )
                else:
                    builder = {
                        'cluster': DiverseInitialSolutionGenerator.build_cluster_order,
                        'sweep': DiverseInitialSolutionGenerator.build_sweep_order,
                        'random': DiverseInitialSolutionGenerator.build_random_order,
                    }[strategy]
                    sol = DiverseInitialSolutionGenerator._construct(
                        data, capacity, max_routes, context, ordering=builder(data, rng),
                    )
                visits = [client for route in sol.routes() for client in route.visits()]
                if len(visits) != data.num_clients or set(visits) != set(range(1, data.num_clients + 1)):
                    raise ValueError("Initial solution does not cover each client exactly once")
                if len(sol.routes()) > max_routes:
                    raise ValueError("Initial solution exceeds the fleet-size limit")
                solutions.append(sol)
                counts[strategy] += 1
            except Exception as exc:
                raise RuntimeError(f"DPPI strategy {strategy!r} failed for individual {i}") from exc
        DiverseInitialSolutionGenerator.last_generation_counts = counts
        DiverseInitialSolutionGenerator.last_generation_unique_routes = len({
            tuple(tuple(route.visits()) for route in sol.routes()) for sol in solutions
        })
        return solutions

    @staticmethod
    def _get_method_weights_for_island(island_id):
        weight_patterns = [
            [0.7, 0.1, 0.1, 0.05, 0.03, 0.02],
            [0.3, 0.4, 0.1, 0.1, 0.05, 0.05],
            [0.2, 0.1, 0.5, 0.1, 0.05, 0.05],
            [0.2, 0.1, 0.1, 0.4, 0.1, 0.1],
            [0.2, 0.1, 0.1, 0.1, 0.4, 0.1],
            [0.2, 0.1, 0.1, 0.1, 0.1, 0.4],
            [0.3, 0.2, 0.2, 0.1, 0.1, 0.1],
            [0.15, 0.15, 0.15, 0.15, 0.2, 0.2],
            [0.4, 0.15, 0.15, 0.1, 0.1, 0.1],
            [0.1, 0.3, 0.3, 0.1, 0.1, 0.1],
        ]

        pattern_idx = island_id % len(weight_patterns)
        return weight_patterns[pattern_idx]

    @staticmethod
    def _weighted_choice(weights, rng):
        total = sum(weights)
        r = rng.rand() * total

        cumulative = 0
        for i, weight in enumerate(weights):
            cumulative += weight
            if r <= cumulative:
                return i

        return len(weights) - 1


def create_island_genetic_algorithm(data,
                                    seed=42,
                                    hybrid_params=None,
                                    custom_neighbourhood_params=None,
                                    custom_swap_star_params=0.05,
                                    island_id=None,
                                    global_best=None,
                                    global_best_lock=None,
                                    is_distance_optimization=False,
                                    num_islands=None,
                                    population_size=50,
                                    runtime_limit=None,
                                    penalty_config=None,
                                    shared_best_feasible=None,
                                    call_deadline=None,
                                    overall_start_time=None,
                                    overall_runtime_limit=None,
                                    distance_scale=1.0,
                                    use_dppi=True,
                                    use_hch=True,
                                    use_hpls=True,
                                    use_egks=True,
                                    alpha_min=1.0,
                                    alpha_max=2.0,
                                    iteration_callback=None,
                                    egks_early_receive_interval=500,
                                    egks_late_receive_interval=500,
                                    egks_early_send_interval=None,
                                    egks_late_send_interval=None,
                                    egks_early_receive_fraction=1 / 3,
                                    egks_wallclock_fraction=2 / 3,
                                    egks_wallclock_interval_seconds=10.0,
                                    egks_last_wall_slot=None,
                                    ):
    from pyvrp import PopulationParams
    from pyvrp.solve import SolveParams
    from pyvrp.GeneticAlgorithm import GeneticAlgorithmParams
    from pyvrp.Population import Population
    from pyvrp._pyvrp import RandomNumberGenerator, Solution
    from pyvrp.diversity import broken_pairs_distance as bpd
    from pyvrp.crossover import selective_route_exchange as srex
    from pyvrp.crossover import ordered_crossover as ox
    from pyvrp.search import SwapStar
    from pyvrp.search import NeighbourhoodParams

    genetic_params = GeneticAlgorithmParams()

    if num_islands is None:
        raise ValueError(
            "The actual num_islands is required"
        )
    if island_id is None or not 0 <= island_id < num_islands:
        raise ValueError("island_id must be in [0, num_islands)")

    if penalty_config is None:
        penalty_config = {
            'design_npe': num_islands,
        }

    design_npe = penalty_config['design_npe']

    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} must equal "
            f"num_islands={num_islands}"
        )

    if use_hch:
        penalty_params = make_island_penalty_params(
            island_id=island_id,
            num_islands=num_islands,
            **penalty_config,
        )
    else:
        from pyvrp.PenaltyManager import PenaltyParams
        penalty_params = PenaltyParams(
            solutions_between_updates=50,
            target_feasible=0.43,
            feas_tolerance=0.05,
            penalty_increase=1.34,
            penalty_decrease=0.32,
        )

    params = SolveParams(
        genetic=genetic_params,
        penalty=penalty_params,
        neighbourhood=custom_neighbourhood_params or NeighbourhoodParams(),
        population=PopulationParams(min_pop_size=population_size),
    )

    rng = RandomNumberGenerator(seed=seed)
    from pyvrp.search import compute_neighbours, LocalSearch, NODE_OPERATORS, ROUTE_OPERATORS

    if island_id is not None and use_hpls:
        ls, search_configuration = DiverseSearchConfigGenerator.create_diverse_local_search(
            data, rng, island_id, 
            num_islands=num_islands, 
            population_size=population_size,
            alpha_min=alpha_min,
            alpha_max=alpha_max,
            return_configuration=True,
        )
    else:
        neighbours = compute_neighbours(data, params.neighbourhood)
        ls = LocalSearch(data, rng, neighbours)
        search_configuration = {
            'mode': 'homogeneous',
            'operator_policy': 'pyvrp_default',
            'heterogeneous_dimensions': [],
            'neighbourhood': asdict(params.neighbourhood),
            'node_operators': [],
            'route_operators': [],
            'swap_star_tolerance': custom_swap_star_params,
            'neighbour_degree': DiverseSearchConfigGenerator.neighbour_degree(
                data, neighbours),
        }

        for node_op in NODE_OPERATORS:
            try:
                if hasattr(node_op, 'supports') and node_op.supports(data):
                    ls.add_node_operator(node_op(data))
                else:
                    ls.add_node_operator(node_op(data))
                search_configuration['node_operators'].append(node_op.__name__)
            except Exception as e:
                print(f"Failed to add node operator {node_op.__name__}: {e}")

        for route_op in ROUTE_OPERATORS:
            try:
                if route_op.__name__ == 'SwapStar':
                    swap_star_instance = SwapStar(data, overlap_tolerance=custom_swap_star_params)
                    ls.add_route_operator(swap_star_instance)
                else:
                    if hasattr(route_op, 'supports') and route_op.supports(data):
                        ls.add_route_operator(route_op(data))
                    else:
                        ls.add_route_operator(route_op(data))
                search_configuration['route_operators'].append(route_op.__name__)
            except Exception as e:
                print(f"Failed to add route operator {route_op.__name__}: {e}")

    pm = HeterogeneousPenaltyManager.init_for_paper(
        data, params.penalty, distance_scale=distance_scale,
    )
    pop = Population(bpd, params.population)

    if use_dppi:
        init = DiverseInitialSolutionGenerator.generate_diverse_initial_solutions(
            data, rng, population_size, island_id, distance_scale=distance_scale,
        )
    else:
        init = [Solution.make_random(data, rng) for _ in range(population_size)]

    if is_distance_optimization and global_best is not None:
        if global_best_lock is None:
            raise ValueError("A shared elite requires global_best_lock")
        with global_best_lock:
            seed_routes = copy.deepcopy(global_best.get("routes"))
        if seed_routes is not None:
            seed_solution = Solution(data, seed_routes)
            if not seed_solution.is_feasible():
                raise ValueError("The Stage-1 seed must be feasible in DS-mode")
            init.append(seed_solution)

    crossover = srex if data.num_vehicles > 1 else ox

    algo = IslandGeneticAlgorithm(
        data, pm, rng, pop, ls, crossover, init,
        params=genetic_params,
        hybrid_params=hybrid_params,
        island_id=island_id,
        global_best=global_best if use_egks else None,
        global_best_lock=global_best_lock,
        is_distance_optimization=is_distance_optimization,
        num_islands=num_islands,
        runtime_limit=runtime_limit,
        shared_best_feasible=shared_best_feasible,
        call_deadline=call_deadline,
        overall_start_time=overall_start_time,
        overall_runtime_limit=overall_runtime_limit,
        iteration_callback=iteration_callback,
        egks_early_receive_interval=egks_early_receive_interval,
        egks_late_receive_interval=egks_late_receive_interval,
        egks_early_send_interval=egks_early_send_interval,
        egks_late_send_interval=egks_late_send_interval,
        egks_early_receive_fraction=egks_early_receive_fraction,
        egks_wallclock_fraction=egks_wallclock_fraction,
        egks_wallclock_interval_seconds=egks_wallclock_interval_seconds,
        egks_last_wall_slot=egks_last_wall_slot,
    )

    algo.search_configuration = search_configuration
    algo.penalty_configuration = {
        'mode': 'heterogeneous' if use_hch else 'homogeneous',
        'initial_capacity_penalty': 20.0,
        'initial_time_warp_penalty': 6.0,
        'distance_scale': float(distance_scale),
        'parameters': asdict(params.penalty),
    }
    algo.initialization_counts = (
        dict(DiverseInitialSolutionGenerator.last_generation_counts)
        if use_dppi else {"random": population_size}
    )
    algo.initialization_unique_routes = (
        DiverseInitialSolutionGenerator.last_generation_unique_routes
        if use_dppi else len({tuple(tuple(route.visits()) for route in sol.routes())
                             for sol in init})
    )
    return algo, rng


class SharedRecord:

    def __init__(self, ctx):
        self._buffer = ctx.RawArray("B", 262144)
        self._size = ctx.RawValue("i", 0)
        self.update({})

    def snapshot(self):
        return pickle.loads(bytes(self._buffer[:self._size.value]))

    def get(self, key, default=None):
        return self.snapshot().get(key, default)

    def __getitem__(self, key):
        return self.snapshot()[key]

    def update(self, value):
        previous = self.snapshot() if self._size.value else {}
        previous.update(value)
        data = pickle.dumps(previous, protocol=5)
        if len(data) > len(self._buffer):
            raise RuntimeError("Shared record exceeds its allocated capacity")
        self._buffer[:len(data)] = data
        self._size.value = len(data)


def read_instance(path):
    rows, vehicle, in_customer = [], None, False
    for line in Path(path).read_text(encoding="utf8").splitlines():
        if line.strip().upper().startswith("CUSTOMER"):
            in_customer = True
            continue
        try:
            values = [int(x) for x in line.split()]
        except ValueError:
            continue
        if len(values) == 2 and not in_customer:
            vehicle = values
        elif len(values) == 7 and in_customer:
            rows.append(values)
    if vehicle is None or len(rows) != 1001 or [r[0] for r in rows] != list(range(1001)):
        raise ValueError(f"Invalid 1000-customer instance: {path}")
    return vehicle, np.asarray(rows, dtype=np.int64)


def build_data(vehicle, rows, conservative_durations=True):
    xy = rows[:, 1:3].astype(float)
    delta = xy[:, None, :] - xy[None, :, :]
    distances = np.sqrt(np.sum(delta * delta, axis=2))
    matrix = np.ascontiguousarray(distances * SCALE, dtype=np.int64)
    durations = (np.ascontiguousarray(np.ceil(distances * SCALE), dtype=np.int64)
                 if conservative_durations else matrix)
    clients = [Client(x=float(r[1]), y=float(r[2]), delivery=[int(r[3])],
                      service_duration=int(r[6]) * SCALE,
                      tw_early=int(r[4]) * SCALE, tw_late=int(r[5]) * SCALE)
               for r in rows[1:]]
    depot = Depot(float(rows[0, 1]), float(rows[0, 2]),
                  tw_early=int(rows[0, 4]) * SCALE, tw_late=int(rows[0, 5]) * SCALE)
    fleet = VehicleType(num_available=int(vehicle[0]), capacity=[int(vehicle[1])],
                        tw_early=int(rows[0, 4]) * SCALE, tw_late=int(rows[0, 5]) * SCALE)
    return ProblemData(clients, [depot], [fleet], [matrix], [durations]), distances


def validate_routes(routes, rows, capacity, distances):
    expected = set(range(1, len(rows)))
    visits = [client for route in routes for client in route]
    coverage = len(visits) == len(expected) and set(visits) == expected
    if not all(isinstance(client, int) and client in expected for client in visits):
        return {"coverage_valid": False, "max_capacity_excess": None,
                "max_time_window_lateness": None, "euclidean_distance": None,
                "double_precision_feasible": False}
    max_overload, max_lateness, total_distance = 0, 0.0, 0.0
    for route in routes:
        max_overload = max(max_overload, sum(int(rows[i, 3]) for i in route) - capacity)
        now, previous = float(rows[0, 4]), 0
        for client in route:
            travel = float(distances[previous, client])
            total_distance += travel
            now = max(now + travel, float(rows[client, 4]))
            max_lateness = max(max_lateness, now - float(rows[client, 5]))
            now += float(rows[client, 6])
            previous = client
        total_distance += float(distances[previous, 0])
        now += float(distances[previous, 0])
        max_lateness = max(max_lateness, now - float(rows[0, 5]))
    return {"coverage_valid": coverage, "max_capacity_excess": max_overload,
            "max_time_window_lateness": max_lateness, "euclidean_distance": total_distance,
            "double_precision_feasible": coverage and max_overload == 0 and max_lateness <= 1e-6}


def stop_processes(processes):
    terminated = []
    for pe, process in enumerate(processes):
        if process.is_alive():
            process.terminate()
            terminated.append(pe)
    for process in processes:
        process.join(timeout=1)
        if process.is_alive():
            process.kill()
            process.join(timeout=1)
    return terminated


class _FeasibleIncumbent:
    def __init__(self, ctx, deadline):
        self._slots = [SharedRecord(ctx), SharedRecord(ctx)]
        self._active = ctx.RawValue("i", 0)
        self._deadline = deadline

    def get(self, key, default=None):
        return self._slots[self._active.value].get(key, default)

    def snapshot(self):
        return self._slots[self._active.value].snapshot()

    def update(self, candidate):
        if candidate["timestamp"] <= self._deadline:
            next_slot = 1 - self._active.value
            self._slots[next_slot].update(candidate)
            self._active.value = next_slot


def _evolve_pe(data, pe, num_pes, seed, elite, feasible, lock, barrier,
               run_start, budget, call_start, deadline, distance_stage, wall_slots):
    def finish_initialization(algorithm, iteration):
        if iteration == 0:
            try:
                barrier.wait(timeout=max(0.001, deadline - time.perf_counter()))
            except threading.BrokenBarrierError:
                if time.perf_counter() < deadline:
                    raise RuntimeError("A processing element failed during initialization")

    try:
        algorithm, _ = create_island_genetic_algorithm(
            data=data, seed=seed + pe * 1000, island_id=pe,
            global_best=elite, global_best_lock=lock, shared_best_feasible=feasible,
            is_distance_optimization=distance_stage, num_islands=num_pes,
            population_size=25, runtime_limit=max(0.001, deadline - call_start),
            call_deadline=deadline, overall_start_time=run_start,
            overall_runtime_limit=budget, distance_scale=SCALE,
            use_dppi=True, use_hch=True, use_hpls=True, use_egks=True,
            alpha_min=1.0, alpha_max=2.0,
            iteration_callback=finish_initialization,
            egks_early_receive_interval=100, egks_late_receive_interval=200,
            egks_early_send_interval=100, egks_late_send_interval=200,
            egks_early_receive_fraction=1 / 3, egks_wallclock_fraction=2 / 3,
            egks_wallclock_interval_seconds=10.0, egks_last_wall_slot=wall_slots,
        )
        remaining = max(0.001, deadline - time.perf_counter())
        algorithm.run(MaxRuntime(remaining), collect_stats=False, display=False)
    except BaseException:
        barrier.abort()
        raise


def _search_fleet_limit(ctx, data, fleet_limit, num_pes, seed, run_start, budget,
                        deadline, wall_slots, incumbent=None):
    call_start = time.perf_counter()
    vehicle = data.vehicle_type(0)
    bounded_data = data.replace(vehicle_types=[VehicleType(
        num_available=fleet_limit, capacity=vehicle.capacity,
        tw_early=vehicle.tw_early, tw_late=vehicle.tw_late,
    )])
    lock, barrier = ctx.Lock(), ctx.Barrier(num_pes)
    elite, feasible = SharedRecord(ctx), _FeasibleIncumbent(ctx, deadline)
    if incumbent is not None:
        seed_record = dict(incumbent, num_iterations=0, completed_local_iterations=0)
        elite.update(seed_record)
        feasible.update(seed_record)
    workers = []
    try:
        for pe in range(num_pes):
            if time.perf_counter() >= deadline:
                break
            worker = ctx.Process(
                name=f"PE-{pe}", target=_evolve_pe,
                args=(bounded_data, pe, num_pes, seed, elite, feasible, lock, barrier,
                      run_start, budget, call_start, deadline, incumbent is not None, wall_slots),
            )
            worker.start()
            workers.append(worker)
        while any(worker.is_alive() for worker in workers):
            if any(worker.exitcode not in (None, 0) for worker in workers):
                break
            if time.perf_counter() >= deadline + 2:
                break
            time.sleep(0.05)
    finally:
        terminated = stop_processes(workers)
    for pe, worker in enumerate(workers):
        if pe not in terminated and worker.exitcode != 0:
            raise RuntimeError(f"{worker.name} exited with status {worker.exitcode}")
        if worker.is_alive():
            raise RuntimeError(f"{worker.name} did not stop at the deadline")
    return feasible.snapshot() or None


def solve(instance_path, *, target_fs, num_pes=32, budget=1800.0, seed=0):
    if not math.isfinite(budget) or budget <= 0:
        raise ValueError("The time budget must be positive and finite.")
    if num_pes < 1 or num_pes > (os.cpu_count() or 1):
        raise ValueError("The PE count must be between one and the available logical CPU count.")
    if seed < 0 or seed + (num_pes - 1) * 1000 >= 2**32:
        raise ValueError("The seed and PE offsets must fit an unsigned 32-bit integer.")
    run_start = time.perf_counter()
    deadline = run_start + budget
    fleet_deadline = run_start + 0.8 * budget
    vehicle, rows = read_instance(instance_path)
    fleet_limit, capacity = (int(value) for value in vehicle)
    if capacity <= 0 or fleet_limit <= 0:
        raise ValueError("The instance must have positive fleet size and vehicle capacity.")
    if not 1 <= target_fs <= fleet_limit:
        raise ValueError("The target fleet size must be within the available fleet.")
    data, distances = build_data(vehicle, rows, conservative_durations=True)
    ctx = mp.get_context("spawn")
    wall_slots = ctx.RawArray("q", [-1] * num_pes)

    def checked(candidate, limit, cutoff):
        routes = candidate["routes"]
        check = validate_routes(routes, rows, capacity, distances)
        if not (check["double_precision_feasible"] and all(routes)
                and len(routes) == candidate["num_vehicles"] <= limit
                and run_start <= candidate["timestamp"] <= cutoff):
            raise RuntimeError("The candidate failed independent route or deadline validation.")
        return check["euclidean_distance"]

    best = None
    best_distance = None
    while time.perf_counter() < fleet_deadline:
        candidate = _search_fleet_limit(
            ctx, data, fleet_limit, num_pes, seed, run_start, budget, fleet_deadline, wall_slots
        )
        if candidate is None:
            break
        best_distance = checked(candidate, fleet_limit, fleet_deadline)
        best = candidate
        if best["num_vehicles"] <= target_fs:
            break
        fleet_limit = best["num_vehicles"] - 1
    if best is None:
        raise RuntimeError("No feasible solution was found within the fleet-size search budget.")
    if time.perf_counter() < deadline:
        candidate = _search_fleet_limit(
            ctx, data, best["num_vehicles"], num_pes, seed, run_start, budget, deadline,
            wall_slots, incumbent=best,
        )
        if candidate is not None:
            best_distance = checked(candidate, best["num_vehicles"], deadline)
            best = candidate
    return {"fleet_size": best["num_vehicles"], "total_distance": best_distance,
            "routes": best["routes"]}


def main():
    parser = argparse.ArgumentParser(description="Solve a GH1000 vehicle routing instance.")
    parser.add_argument("instance", type=Path)
    parser.add_argument("--target-fs", type=int, required=True, metavar="TARGET")
    parser.add_argument("--num-pes", type=int, default=32)
    parser.add_argument("--budget", type=float, default=1800.0, metavar="SECONDS")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    try:
        result = solve(args.instance, target_fs=args.target_fs, num_pes=args.num_pes,
                       budget=args.budget, seed=args.seed)
    except (ValueError, OSError, RuntimeError) as error:
        parser.exit(1, f"{parser.prog}: {error}\n")
    print(f"Fleet size: {result['fleet_size']}")
    print(f"Total travel distance: {result['total_distance']:.2f}")


if __name__ == "__main__":
    mp.freeze_support()
    main()
