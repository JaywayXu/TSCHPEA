from __future__ import annotations
from dataclasses import replace
import math
from warnings import warn
import numpy as np
from pyvrp import CostEvaluator
from pyvrp.PenaltyManager import PenaltyManager, PenaltyParams
from pyvrp.exceptions import PenaltyBoundWarning


class HeterogeneousPenaltyManager(PenaltyManager):
    """PE-specific adaptive penalties, stored in the paper's original units."""

    @classmethod
    def init_for_paper(
        cls,
        data,
        params: PenaltyParams,
        distance_scale: float = 1.0,
    ):
        """Use the paper's initial capacity/time-warp coefficients, 20 and 6.

        The main program multiplies distance and time by ``distance_scale``
        while leaving load unchanged. Store and adapt the physical coefficients
        here, then convert them when constructing a model cost evaluator. This
        avoids clipping a scaled capacity coefficient against an unscaled bound.
        """
        if not math.isfinite(distance_scale) or distance_scale <= 0:
            raise ValueError("distance_scale must be finite and positive")
        manager = cls(([20.0] * data.num_load_dimensions, 6.0, 1.0), params)
        manager._distance_scale = float(distance_scale)
        return manager

    def _make_cost_evaluator(self, multiplier: float = 1.0):
        loads, time_warp, distance = self.penalties()
        scale = getattr(self, "_distance_scale", 1.0)
        return CostEvaluator(
            [penalty * multiplier * scale for penalty in loads],
            time_warp * multiplier,
            distance * multiplier,
        )

    def cost_evaluator(self):
        return self._make_cost_evaluator()

    def booster_cost_evaluator(self):
        return self._make_cost_evaluator(self._params.repair_booster)

    def _compute(
        self,
        penalty: float,
        feas_percentage: float,
    ) -> float:
        p = self._params
        min_feasible = p.target_feasible - p.feas_tolerance
        max_feasible = p.target_feasible + p.feas_tolerance
        if feas_percentage < min_feasible:
            new_penalty = (
                penalty * p.penalty_increase
            )
            if new_penalty >= p.max_penalty:
                warn(
                    "Penalty has reached its upper bound.",
                    PenaltyBoundWarning,
                )
        elif feas_percentage > max_feasible:
            new_penalty = (
                penalty * p.penalty_decrease
            )
            if new_penalty <= p.min_penalty:
                warn(
                    "Penalty has reached its lower bound.",
                    PenaltyBoundWarning,
                )
        else:
            return penalty

        return float(np.clip(
            new_penalty,
            p.min_penalty,
            p.max_penalty,
        ))


def make_island_penalty_params(
    island_id: int,
    num_islands: int,
    design_npe: int |None = None,
) -> PenaltyParams:

    if num_islands < 1:
        raise ValueError("num_islands must be at least 1")

    if design_npe is None:
        design_npe = num_islands


    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} must equal "
            f"num_islands={num_islands}"
        )

    if not 0 <= island_id < num_islands:
        raise ValueError(
            f"island_id={island_id} must be in "
            f"[0, {num_islands - 1}]"
        )

    # Pin the paper's baseline settings rather than relying on package defaults.
    original = PenaltyParams(
        solutions_between_updates=50,
        target_feasible=0.43,
        feas_tolerance=0.05,
        penalty_increase=1.34,
        penalty_decrease=0.32,
    )
    lower_init = (
        original.target_feasible
        - original.feas_tolerance
    )
    upper_init = (
        original.target_feasible
        + original.feas_tolerance
    )

    delta_ro = (
        upper_init - lower_init
    ) / design_npe

    if design_npe == 1:
        position = 0.0
    else:
        position = (
            island_id / (design_npe - 1)
        )

    delta_inc = (
        original.penalty_increase
        - original.penalty_decrease
    ) / design_npe
    delta_dec = (
                        original.penalty_increase
                        - original.penalty_decrease
                ) / design_npe


    ro_adjustment = (
        position * delta_ro
    )
    increase_adjustment = (
        position * delta_inc
    )
    decrease_adjustment = (
        position * delta_dec
    )

    return replace(
        original,
        target_feasible=(
            original.target_feasible
            + ro_adjustment
        ),
        penalty_increase=(
            original.penalty_increase
            + increase_adjustment
        ),
        penalty_decrease=(
            original.penalty_decrease
            + decrease_adjustment
        ),
    )
