import matplotlib
matplotlib.use('Agg')
from pyvrp import Model
from pyvrp.stop import MaxRuntime, MaxIterations, NoImprovement, MultipleCriteria, StoppingCriterion
from pyvrp.search import (
    NODE_OPERATORS,
    ROUTE_OPERATORS,
    LocalSearch,
    NeighbourhoodParams,
    compute_neighbours,
)
from pyvrp.minimise_fleet import _lower_bound
import math
import re
import os
import pandas as pd
import multiprocessing
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
from pyvrp.exceptions import PenaltyBoundWarning
warnings.filterwarnings(
    "default",
    category=PenaltyBoundWarning,
)
import gc

from mab_genetic_V5 import create_hybrid_genetic_algorithm, create_island_genetic_algorithm

HYBRID_CONFIG = {
    'switch_interval': 2000,
    'tournament_size': 5,
    'num_arms': 8,
    'c': 1.2,
    'initial_temperature': 1.5,
    'cooling_rate': 0.9998,
    'custom_vehicle_weight': 5.0,
    'custom_distance_weight': 0.0
}


ISLAND_POPULATION_SIZE = 25

VEHICLE_PHASE_EXTRA_RUNTIME_BY_PROBLEM = {
    "C1_10_2": {
        92: 240,
        91: 300,
        90: 600,
    },
    "C1_8_2": {
        73: 1200,
        72: 1200,
    },
    "C1_10_6": {
        99: 3600,
    },
    "C1_10_7": {
        99: 240,
        98: 600,
        97: 3600,
    },
    "C1_10_8": {
        94: 600,
        93: 1800,
        92: 3600,
    },
    "C1_10_9": {
        90: 600,
    },
    "C2_10_2": {
        29: 240,
    },
    "C2_10_3": {
        28: 600,
    },
    "C2_10_4": {
        28: 600,
    },
    "C2_10_6": {
        29: 600,
    },
    "C2_10_7": {
        29: 2400,
    },
    "C2_10_8": {
        28: 1200,
    },
    "C2_10_9": {
        28: 2400,
    },
    "C2_10_10": {
        28: 600,
    },
    "RC2_10_1": {
        21: 600,
        20:600,
    },
    "RC2_10_2": {
        20:240,
        19:600,
        18:1200,
    },
    "RC2_10_5": {
        18: 900,
    },
    "RC1_4_1": {
        36: 600,
    },
}

ISLAND_CONFIG = {
    'num_islands': 2,
    'migration_interval': 500,
    'migration_queue_size': 50,
    'diversity_migration_threshold': 200,
    'min_isolation_period': 1000
}

PENALTY_CONFIG = {
    'design_npe': ISLAND_CONFIG['num_islands'],
}


SCALE_FACTOR = 10000

import csv

def save_iteration_history(history, problem_name, phase_name, island_id, base_dir="results", call_index=None):
    if call_index is not None and phase_name == "vehicle_phase":
        phase_dir = f"{phase_name}_call{call_index}"
    else:
        phase_dir = phase_name
    dir_path = os.path.join(base_dir, problem_name, phase_dir)
    os.makedirs(dir_path, exist_ok=True)
    
    file_name = f"island_{island_id:03d}_history.csv"
    file_path = os.path.join(dir_path, file_name)
    
    with open(file_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if history and len(history[0]) >= 5:
            writer.writerow(["island_id", "iteration", "elapsed_time", "num_vehicles", "distance"])
        else:
            writer.writerow(["island_id", "iteration", "num_vehicles", "distance"])
        writer.writerows(history)
    
    return file_path

def load_all_histories(problem_name, phase_name, base_dir="results", call_index=None, max_island_id=None):
    if call_index is not None and phase_name == "vehicle_phase":
        phase_dir = f"{phase_name}_call{call_index}"
    else:
        phase_dir = phase_name
    dir_path = os.path.join(base_dir, problem_name, phase_dir)
    
    if not os.path.exists(dir_path):
        return []
    
    all_rows = []
    for file_name in os.listdir(dir_path):
        if not file_name.endswith("_history.csv"):
            continue
        
        try:
            file_island_id_str = file_name.replace("island_", "").replace("_history.csv", "")
            file_island_id = int(file_island_id_str)
            if max_island_id is not None and file_island_id >= max_island_id:
                continue
        except (ValueError, AttributeError):
            pass
        
        file_path = os.path.join(dir_path, file_name)
        try:
            with open(file_path, "r", newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    island_id = int(row["island_id"])
                    if max_island_id is not None and island_id >= max_island_id:
                        continue
                    iteration = int(row["iteration"])
                    elapsed_time = float(row["elapsed_time"]) if "elapsed_time" in row else 0.0
                    all_rows.append([
                        island_id,
                        iteration,
                        elapsed_time,
                        float(row["num_vehicles"]),
                        float(row["distance"])
                    ])
        except Exception as e:
            print(f"警告：读取历史文件 {file_path} 时出错: {e}")
            continue
    
    return all_rows


class EarlyStopAfterFeasible:
    def __init__(self, max_runtime, delay_after_feasible=10):
        self.max_runtime = max_runtime
        self.delay_after_feasible = delay_after_feasible
        self.start_time = None
        self.feasible_found_time = None
        self.population_reference = None
        
    def set_population_reference(self, population, cost_evaluator):
        self.population_reference = population
        self.cost_evaluator_reference = cost_evaluator
        
    def __call__(self, cost_or_result):
        if self.start_time is None:
            self.start_time = time.time()
            
        current_time = time.time()
        elapsed_time = current_time - self.start_time
        
        if elapsed_time >= self.max_runtime:
            return True
        
        has_feasible_solution = False
        
        try:
            if hasattr(cost_or_result, 'best'):
                has_feasible_solution = cost_or_result.best.is_feasible()
            elif self.population_reference is not None:
                best_solution = self.population_reference.best()
                if best_solution is not None:
                    has_feasible_solution = best_solution.is_feasible()
        except:
            has_feasible_solution = False
            
        if has_feasible_solution:
            if self.feasible_found_time is None:
                self.feasible_found_time = current_time
                print(f"找到可行解！将在 {self.delay_after_feasible} 秒后停止...")
                
            elif current_time - self.feasible_found_time >= self.delay_after_feasible:
                print(f"延迟 {self.delay_after_feasible} 秒后停止")
                return True
                
        return False

def load_solomon_data(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    vehicle_info_str = re.search(r'VEHICLE\nNUMBER\s+CAPACITY\n\s*(\d+)\s+(\d+)', content)
    num_vehicles = int(vehicle_info_str.group(1))
    vehicle_capacity = int(vehicle_info_str.group(2))
    customer_data_str = re.search(r'CUSTOMER\n(.+)', content, re.DOTALL).group(1)
    lines = customer_data_str.strip().split('\n')[2:]
    coords, demands, time_windows, service_times = [], [], [], []
    for line in lines:
        if not line.strip(): continue
        parts = list(map(int, line.split()))
        coords.append((parts[1], parts[2]))
        demands.append(parts[3])
        time_windows.append((parts[4], parts[5]))
        service_times.append(parts[6])
    return num_vehicles, vehicle_capacity, coords, demands, time_windows, service_times

def merge_islands_history_and_generate_global_best(all_islands_history):
    if not all_islands_history or len(all_islands_history) == 0:
        return [], 0.0
    
    all_records = []
    for island_history in all_islands_history:
        if island_history:
            all_records.extend(island_history)
    
    if not all_records:
        return [], 0.0

    parsed = []
    max_time = 0.0
    for record in all_records:
        if len(record) >= 5:
            island_id, iter_num, time_sec, num_vehicles, distance = record[0], record[1], record[2], record[3], record[4]
        elif len(record) == 4:
            island_id, iter_num, num_vehicles, distance = record[0], record[1], record[2], record[3]
            time_sec = float(iter_num)
        else:
            continue

        if num_vehicles == float('inf') or distance == float('inf'):
            continue

        parsed.append((float(time_sec), island_id, num_vehicles, distance))
        if time_sec > max_time:
            max_time = float(time_sec)

    if not parsed:
        return [], max_time

    parsed.sort(key=lambda x: x[0])

    global_best_history = []
    best_vehicles = float('inf')
    best_distance = float('inf')

    for time_sec, island_id, num_vehicles, distance in parsed:
        is_better = False
        if num_vehicles < best_vehicles:
            is_better = True
        elif num_vehicles == best_vehicles and distance < best_distance:
            is_better = True

        if is_better:
            global_best_history.append((
                time_sec,
                num_vehicles,
                distance,
                island_id
            ))
            best_vehicles = num_vehicles
            best_distance = distance

    return global_best_history, max_time


def plot_iteration_history(global_best_history, filename, output_dir=None, phase_name="", call_index=None, final_solution=None, max_iteration=None, export_csv=True):
    if not global_best_history or len(global_best_history) == 0:
        print(f"警告: 没有历史记录可供绘图 ({phase_name})")
        return
    
    try:
        times = []
        vehicles = []
        distances = []
        island_ids = []
        phases = []
        
        for record in global_best_history:
            times.append(record[0])
            vehicles.append(record[1])
            distances.append(record[2])
            island_ids.append(record[3] if len(record) >= 4 else -1)
            phases.append(record[4] if len(record) >= 5 else "")
        
        x_min = min(times) if times else 0.0
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        phase_lower = str(phase_name).lower()
        if "车辆" in phase_name or "vehicle" in phase_lower:
            if call_index is not None:
                title_phase = f"Vehicle optimization (Call {call_index})"
            else:
                title_phase = "Vehicle optimization"
        elif "距离" in phase_name or "distance" in phase_lower:
            title_phase = "Distance optimization"
        else:
            title_phase = "Optimization"

        fig.suptitle(f'{title_phase} - {os.path.basename(filename)}', fontsize=14, fontweight='bold')
        
        ax1.plot(times, vehicles, 'b-', linewidth=1.5, alpha=0.8, marker='o', markersize=4)
        ax1.set_xlabel('Time (s)', fontsize=11)
        ax1.set_ylabel('NV', fontsize=11)
        ax1.set_title('NV', fontsize=12)
        ax1.grid(True, alpha=0.3)
        
        if max_iteration is not None and max_iteration > x_min:
            ax1.set_xlim(left=x_min, right=max_iteration)
        else:
            ax1.set_xlim(left=x_min)
        if vehicles:
            min_vehicles = min(vehicles)
            max_vehicles = max(vehicles)
            ax1.set_ylim(bottom=max(0, min_vehicles - 1), top=max_vehicles + 1)
            if max_vehicles - min_vehicles <= 10:
                ax1.set_yticks(range(int(min_vehicles), int(max_vehicles) + 2))
            
            if len(vehicles) > 0:
                best_time = times[-1]
                best_nv = vehicles[-1]
                best_dist = distances[-1]
                
                ax1.plot(best_time, best_nv, 'bo', markersize=8, zorder=5)
                ax1.annotate(f'NV={int(best_nv)}', 
                            xy=(best_time, best_nv),
                            xytext=(10, 10), textcoords='offset points',
                            fontsize=10, fontweight='bold',
                            bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7),
                            arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0'))
                
                ax1.plot(best_time, best_nv, 'g*', markersize=12, zorder=6, label='Final Solution')
                ax1.annotate(f'Final: NV={int(best_nv)}', 
                            xy=(best_time, best_nv),
                            xytext=(10, -20), textcoords='offset points',
                            fontsize=10, fontweight='bold',
                            bbox=dict(boxstyle='round,pad=0.3', facecolor='lightgreen', alpha=0.8),
                            arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0'))
                
                if max_iteration is not None and max_iteration > best_time:
                    ax1.plot([best_time, max_iteration],
                             [best_nv, best_nv],
                             linestyle='--', alpha=0.8, color='blue', linewidth=1.5)
        
        ax2.plot(times, distances, 'r-', linewidth=1.5, alpha=0.8, marker='o', markersize=4)
        ax2.set_xlabel('Time (s)', fontsize=11)
        ax2.set_ylabel('Distance', fontsize=11)
        ax2.set_title('Distance', fontsize=12)
        ax2.grid(True, alpha=0.3)
        
        if max_iteration is not None and max_iteration > x_min:
            ax2.set_xlim(left=x_min, right=max_iteration)
        else:
            ax2.set_xlim(left=x_min)
        if distances:
            min_distance = min(distances)
            max_distance = max(distances)
            margin = (max_distance - min_distance) * 0.1 if max_distance > min_distance else max_distance * 0.1
            ax2.set_ylim(bottom=max(0, min_distance - margin), top=max_distance + margin)
            
            if len(distances) > 0:
                best_time = times[-1]
                best_nv = vehicles[-1]
                best_dist = distances[-1]
                
                ax2.plot(best_time, best_dist, 'ro', markersize=8, zorder=5)
                ax2.annotate(f'Distance={best_dist:.2f}', 
                            xy=(best_time, best_dist),
                            xytext=(10, 10), textcoords='offset points',
                            fontsize=10, fontweight='bold',
                            bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7),
                            arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0'))
                
                ax2.plot(best_time, best_dist, 'g*', markersize=12, zorder=6, label='Final Solution')
                ax2.annotate(f'Final: Dist={best_dist:.2f}', 
                            xy=(best_time, best_dist),
                            xytext=(10, -20), textcoords='offset points',
                            fontsize=10, fontweight='bold',
                            bbox=dict(boxstyle='round,pad=0.3', facecolor='lightgreen', alpha=0.8),
                            arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0'))
                
                if max_iteration is not None and max_iteration > best_time:
                    ax2.plot([best_time, max_iteration],
                             [best_dist, best_dist],
                             linestyle='--', alpha=0.8, color='red', linewidth=1.5)
        
        plt.tight_layout()
        
        if output_dir is None:
            output_dir = r"C:\Users\yiran\Desktop\TSCHPEA\final\expriement"
        
        base_name = os.path.splitext(os.path.basename(filename))[0]
        phase_name_clean = phase_name.replace(' ', '').replace('阶段', '').replace('第', '_').replace('次', '')
        phase_suffix = f"_{phase_name_clean}" if phase_name_clean else ""
        output_filename = f"{base_name}{phase_suffix}_time_history.png"
        output_path = os.path.join(output_dir, output_filename)
        
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        print(f"已保存{phase_name}阶段时间历史图表: {output_path}")
        
        if export_csv:
            try:
                csv_data = []
                for i in range(len(times)):
                    if vehicles[i] != float('inf') and distances[i] != float('inf'):
                        row = {
                            'Time_Seconds': times[i],
                            'Num_Vehicles': int(vehicles[i]),
                            'Distance': distances[i],
                            'Island_ID': island_ids[i],
                        }
                        if any(phases):
                            row['Phase'] = phases[i]
                        csv_data.append(row)
                
                if csv_data:
                    csv_filename = output_filename.replace('.png', '.csv')
                    csv_path = os.path.join(output_dir, csv_filename)
                    df = pd.DataFrame(csv_data)
                    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
                    print(f"已保存{phase_name}阶段时间历史CSV: {csv_path}")
            except Exception as csv_err:
                print(f"导出CSV时出错 ({phase_name}): {csv_err}")
        
    except Exception as e:
        print(f"绘图时出错 ({phase_name}): {e}")
        import traceback
        traceback.print_exc()
        try:
            plt.close()
        except:
            pass



def validate_pyvrp_solution(solution, num_all_clients: int, vehicle_capacity: int, filename: str, scale_factor: int = SCALE_FACTOR):
    print(f"正在为文件 {filename} 验证方案 (Validating solution for file {filename})...")
    all_required_clients = set(range(1, num_all_clients + 1))
    served_clients = set()
    for route_idx, route in enumerate(solution.routes()):
        for client in route.visits():
            if client in served_clients:
                print(f"错误 (Error): 客户 (Customer) {client} 被服务了多次 (served multiple times)。")
                return False
            served_clients.add(client)
    unserved = all_required_clients - served_clients
    if unserved:
        print(f"警告 (Warning): 客户 (Customers) {unserved} 未被服务 (not served)。")
    for route_idx, route in enumerate(solution.routes()):
        vehicle_num = route_idx + 1
        total_demand = sum(route.delivery())
        if total_demand > vehicle_capacity:
            print(f"错误 (Error): 车辆 (Vehicle) {vehicle_num} 的路径超载 (exceeds capacity)。")
            print(f" -> 路径需求 (Route Demand): {total_demand}, 车辆容量 (Vehicle Capacity): {vehicle_capacity}")
            return False
        
        time_warp = route.time_warp()
        if time_warp > 0:
            actual_time_warp = time_warp / scale_factor
            print(f"错误 (Error): 车辆 (Vehicle) {vehicle_num} 的路径违反了时间窗 (violates time windows)。")
            print(f" -> 时间窗冲突值 (Time Warp Value): {actual_time_warp:.2f}")
            return False
            
    print(f"文件 {filename} 的方案验证成功 (Solution validation for file {filename} completed successfully!)")
    return True


def get_island_specific_config(island_id, base_config):
    import math
    import hashlib
    
    seed = int(hashlib.md5(f"island_{island_id}".encode()).hexdigest()[:8], 16)
    
    import random
    temp_random = random.Random(seed)
    
    param_ranges = {
        'tournament_size': (2, 12),
        'num_arms': (3, 25),
        'c': (0.3, 4.0),
        'switch_interval': (30, 300),
        'initial_temperature': (0.5, 5.0),
        'cooling_rate': (0.9990, 0.99995),
        'custom_vehicle_weight': (1.0, 15.0),
        'custom_distance_weight': (0.0, 5.0)
    }
    
    island_config = base_config.copy()
    
    for param, (min_val, max_val) in param_ranges.items():
        if param in ['tournament_size', 'num_arms', 'switch_interval']:
            island_config[param] = temp_random.randint(int(min_val), int(max_val))
        else:
            island_config[param] = temp_random.uniform(min_val, max_val)
    
    strategy_type = island_id % 10
    
    if strategy_type == 0:
        island_config.update({
            'tournament_size': max(2, island_config['tournament_size'] // 2),
            'c': min(0.8, island_config['c'] * 0.5),
            'switch_interval': max(200, island_config['switch_interval']),
            'initial_temperature': min(1.0, island_config['initial_temperature']),
            'custom_vehicle_weight': min(3.0, island_config['custom_vehicle_weight']),
            'num_arms': min(6, island_config['num_arms'])
        })
        
    elif strategy_type == 1:
        island_config.update({
            'tournament_size': min(12, island_config['tournament_size'] + 3),
            'c': max(2.5, island_config['c'] * 1.5),
            'switch_interval': min(50, island_config['switch_interval']),
            'initial_temperature': max(3.0, island_config['initial_temperature']),
            'custom_vehicle_weight': max(8.0, island_config['custom_vehicle_weight']),
            'num_arms': max(15, island_config['num_arms'])
        })
        
    elif strategy_type == 2:
        island_config.update({
            'num_arms': max(20, island_config['num_arms']),
            'c': max(2.0, island_config['c']),
            'switch_interval': temp_random.randint(60, 120),
            'initial_temperature': temp_random.uniform(2.0, 4.0),
            'custom_distance_weight': max(2.0, island_config['custom_distance_weight'])
        })
        
    elif strategy_type == 3:
        island_config.update({
            'tournament_size': max(8, island_config['tournament_size']),
            'switch_interval': max(150, island_config['switch_interval']),
            'c': min(1.2, island_config['c']),
            'custom_vehicle_weight': temp_random.uniform(10.0, 15.0),
            'num_arms': min(8, island_config['num_arms'])
        })
        
    elif strategy_type == 4:
        island_config.update({
            'custom_distance_weight': max(3.0, island_config['custom_distance_weight']),
            'custom_vehicle_weight': min(2.0, island_config['custom_vehicle_weight']),
            'c': temp_random.uniform(1.0, 2.0),
            'switch_interval': temp_random.randint(80, 150),
            'initial_temperature': temp_random.uniform(1.5, 2.5)
        })
        
    elif strategy_type == 5:
        island_config.update({
            'custom_vehicle_weight': max(10.0, island_config['custom_vehicle_weight']),
            'custom_distance_weight': 0.0,
            'c': max(1.8, island_config['c']),
            'initial_temperature': max(2.5, island_config['initial_temperature']),
            'switch_interval': min(80, island_config['switch_interval'])
        })
        
    elif strategy_type == 6:
        island_config.update({
            'initial_temperature': max(4.0, island_config['initial_temperature']),
            'cooling_rate': min(0.99992, island_config['cooling_rate']),
            'switch_interval': max(200, island_config['switch_interval']),
            'c': temp_random.uniform(1.5, 3.0)
        })
        
    elif strategy_type == 7:
        island_config.update({
            'switch_interval': min(40, island_config['switch_interval']),
            'c': max(2.0, island_config['c']),
            'tournament_size': temp_random.randint(6, 10),
            'initial_temperature': temp_random.uniform(1.8, 3.0)
        })
        
    elif strategy_type == 8:
        island_config.update({
            'custom_vehicle_weight': temp_random.uniform(4.0, 8.0),
            'custom_distance_weight': temp_random.uniform(1.0, 3.0),
            'c': temp_random.uniform(1.2, 2.2),
            'switch_interval': temp_random.randint(90, 150)
        })
        
    else:
        island_config.update({
            'switch_interval': temp_random.randint(40, 80),
            'c': temp_random.uniform(1.5, 3.5),
            'initial_temperature': temp_random.uniform(2.0, 4.5),
            'cooling_rate': temp_random.uniform(0.9991, 0.9998),
            'num_arms': temp_random.randint(12, 25)
        })
    
    fine_tune_seed = (island_id * 7 + 13) % 20
    
    temp_multipliers = [0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 
                       1.6, 1.7, 1.8, 1.9, 2.0, 2.2, 2.4, 2.6, 2.8, 3.0]
    weight_multipliers = [0.5, 0.7, 0.9, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2,
                         2.5, 2.8, 3.0, 3.5, 4.0, 4.5, 5.0, 6.0, 7.0, 8.0]
    
    island_config['initial_temperature'] *= temp_multipliers[fine_tune_seed]
    island_config['custom_vehicle_weight'] *= weight_multipliers[fine_tune_seed]
    
    distance_additions = [0.0, 0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 1.8, 2.5, 3.5]
    distance_idx = (island_id * 3) % len(distance_additions)
    island_config['custom_distance_weight'] += distance_additions[distance_idx]
    
    island_config['tournament_size'] = max(2, min(15, int(island_config['tournament_size'])))
    island_config['num_arms'] = max(3, min(30, int(island_config['num_arms'])))
    island_config['c'] = max(0.1, min(5.0, island_config['c']))
    island_config['switch_interval'] = max(20, min(400, int(island_config['switch_interval'])))
    island_config['initial_temperature'] = max(0.1, min(8.0, island_config['initial_temperature']))
    island_config['cooling_rate'] = max(0.9985, min(0.99999, island_config['cooling_rate']))
    island_config['custom_vehicle_weight'] = max(0.5, min(20.0, island_config['custom_vehicle_weight']))
    island_config['custom_distance_weight'] = max(0.0, min(8.0, island_config['custom_distance_weight']))
    
    return island_config


def run_island_worker_with_migration(island_id, filepath, num_vehicles, runtime_limit, seed_base, hybrid_params, penalty_config, global_best, global_best_lock, result_queue, num_islands=None, runtime_limit_param=None, call_index=None):
    try:
        if num_islands is None:
            num_islands = ISLAND_CONFIG['num_islands']
        
        
        island_seed = seed_base + island_id * 1000
        
        island_hybrid_params = get_island_specific_config(island_id, hybrid_params)
        
        
        scale_factor = SCALE_FACTOR
        
        INITIAL_NUM_VEHICLES, VEHICLE_CAPACITY, COORDS, DEMANDS, TIME_WINDOWS, SERVICE_TIMES = load_solomon_data(filepath)
        num_locations = len(COORDS)
        
        SCALED_TIME_WINDOWS = []
        SCALED_SERVICE_TIMES = []
        
        for i in range(len(TIME_WINDOWS)):
            early, late = TIME_WINDOWS[i]
            SCALED_TIME_WINDOWS.append((int(early * scale_factor), int(late * scale_factor)))
            SCALED_SERVICE_TIMES.append(int(SERVICE_TIMES[i] * scale_factor))
        
        DURATION_MATRIX = [[math.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2) * scale_factor for c2 in COORDS] for c1 in COORDS]
        
        m = Model()
        m.add_vehicle_type(num_vehicles, capacity=VEHICLE_CAPACITY, tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        m.add_depot(x=COORDS[0][0], y=COORDS[0][1], tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        
        clients = [m.add_client(
            x=COORDS[i][0], 
            y=COORDS[i][1], 
            tw_early=SCALED_TIME_WINDOWS[i][0], 
            tw_late=SCALED_TIME_WINDOWS[i][1], 
            delivery=DEMANDS[i], 
            service_duration=SCALED_SERVICE_TIMES[i]
        ) for i in range(1, len(COORDS))]
        
        for i in range(num_locations):
            for j in range(num_locations):
                frm = m.locations[i]
                to = m.locations[j]
                distance = math.sqrt((frm.x - to.x)**2 + (frm.y - to.y)**2)
                scaled_distance = int(distance * scale_factor)
                scaled_duration = int(DURATION_MATRIX[i][j])
                m.add_edge(frm, to, distance=scaled_distance, duration=scaled_duration)
        
        data = m.data()
        algo, rng = create_island_genetic_algorithm(
            data=data,
            seed=island_seed,
            hybrid_params=island_hybrid_params,
            custom_neighbourhood_params=NeighbourhoodParams(),
            custom_swap_star_params=0.1,
            island_id=island_id,
            global_best=global_best,
            global_best_lock=global_best_lock,
            is_distance_optimization=False,
            num_islands=num_islands,
            population_size=ISLAND_POPULATION_SIZE,
            runtime_limit=runtime_limit_param if runtime_limit_param is not None else runtime_limit,
            penalty_config = penalty_config,
        )
        
        stop_criteria = MaxRuntime(runtime_limit)
        res = algo.run(stop=stop_criteria, collect_stats=False, display=False)

        iteration_history = []
        if hasattr(algo, 'iteration_history') and algo.iteration_history:
            history_to_process = algo.iteration_history
            
            for record in history_to_process:
                if len(record) >= 5:
                    island_id_record, iter_num, elapsed_time, num_vehicles, distance_scaled = record[0], record[1], record[2], record[3], record[4]
                    distance_original = distance_scaled / scale_factor if distance_scaled != float('inf') else float('inf')
                    iteration_history.append([island_id_record, iter_num, elapsed_time, num_vehicles, distance_original])
        
        problem_name = os.path.splitext(os.path.basename(filepath))[0]
        history_file = None
        if iteration_history:
            try:
                history_file = save_iteration_history(
                    history=iteration_history,
                    problem_name=problem_name,
                    phase_name="vehicle_phase",
                    island_id=island_id,
                    base_dir="results",
                    call_index=call_index
                )
            except Exception as e:
                print(f"[岛屿 {island_id}] 警告：保存历史记录到 CSV 时出错: {e}")
        
        best_solution_to_use = None
        solution_source = ""
        
        res_best_feasible = res.best.is_feasible() if res.best else False
        res_best_vehicles = len(res.best.routes()) if res_best_feasible else float('inf')
        res_best_distance = res.best.distance() if res_best_feasible else float('inf')
        
        local_best_feasible = False
        local_best_vehicles = float('inf')
        local_best_distance = float('inf')
        
        if hasattr(algo, 'local_best_solution') and algo.local_best_solution is not None:
            local_best_feasible = algo.local_best_solution.is_feasible()
            if local_best_feasible:
                local_best_vehicles = len(algo.local_best_solution.routes())
                local_best_distance = algo.local_best_solution.distance()
        
        if res_best_feasible and local_best_feasible:
            if res_best_vehicles < local_best_vehicles:
                best_solution_to_use = res.best
                solution_source = "res.best"
            elif res_best_vehicles > local_best_vehicles:
                best_solution_to_use = algo.local_best_solution
                solution_source = "local_best"
            else:
                if res_best_distance < local_best_distance:
                    best_solution_to_use = res.best
                    solution_source = "res.best"
                else:
                    best_solution_to_use = algo.local_best_solution
                    solution_source = "local_best"
        elif res_best_feasible:
            best_solution_to_use = res.best
            solution_source = "res.best"
        elif local_best_feasible:
            best_solution_to_use = algo.local_best_solution
            solution_source = "local_best"
        else:
            best_solution_to_use = None
        
        if best_solution_to_use is not None and best_solution_to_use.is_feasible():
            best_cost = best_solution_to_use.distance() / scale_factor
            
            routes_data = []
            for route in best_solution_to_use.routes():
                route_visits = list(route.visits())
                routes_data.append(route_visits)
            
            solution_data = {
                'routes': routes_data,
                'distance': best_cost,
                'num_iteration': res.num_iterations,
                'is_feasible': True,
                'num_vehicles': len(best_solution_to_use.routes()),
                'history_file': history_file,
                'solution_source': solution_source
            }
            
            num_iterations_island = res.num_iterations
            try:
                result_queue.put((island_id, best_cost, solution_data), timeout=5.0)
            except Exception as e:
                print(f"[岛屿 {island_id}] 警告：结果队列写入失败: {e}")
            return (island_id, best_cost, solution_data)
        else:
            solution_data = {
                'is_feasible': False,
                'num_iteration': res.num_iterations,
                'history_file': history_file
            }
            try:
                result_queue.put((island_id, None, solution_data), timeout=5.0)
            except Exception as e:
                print(f"[岛屿 {island_id}] 警告：结果队列写入失败: {e}")
            return (island_id, None, solution_data)
            
    except Exception as e:
        print(f"[岛屿 {island_id}] 错误: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        try:
            gc.collect()
        except:
            pass


def run_island_worker(island_id, filepath, num_vehicles, runtime_limit, seed_base, hybrid_params, island_config,penalty_config):
    try:
        print(f"[岛屿 {island_id}] 开始处理...")
        
        island_seed = seed_base + island_id * 1000
        
        scale_factor = SCALE_FACTOR
        
        INITIAL_NUM_VEHICLES, VEHICLE_CAPACITY, COORDS, DEMANDS, TIME_WINDOWS, SERVICE_TIMES = load_solomon_data(filepath)
        num_locations = len(COORDS)
        
        SCALED_TIME_WINDOWS = []
        SCALED_SERVICE_TIMES = []
        
        for i in range(len(TIME_WINDOWS)):
            early, late = TIME_WINDOWS[i]
            SCALED_TIME_WINDOWS.append((int(early * scale_factor), int(late * scale_factor)))
            SCALED_SERVICE_TIMES.append(int(SERVICE_TIMES[i] * scale_factor))
        
        DURATION_MATRIX = [[math.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2) * scale_factor for c2 in COORDS] for c1 in COORDS]
        
        m = Model()
        m.add_vehicle_type(num_vehicles, capacity=VEHICLE_CAPACITY, tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        m.add_depot(x=COORDS[0][0], y=COORDS[0][1], tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        
        clients = [m.add_client(
            x=COORDS[i][0], 
            y=COORDS[i][1], 
            tw_early=SCALED_TIME_WINDOWS[i][0], 
            tw_late=SCALED_TIME_WINDOWS[i][1], 
            delivery=DEMANDS[i], 
            service_duration=SCALED_SERVICE_TIMES[i]
        ) for i in range(1, len(COORDS))]
        
        for i in range(num_locations):
            for j in range(num_locations):
                frm = m.locations[i]
                to = m.locations[j]
                distance = math.sqrt((frm.x - to.x)**2 + (frm.y - to.y)**2)
                scaled_distance = int(distance * scale_factor)
                scaled_duration = int(DURATION_MATRIX[i][j])
                m.add_edge(frm, to, distance=scaled_distance, duration=scaled_duration)
        
        island_hybrid_params = get_island_specific_config(island_id, hybrid_params)
        
        data = m.data()
        algo, rng = create_hybrid_genetic_algorithm(
            data=data,
            seed=island_seed,
            hybrid_params=island_hybrid_params,
            custom_neighbourhood_params=NeighbourhoodParams(),
            custom_swap_star_params=0.1,
            island_id=island_id,
            population_size=ISLAND_POPULATION_SIZE,
            num_islands=island_config["num_islands"],
            penalty_config=penalty_config
        )
        
        stop_criteria = MaxRuntime(runtime_limit)
        res = algo.run(stop=stop_criteria, collect_stats=False, display=False)
        
        if res.best.is_feasible():
            best_cost = res.best.distance() / scale_factor
            
            routes_data = []
            for route in res.best.routes():
                route_visits = list(route.visits())
                routes_data.append(route_visits)
            
            solution_data = {
                'routes': routes_data,
                'distance': best_cost,
                'is_feasible': True,
                'num_vehicles': len(res.best.routes())
            }
            
            return (island_id, best_cost, solution_data)
        else:
            print(f"[岛屿 {island_id}] 完成，未找到可行解")
            return None
            
    except Exception as e:
        print(f"[岛屿 {island_id}] 错误: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        try:
            gc.collect()
        except:
            pass

def solve_with_island_model(filepath, num_vehicles, runtime_limit, seed_base=42, call_index=None):
    import multiprocessing as mp
    from multiprocessing import Process, Queue, Manager, Lock
    
    num_islands = ISLAND_CONFIG['num_islands']
    
    manager = Manager()
    global_best = manager.dict({
        "routes": None,
        "num_vehicles": float("inf"),
        "distance": float("inf"),
        "owner_id": -1,
        "timestamp": 0.0,
    })
    global_best_lock = Lock()
    
    result_queue = Queue(maxsize=num_islands * 2)
    
    processes = []
    try:
        for island_id in range(num_islands):
            p = Process(
                target=run_island_worker_with_migration,
                args=(
                    island_id, 
                    filepath, 
                    num_vehicles, 
                    runtime_limit, 
                    seed_base, 
                    HYBRID_CONFIG,
                    PENALTY_CONFIG,
                    global_best,
                    global_best_lock,
                    result_queue,
                    num_islands,
                    runtime_limit,
                    call_index
                )
            )
            p.start()
            processes.append(p)

        results = []
        completed_processes = set()
        max_total_wait_time = runtime_limit + 90
        start_wait_time = time.time()
        
        while len(completed_processes) < num_islands and (time.time() - start_wait_time) < max_total_wait_time:
            while True:
                try:
                    result = result_queue.get(timeout=0.1)
                    results.append(result)
                except:
                    break
            
            for idx, p in enumerate(processes):
                if idx not in completed_processes:
                    if not p.is_alive():
                        completed_processes.add(idx)
                        if p.exitcode != 0:
                            print(f"进程 {p.pid} (岛屿 {idx}) 异常退出, 代码: {p.exitcode}")
            
            if len(completed_processes) < num_islands:
                time.sleep(0.5)
        
        for idx, p in enumerate(processes):
            if idx not in completed_processes:
                p.join(timeout=60.0)
                if p.is_alive():
                    print(f"进程 {p.pid} (岛屿 {idx}) 超时终止（可能卡在队列写入）")
                    p.terminate()
                    p.join(timeout=5.0)
                    if p.is_alive():
                        p.kill()
                        p.join(timeout=2.0)
                else:
                    completed_processes.add(idx)
        
        remaining_attempts = 50
        while remaining_attempts > 0:
            try:
                result = result_queue.get(timeout=0.5)
                results.append(result)
                remaining_attempts -= 1
            except:
                break
        
        import gc
        gc.collect()
        time.sleep(0.5)
        
        valid_results = [r for r in results if r is not None]
        
        
        if valid_results:
            def compare_key(result):
                island_id_result, best_cost_result, solution_data_result = result
                if solution_data_result and solution_data_result.get('is_feasible', False):
                    num_vehicles = solution_data_result.get('num_vehicles', float('inf'))
                    return (num_vehicles, best_cost_result if best_cost_result is not None else float('inf'))
                else:
                    return (float('inf'), float('inf'))
            
            best_result = min(valid_results, key=compare_key)
            island_id, best_cost, solution_data = best_result
            
            
            try:
                problem_name = os.path.splitext(os.path.basename(filepath))[0]
                all_history_raw = load_all_histories(
                    problem_name=problem_name,
                    phase_name="vehicle_phase",
                    base_dir="results",
                    call_index=call_index,
                    max_island_id=ISLAND_CONFIG['num_islands']
                )

                time_buckets = {}
                for record in all_history_raw:
                    if len(record) >= 5:
                        island_id_record, iter_num, elapsed_time, num_vehicles, distance = record
                        if num_vehicles == float('inf') or distance == float('inf'):
                            continue
                        t_key = round(float(elapsed_time), 6)
                        cur = time_buckets.get(t_key)
                        cand = (num_vehicles, distance, island_id_record, iter_num, float(elapsed_time))
                        if cur is None or (cand[0] < cur[0]) or (cand[0] == cur[0] and cand[1] < cur[1]):
                            time_buckets[t_key] = cand

                csv_data = []
                best_nv = float('inf')
                best_dist = float('inf')
                for _t, (nv, dist, island_id_record, iter_num, elapsed_time) in sorted(time_buckets.items(), key=lambda x: x[0]):
                    is_better = (nv < best_nv) or (nv == best_nv and dist < best_dist)
                    if not is_better:
                        continue
                    best_nv = nv
                    best_dist = dist
                    csv_data.append({
                        'Time_Seconds': elapsed_time,
                        'Iteration': iter_num,
                        'Island_ID': island_id_record,
                        'Num_Vehicles': int(nv),
                        'Distance': dist
                    })
                
                if csv_data:
                    if call_index is not None:
                        csv_filename = f"{problem_name}_vehicle_phase_iterations_call{call_index}.csv"
                    else:
                        csv_filename = f"{problem_name}_vehicle_phase_iterations.csv"
                    csv_path = os.path.join(r"C:\Users\yiran\Desktop\TSCHPEA\final\expriement", csv_filename)
                    
                    df = pd.DataFrame(csv_data)
                    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
                    print(f"已保存车辆优化阶段 global_best 汇总CSV: {csv_path}")
            except Exception as csv_err:
                print(f"保存车辆优化阶段 global_best 汇总CSV时出错: {csv_err}")
            
            num_iterations = solution_data.get('num_iteration', 0) if solution_data else 0
            
            num_vehicles = solution_data.get('num_vehicles', '未知') if solution_data else '未知'
            
            if best_cost is not None:
                print(f"=== 最优解来自岛屿 {island_id}，车辆数: {num_vehicles}，成本: {best_cost:.2f}，迭代次数: {num_iterations} ===\n")
            else:
                print(f"=== 最优解来自岛屿 {island_id}，车辆数: {num_vehicles}，成本: 无，迭代次数: {num_iterations} ===\n")
            
            return solution_data
        else:
            print("岛屿模型求解完成，但所有岛屿都未找到可行解")
            return None
            
    except Exception as e:
        print(f"岛屿模型求解时出错: {e}")
        return None
    finally:
        for p in processes:
            if p.is_alive():
                try:
                    p.terminate()
                    p.join(timeout=5.0)
                    if p.is_alive():
                        p.kill()
                        p.join(timeout=2.0)
                except Exception as e:
                    print(f"清理进程 {p.pid} 时出错: {e}")
        
        gc.collect()
        time.sleep(0.5)

def run_distance_optimization_with_islands(filepath, min_vehicles, runtime_limit, seed_base=42, elite_solutions=None):
    import multiprocessing as mp
    from multiprocessing import Process, Queue, Manager, Lock
    
    num_islands = ISLAND_CONFIG['num_islands']
    
    manager = Manager()
    global_best = manager.dict({
        "routes": None,
        "num_vehicles": float("inf"),
        "distance": float("inf"),
        "owner_id": -1,
        "timestamp": 0.0,
    })
    global_best_lock = Lock()
    
    if elite_solutions and len(elite_solutions) > 0:
        print(f"注入{len(elite_solutions)}个精英解到距离优化阶段")
        elite = elite_solutions[0]
        with global_best_lock:
            global_best["routes"] = elite['solution']['routes']
            global_best["num_vehicles"] = elite['solution']['num_vehicles']
            global_best["distance"] = elite['cost']
            global_best["owner_id"] = -1
            global_best["timestamp"] = time.time()
    
    result_queue = Queue()
    
    processes = []
    try:
        for island_id in range(num_islands):
            p = Process(
                target=run_distance_optimization_island,
                args=(
                    island_id, 
                    filepath, 
                    min_vehicles, 
                    runtime_limit, 
                    seed_base + 100,
                    PENALTY_CONFIG,
                    global_best,
                    global_best_lock,
                    result_queue,
                    num_islands,
                    runtime_limit
                )
            )
            p.start()
            processes.append(p)
            
        
        results = []
        completed_processes = set()
        max_total_wait_time = runtime_limit + 60
        start_wait_time = time.time()
        
        while len(completed_processes) < num_islands and (time.time() - start_wait_time) < max_total_wait_time:
            while True:
                try:
                    result = result_queue.get(timeout=0.1)
                    results.append(result)
                except:
                    break
            
            for i, p in enumerate(processes):
                if i not in completed_processes:
                    if not p.is_alive():
                        completed_processes.add(i)
                        if p.exitcode != 0:
                            print(f"进程 {p.pid} (岛屿 {i}) 异常退出, 代码: {p.exitcode}")
            
            if len(completed_processes) < num_islands:
                time.sleep(0.5)
        
        for i, p in enumerate(processes):
            if i not in completed_processes:
                p.join(timeout=30.0)
                if p.is_alive():
                    print(f"距离优化进程 {p.pid} (岛屿 {i}) 超时终止（可能卡在队列写入）")
                    p.terminate()
                    p.join(timeout=5.0)
                    if p.is_alive():
                        p.kill()
                        p.join(timeout=2.0)
                else:
                    completed_processes.add(i)
        
        remaining_attempts = 50
        while remaining_attempts > 0:
            try:
                result = result_queue.get(timeout=0.5)
                results.append(result)
                remaining_attempts -= 1
            except:
                break
        
        valid_results = [r for r in results if r is not None]
        
        problem_name = os.path.splitext(os.path.basename(filepath))[0]
        all_islands_history_raw = load_all_histories(
            problem_name=problem_name,
            phase_name="distance_phase",
            base_dir="results",
            max_island_id=ISLAND_CONFIG['num_islands']
        )
        all_islands_history = []
        if all_islands_history_raw:
            islands_dict = {}
            for record in all_islands_history_raw:
                if len(record) >= 1:
                    island_id_record = record[0]
                    islands_dict.setdefault(island_id_record, []).append(record)
            all_islands_history = list(islands_dict.values())
        
        if valid_results:
            def compare_key(result):
                island_id_result, best_cost_result, solution_data_result = result
                if solution_data_result and solution_data_result.get('is_feasible', False):
                    num_vehicles = solution_data_result.get('num_vehicles', float('inf'))
                    return (num_vehicles, best_cost_result if best_cost_result is not None else float('inf'))
                else:
                    return (float('inf'), float('inf'))
            
            best_result = min(valid_results, key=compare_key)
            island_id, best_cost, solution_data = best_result
            
            if all_islands_history:
                solution_data['all_islands_history'] = all_islands_history
            
            try:
                problem_name = os.path.splitext(os.path.basename(filepath))[0]
                all_history_raw = load_all_histories(
                    problem_name=problem_name,
                    phase_name="distance_phase",
                    base_dir="results",
                    max_island_id=ISLAND_CONFIG['num_islands']
                )

                time_buckets = {}
                for record in all_history_raw:
                    if len(record) >= 5:
                        island_id_record, iter_num, elapsed_time, num_vehicles, distance = record
                        if num_vehicles == float('inf') or distance == float('inf'):
                            continue
                        t_key = round(float(elapsed_time), 6)
                        cur = time_buckets.get(t_key)
                        cand = (num_vehicles, distance, island_id_record, iter_num, float(elapsed_time))
                        if cur is None or (cand[0] < cur[0]) or (cand[0] == cur[0] and cand[1] < cur[1]):
                            time_buckets[t_key] = cand

                csv_data = []
                best_nv = float('inf')
                best_dist = float('inf')
                for _t, (nv, dist, island_id_record, iter_num, elapsed_time) in sorted(time_buckets.items(), key=lambda x: x[0]):
                    is_better = (nv < best_nv) or (nv == best_nv and dist < best_dist)
                    if not is_better:
                        continue
                    best_nv = nv
                    best_dist = dist
                    csv_data.append({
                        'Time_Seconds': elapsed_time,
                        'Iteration': iter_num,
                        'Island_ID': island_id_record,
                        'Num_Vehicles': int(nv),
                        'Distance': dist
                    })
                
                if csv_data:
                    csv_filename = f"{problem_name}_distance_phase_iterations.csv"
                    csv_path = os.path.join(r"C:\Users\yiran\Desktop\TSCHPEA\final\expriement", csv_filename)
                    
                    df = pd.DataFrame(csv_data)
                    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
                    print(f"已保存距离优化阶段 global_best 汇总CSV: {csv_path}")
            except Exception as csv_err:
                print(f"保存距离优化阶段 global_best 汇总CSV时出错: {csv_err}")
            
            num_iterations_distance = solution_data.get('num_iteration', 0) if solution_data else 0
            
            num_vehicles = solution_data.get('num_vehicles', '未知') if solution_data else '未知'
            
            if best_cost is not None:
                print(f"=== 距离优化最优解来自岛屿 {island_id}，车辆数: {num_vehicles}，成本: {best_cost:.2f}，迭代次数: {num_iterations_distance} ===\n")
            else:
                print(f"=== 距离优化最优解来自岛屿 {island_id}，车辆数: {num_vehicles}，成本: 无，迭代次数: {num_iterations_distance} ===\n")
            return solution_data
        else:
            print("距离优化岛屿模型完成，但所有岛屿都未找到可行解")
            if all_islands_history:
                return {'is_feasible': False, 'all_islands_history': all_islands_history}
            return None
            
    except Exception as e:
        print(f"距离优化岛屿模型求解时出错: {e}")
        return None
    finally:
        for p in processes:
            if p.is_alive():
                try:
                    p.terminate()
                    p.join(timeout=5.0)
                    if p.is_alive():
                        p.kill()
                        p.join(timeout=2.0)
                except Exception as e:
                    print(f"清理进程 {p.pid} 时出错: {e}")
        
        gc.collect()
        time.sleep(0.5)

def run_distance_optimization_island(island_id, filepath, min_vehicles, runtime_limit, seed_base, penalty_config, global_best, global_best_lock, result_queue, num_islands=None, runtime_limit_param=None):
    try:
        if num_islands is None:
            num_islands = ISLAND_CONFIG['num_islands']
        
        
        island_seed = seed_base + island_id * 1000
        
        base_distance_params = HYBRID_CONFIG.copy()
        base_distance_params['custom_vehicle_weight'] = 0
        base_distance_params['custom_distance_weight'] = 5.0
        
        island_distance_params = get_island_specific_config(island_id, base_distance_params)
        island_distance_params['num_arms'] = min(12, island_distance_params['num_arms'] + 2)
        island_distance_params['c'] = max(0.5, island_distance_params['c'] - 0.2)
        island_distance_params['switch_interval'] = max(50, island_distance_params['switch_interval'] - 20)
        
        
        scale_factor = SCALE_FACTOR
        
        INITIAL_NUM_VEHICLES, VEHICLE_CAPACITY, COORDS, DEMANDS, TIME_WINDOWS, SERVICE_TIMES = load_solomon_data(filepath)
        num_locations = len(COORDS)
        
        SCALED_TIME_WINDOWS = []
        SCALED_SERVICE_TIMES = []
        
        for i in range(len(TIME_WINDOWS)):
            early, late = TIME_WINDOWS[i]
            SCALED_TIME_WINDOWS.append((int(early * scale_factor), int(late * scale_factor)))
            SCALED_SERVICE_TIMES.append(int(SERVICE_TIMES[i] * scale_factor))
        
        DURATION_MATRIX = [[math.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2) * scale_factor for c2 in COORDS] for c1 in COORDS]
        
        m = Model()
        m.add_vehicle_type(min_vehicles, capacity=VEHICLE_CAPACITY, tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        m.add_depot(x=COORDS[0][0], y=COORDS[0][1], tw_early=SCALED_TIME_WINDOWS[0][0], tw_late=SCALED_TIME_WINDOWS[0][1])
        
        clients = [m.add_client(
            x=COORDS[i][0], 
            y=COORDS[i][1], 
            tw_early=SCALED_TIME_WINDOWS[i][0], 
            tw_late=SCALED_TIME_WINDOWS[i][1], 
            delivery=DEMANDS[i], 
            service_duration=SCALED_SERVICE_TIMES[i]
        ) for i in range(1, len(COORDS))]
        
        for i in range(num_locations):
            for j in range(num_locations):
                frm = m.locations[i]
                to = m.locations[j]
                distance = math.sqrt((frm.x - to.x)**2 + (frm.y - to.y)**2)
                scaled_distance = int(distance * scale_factor)
                scaled_duration = int(DURATION_MATRIX[i][j])
                m.add_edge(frm, to, distance=scaled_distance, duration=scaled_duration)
        
        data = m.data()
        algo, rng = create_island_genetic_algorithm(
            data=data,
            seed=island_seed,
            hybrid_params=island_distance_params,
            custom_neighbourhood_params=NeighbourhoodParams(),
            custom_swap_star_params=0.2,
            island_id=island_id,
            global_best=global_best,
            global_best_lock=global_best_lock,
            is_distance_optimization=True,
            num_islands=num_islands,
            population_size=ISLAND_POPULATION_SIZE,
            runtime_limit=runtime_limit_param if runtime_limit_param is not None else runtime_limit,
            penalty_config = penalty_config
        )

        
        stop_criteria = MaxRuntime(runtime_limit)
        res = algo.run(stop=stop_criteria, collect_stats=False, display=False)

        iteration_history = []
        if hasattr(algo, 'iteration_history') and algo.iteration_history:
            history_to_process = algo.iteration_history
            
            for record in history_to_process:
                if len(record) >= 5:
                    island_id_record, iter_num, elapsed_time, num_vehicles_rec, distance_scaled = record[0], record[1], record[2], record[3], record[4]
                    distance_original = distance_scaled / scale_factor if distance_scaled != float('inf') else float('inf')
                    iteration_history.append([island_id_record, iter_num, elapsed_time, num_vehicles_rec, distance_original])
        
        problem_name = os.path.splitext(os.path.basename(filepath))[0]
        history_file = None
        if iteration_history:
            try:
                history_file = save_iteration_history(
                    history=iteration_history,
                    problem_name=problem_name,
                    phase_name="distance_phase",
                    island_id=island_id,
                    base_dir="results"
                )
            except Exception as e:
                print(f"[距离优化岛屿 {island_id}] 警告：保存历史记录到 CSV 时出错: {e}")
        
        if res.best.is_feasible():
            best_cost = res.best.distance() / scale_factor
            
            routes_data = []
            for route in res.best.routes():
                route_visits = list(route.visits())
                routes_data.append(route_visits)
            
            solution_data = {
                'routes': routes_data,
                'distance': best_cost,
                'is_feasible': True,
                'num_vehicles': len(res.best.routes()),
                'num_iteration': res.num_iterations,
                'history_file': history_file
            }
            
            num_iterations_distance_island = res.num_iterations
            try:
                result_queue.put((island_id, best_cost, solution_data), timeout=5.0)
            except Exception as e:
                print(f"[距离优化岛屿 {island_id}] 警告：结果队列写入失败: {e}")
            return (island_id, best_cost, solution_data)
        else:
            solution_data = {
                'is_feasible': False,
                'num_iteration': res.num_iterations,
                'history_file': history_file
            }
            try:
                result_queue.put((island_id, None, solution_data), timeout=5.0)
            except Exception as e:
                print(f"[距离优化岛屿 {island_id}] 警告：结果队列写入失败: {e}")
            return (island_id, None, solution_data)
            
    except Exception as e:
        print(f"[距离优化岛屿 {island_id}] 错误: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        try:
            gc.collect()
        except:
            pass


def calculate_route_details(route, coords, time_windows, service_times, scale_factor=SCALE_FACTOR):
    route_nodes = [0] + list(route.visits()) + [0]
    
    total_distance = 0
    for i in range(len(route_nodes) - 1):
        from_idx = route_nodes[i]
        to_idx = route_nodes[i+1]
        dx = coords[from_idx][0] - coords[to_idx][0]
        dy = coords[from_idx][1] - coords[to_idx][1]
        distance = math.sqrt(dx*dx + dy*dy)
        total_distance += distance
    
    current_time = 0
    total_time = 0
    total_wait_time = 0
    total_service_time = 0
    
    for i in range(len(route_nodes) - 1):
        from_idx = route_nodes[i]
        to_idx = route_nodes[i+1]
        
        dx = coords[from_idx][0] - coords[to_idx][0]
        dy = coords[from_idx][1] - coords[to_idx][1]
        travel_time = math.sqrt(dx*dx + dy*dy)
        
        current_time += travel_time
        
        
        if i < len(route_nodes) - 1:  
            earliest_time = time_windows[to_idx][0]
            latest_time = time_windows[to_idx][1]
            
            if current_time < earliest_time:
                wait_time = earliest_time - current_time
                total_wait_time += wait_time
                current_time = earliest_time
            
            service_time = service_times[to_idx]
            total_service_time += service_time
            current_time += service_time
    
    total_time = total_distance + total_service_time + total_wait_time
    
    route_representation = " -> ".join([str(node) for node in route_nodes])
    
    return {
        "distance": total_distance,
        "time": total_time,
        "route": route_representation,
        "service_time": total_service_time,
        "wait_time": total_wait_time
    }


def get_min_vehicle_number(num_vehicles: int,
                          vehicle_capacity: int,
                          coords,
                          demands,
                          time_windows,
                          service_times):
    DURATION_MATRIX = [[math.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2) for c2 in coords] for c1 in coords]

    temp_model = Model()
    temp_model.add_vehicle_type(num_vehicles, capacity=vehicle_capacity, tw_early=time_windows[0][0], tw_late=time_windows[0][1])
    temp_model.add_depot(x=coords[0][0], y=coords[0][1], tw_early=time_windows[0][0], tw_late=time_windows[0][1])
    
    clients = [temp_model.add_client(
        x=coords[i][0], 
        y=coords[i][1], 
        tw_early=time_windows[i][0], 
        tw_late=time_windows[i][1], 
        delivery=demands[i], 
        service_duration=service_times[i]
    ) for i in range(1, len(coords))]
    
    for i in range(len(coords)):
        for j in range(len(coords)):
            frm = temp_model.locations[i]
            to = temp_model.locations[j]
            distance = math.sqrt((frm.x - to.x)**2 + (frm.y - to.y)**2)
            scaled_distance = int(distance)
            scaled_duration = int(DURATION_MATRIX[i][j])
            temp_model.add_edge(frm, to, distance=scaled_distance, duration=scaled_duration)

    lower_bound = _lower_bound(temp_model.data())
    return lower_bound


def process_file(filepath, start_time=None, total_time_limit=1800, seed_base=41, run_index=None):
    filename = os.path.basename(filepath)
    run_prefix = f"[运行{run_index}]" if run_index is not None else ""
    try:
        scale_factor = SCALE_FACTOR
        INITIAL_NUM_VEHICLES, VEHICLE_CAPACITY, COORDS, DEMANDS, TIME_WINDOWS, SERVICE_TIMES = load_solomon_data(filepath)

        best_solution_found = None
        best_vehicle_phase_call_index = None
        num_vehicles_to_try = INITIAL_NUM_VEHICLES
        print(f"{run_prefix}[{filename}] 开始搜索最小车辆数，起始车辆数: {num_vehicles_to_try}，随机种子基数: {seed_base}")

        if start_time is None:
            start_time = time.time()

        vehicle_optimization_start = time.time()
        vehicle_opt_call_count = 0
        
        MAX_VEHICLE_OPT_ATTEMPTS = 9
        VEHICLE_OPT_TIME_ALLOCATION = [120, 180, 180, 240, 240, 300, 300,300,300]
        VEHICLE_OPT_TIME_ALLOCATION = [120, 120, 180, 240, 240, 240, 300, 300, 300]
        VEHICLE_OPT_TIME_BUDGET_RATIO = 0.8

        lower_bound = get_min_vehicle_number(num_vehicles_to_try, VEHICLE_CAPACITY, COORDS, DEMANDS, TIME_WINDOWS, SERVICE_TIMES)
        
        print(f"{run_prefix}[{filename}] 计算理论下界: {lower_bound}")

        while num_vehicles_to_try >= lower_bound:
            if vehicle_opt_call_count >= MAX_VEHICLE_OPT_ATTEMPTS:
                print(f"[{filename}] 已达到最大尝试次数 {MAX_VEHICLE_OPT_ATTEMPTS}，停止车辆优化")
                break
            
            elapsed_total = time.time() - start_time
            if elapsed_total >= total_time_limit:
                print(f"[{filename}] 达到总时间限制 {total_time_limit/60:.1f} 分钟，停止车辆优化")
                break
                
            print(f"[{filename}] 正在尝试使用 {num_vehicles_to_try} 辆车...")
            
            if vehicle_opt_call_count < len(VEHICLE_OPT_TIME_ALLOCATION):
                runtime_limit = VEHICLE_OPT_TIME_ALLOCATION[vehicle_opt_call_count]
            else:
                runtime_limit = VEHICLE_OPT_TIME_ALLOCATION[-1]

            vehicle_opt_time_budget = total_time_limit * VEHICLE_OPT_TIME_BUDGET_RATIO
            elapsed_vehicle_opt_time = time.time() - vehicle_optimization_start
            remaining_vehicle_opt_time = vehicle_opt_time_budget - elapsed_vehicle_opt_time
            
            if remaining_vehicle_opt_time < runtime_limit:
                runtime_limit = remaining_vehicle_opt_time - 5
                print(f"[{filename}] 车辆优化阶段剩余时间不足（剩余 {remaining_vehicle_opt_time:.0f} 秒，需要 {runtime_limit} 秒），停止尝试更小的车辆数")
            
            runtime_limit = min(runtime_limit, remaining_vehicle_opt_time)
            
            print(f"[{filename}] 第 {vehicle_opt_call_count + 1} 次尝试，使用 {runtime_limit:.0f} 秒运行时间（车辆优化阶段剩余时间：{remaining_vehicle_opt_time:.0f} 秒）")
            
            
            vehicle_opt_call_count += 1
            
            solution_result = solve_with_island_model(
                filepath=filepath,
                num_vehicles=num_vehicles_to_try,
                runtime_limit=runtime_limit,
                seed_base=seed_base,
                call_index=vehicle_opt_call_count
            )

            if solution_result and solution_result['is_feasible']:
                print(f"{run_prefix}[{filename}] 岛屿模型成功找到可行解。使用 {solution_result['num_vehicles']} 辆车，总距离: {solution_result['distance']:.2f}")
                
                class MockSolution:
                    def __init__(self, solution_data, scale_factor):
                        self._solution_data = solution_data
                        self._scale_factor = scale_factor
                                                                                                                           
                    def routes(self):
                        mock_routes = []                                              
                        for route_visits in self._solution_data['routes']:                                              
                            mock_route = MockRoute(route_visits)
                            mock_routes.append(mock_route)                       
                        return mock_routes
                    
                    def distance(self):
                        return self._solution_data['distance'] * self._scale_factor
                    
                    def is_feasible(self):
                        return self._solution_data['is_feasible']
                
                class MockRoute:
                    def __init__(self, visits):
                        self._visits = visits
                    
                    def visits(self):
                        return self._visits
                    
                    def delivery(self):
                        total_demand = 0
                        for client_id in self._visits:
                            if client_id > 0:
                                total_demand += DEMANDS[client_id]
                        return [total_demand]
                    
                    def time_warp(self):
                        return 0
                
                best_solution_found = MockSolution(solution_result, scale_factor)
                actual_vehicles_used = len(solution_result['routes'])
                actual_distance = solution_result['distance']

                best_vehicle_phase_call_index = vehicle_opt_call_count
                
                num_vehicles_to_try = actual_vehicles_used - 1
                print(f"{run_prefix}[{filename}] 找到 {actual_vehicles_used} 辆车的可行解，下一轮将尝试 {num_vehicles_to_try} 辆车")
            else:
                print(f"[{filename}] 岛屿模型使用 {num_vehicles_to_try} 辆车未找到可行解。搜索结束。")
                break

        if best_solution_found:
            print(f"{run_prefix}[{filename}] 最终确定最小车辆数为: {len(best_solution_found.routes())}")
            
            print(f"{run_prefix}[{filename}] 进行额外的距离优化...")
            min_vehicles = len(best_solution_found.routes())
            
            elite_solutions = []
            if hasattr(best_solution_found, 'routes'):
                routes_data = []
                for route in best_solution_found.routes():
                    route_visits = list(route.visits())
                    routes_data.append(route_visits)
                
                elite_solution = {
                    'island_id': -1,
                    'cost': best_solution_found.distance() / scale_factor,
                    'solution': {
                        'routes': routes_data,
                        'num_vehicles': min_vehicles
                    }
                }
                elite_solutions.append(elite_solution)
            
            distance_phase_ran = False
            elapsed_total = time.time() - start_time
            remaining_time = total_time_limit - elapsed_total
            distance_opt_runtime = max(60, remaining_time - 10)
            
            print(f"[{filename}] 车辆优化完成，剩余时间 {remaining_time:.0f} 秒，距离优化将使用 {distance_opt_runtime:.0f} 秒")
            
            if distance_opt_runtime <= 10:
                print(f"[{filename}] 剩余时间不足，跳过距离优化阶段")
            else:
                distance_phase_ran = True
                distance_optimized_result = run_distance_optimization_with_islands(
                    filepath=filepath,
                    min_vehicles=min_vehicles,
                    runtime_limit=distance_opt_runtime,
                    seed_base=seed_base + 10000,
                    elite_solutions=elite_solutions
                )


                if distance_optimized_result and distance_optimized_result['is_feasible']:
                    new_actual_distance = distance_optimized_result['distance']
                    previous_actual_distance = best_solution_found.distance() / scale_factor
                    
                    if new_actual_distance < previous_actual_distance:
                        class DistanceOptimizedSolution:
                            def __init__(self, solution_data, scale_factor):
                                self._solution_data = solution_data
                                self._scale_factor = scale_factor
                            
                            def routes(self):
                                mock_routes = []
                                for route_visits in self._solution_data['routes']:
                                    mock_route = MockRoute(route_visits)
                                    mock_routes.append(mock_route)
                                return mock_routes
                            
                            def distance(self):
                                return self._solution_data['distance'] * self._scale_factor
                            
                            def is_feasible(self):
                                return self._solution_data['is_feasible']
                        
                        class MockRoute:
                            def __init__(self, visits):
                                self._visits = visits
                            
                            def visits(self):
                                return self._visits
                            
                            def delivery(self):
                                total_demand = 0
                                for client_id in self._visits:
                                    if client_id > 0:
                                        total_demand += DEMANDS[client_id]
                                return [total_demand]
                            
                            def time_warp(self):
                                return 0
                        
                        best_solution_found = DistanceOptimizedSolution(distance_optimized_result, scale_factor)
                        print(f"[{filename}] 距离优化岛屿模型成功！新的总距离: {new_actual_distance:.2f}")
                    else:
                        print(f"[{filename}] 距离优化岛屿模型没有提高。保持原来的解决方案。")
                else:
                    print(f"[{filename}] 距离优化岛屿模型未找到可行解，保持原来的解决方案。")
            
            try:
                problem_name = os.path.splitext(os.path.basename(filepath))[0]
                
                output_dir = r"C:\Users\yiran\Desktop\TSCHPEA\final\expriement"
                base_name = os.path.splitext(os.path.basename(filepath))[0]

                combined_raw_records = []

                vehicle_total_offset = 0.0
                for call_idx in range(1, vehicle_opt_call_count + 1):
                    vehicle_history_raw = load_all_histories(
                        problem_name=problem_name,
                        phase_name="vehicle_phase",
                        base_dir="results",
                        call_index=call_idx,
                        max_island_id=ISLAND_CONFIG['num_islands']
                    )
                    if not vehicle_history_raw:
                        continue

                    call_max_time = 0.0
                    for record in vehicle_history_raw:
                        if len(record) >= 5:
                            island_id_record, _iter, elapsed_time, num_vehicles, distance = record[0], record[1], record[2], record[3], record[4]
                            elapsed_time = float(elapsed_time)
                            call_max_time = max(call_max_time, elapsed_time)
                            if num_vehicles != float('inf') and distance != float('inf'):
                                combined_raw_records.append((
                                    elapsed_time + vehicle_total_offset,
                                    float(num_vehicles),
                                    float(distance),
                                    int(island_id_record),
                                    f"vehicle_call{call_idx}"
                                ))

                    vehicle_total_offset += call_max_time

                if distance_phase_ran:
                    distance_history_raw = load_all_histories(
                        problem_name=problem_name,
                        phase_name="distance_phase",
                        base_dir="results",
                        max_island_id=ISLAND_CONFIG['num_islands']
                    )
                    if distance_history_raw:
                        for record in distance_history_raw:
                            if len(record) >= 5:
                                island_id_record, _iter, elapsed_time, num_vehicles, distance = record[0], record[1], record[2], record[3], record[4]
                                t = float(elapsed_time) + vehicle_total_offset
                                if num_vehicles != float('inf') and distance != float('inf'):
                                    combined_raw_records.append((t, float(num_vehicles), float(distance), int(island_id_record), "distance"))

                if combined_raw_records:
                    combined_raw_records.sort(key=lambda x: x[0])
                    combined_max_time = combined_raw_records[-1][0]

                    global_best_points = []
                    best_nv = float("inf")
                    best_dist = float("inf")
                    for t, nv, dist, island_id, phase in combined_raw_records:
                        is_better = False
                        if nv < best_nv:
                            is_better = True
                        elif nv == best_nv and dist < best_dist:
                            is_better = True
                        if is_better:
                            global_best_points.append((t, nv, dist, island_id, phase))
                            best_nv = nv
                            best_dist = dist

                    total_csv_path = os.path.join(output_dir, f"{base_name}_vehicle_distance_total_time.csv")
                    try:
                        with open(total_csv_path, "w", newline="", encoding="utf-8") as f_csv:
                            writer = csv.writer(f_csv)
                            writer.writerow(["Time_Seconds", "Num_Vehicles", "Distance", "Island_ID", "Phase"])
                            for t, nv, dist, island_id, phase in global_best_points:
                                writer.writerow([t, int(nv), dist, island_id, phase])
                        print(f"已保存总CSV（仅global_best点）: {total_csv_path}")
                    except Exception as csv_total_err:
                        print(f"保存总CSV时出错（不影响画图）: {csv_total_err}")

                    plot_iteration_history(
                        global_best_points,
                        filepath,
                        output_dir=output_dir,
                        phase_name="总体",
                        max_iteration=combined_max_time,
                        export_csv=False
                    )
            except Exception as plot_total_err:
                print(f"生成总时间图表时出错（不影响主流程）: {plot_total_err}")
            
            is_valid = validate_pyvrp_solution(
                solution=best_solution_found,
                num_all_clients=len(COORDS) - 1,
                vehicle_capacity=VEHICLE_CAPACITY,
                filename=filename,
                scale_factor=scale_factor
            )
            if is_valid:
                routes = best_solution_found.routes()
                all_routes_details = []
                total_euclidean_distance = 0
                total_time = 0
                routes_text = []
                
                for route_idx, route in enumerate(routes):
                    details = calculate_route_details(
                        route, 
                        COORDS, 
                        TIME_WINDOWS,
                        SERVICE_TIMES,
                        scale_factor=scale_factor
                    )
                    total_euclidean_distance += details["distance"]
                    total_time += details["time"]
                    routes_text.append(f"路线{route_idx+1}: {details['route']}")
                    all_routes_details.append({
                        "route_idx": route_idx + 1,
                        "distance": details["distance"],
                        "time": details["time"],
                        "service_time": details["service_time"],
                        "wait_time": details["wait_time"],
                        "route": details["route"]
                    })
                
                algorithm_name = f"混合MAB-Tournament策略(岛屿模型-{ISLAND_CONFIG['num_islands']}岛屿)"
                
                result_dict = {
                    "文件名": filename,
                    "Number of vehicles used": len(best_solution_found.routes()),
                    "Total distance (Euclidean)": f"{total_euclidean_distance:.2f}",
                    "Total time": f"{total_time:.2f}",
                    "Algorithm": algorithm_name
                }
                
                for i, route_detail in enumerate(all_routes_details):
                    result_dict[f"Route_{i+1}"] = route_detail["route"]
                
                return result_dict
            else: 
                return {"文件名": filename, "Number of vehicles used": "Validation Failed",  "Total distance (Euclidean)": "N/A", "Total time": "N/A"}
        else:
            print(f"[{filename}] 即使用初始的 {INITIAL_NUM_VEHICLES} 辆车也未找到任何可行解。")
            return {"文件名": filename, "Number of vehicles used": "No Feasible Solution",  "Total distance (Euclidean)": "N/A", "Total time": "N/A"}
    except Exception as e:
        print(f"处理文件 {filepath} 时发生严重错误: {e}")
        return {"文件名": filename, "Number of vehicles used": "Processing Error", "Total distance (Euclidean)": str(e), "Total time": "N/A"}

def main():
    try:
        start_time = time.time()
        
        print(f"开始执行，每个文件处理时间限制: 30 分钟")

        script_dir = os.path.dirname(os.path.abspath(__file__))
        directories_names = ['htest2']
        directories_paths = [os.path.join(script_dir, name) for name in directories_names]
        
        print(f"使用MAB与锦标赛混合选择策略+岛屿模型({ISLAND_CONFIG['num_islands']}岛屿)运行实验")
        
        all_filepaths = []
        print("正在搜集需要处理的文件...")
        for directory_path in directories_paths:
            if not os.path.isdir(directory_path):
                print(f"警告: 目录 '{directory_path}' 不存在，已跳过。")
                continue
            for filename in os.listdir(directory_path):
                if filename.lower() != "c1_2_1.txt":
                    continue
                if filename.lower().endswith(('.txt', '.vrp')):
                    filepath = os.path.join(directory_path, filename)
                    all_filepaths.append(filepath)

        if not all_filepaths:
            print("未找到任何 .txt 或 .vrp 文件进行处理。")
            return

        all_results = []
        NUM_RUNS_PER_FILE = 1
        
        if all_filepaths:
            print(f"共找到 {len(all_filepaths)} 个文件。每个文件将独立运行 {NUM_RUNS_PER_FILE} 次。")
            for i, filepath in enumerate(all_filepaths):
                filename = os.path.basename(filepath)
                print(f"\n{'='*80}")
                print(f"正在处理第 {i+1}/{len(all_filepaths)} 个文件: {filename}")
                print(f"{'='*80}")
                
                file_time_limit = 30 * 60

                file_results = []
                for run_index in range(1, NUM_RUNS_PER_FILE + 1):
                    print(f"\n--- 文件 {filename} 第 {run_index}/{NUM_RUNS_PER_FILE} 次运行 ---")
                    file_start_time = time.time()
                    
                    run_seed_base = 42 + (i * 100000) + (run_index * 10000)
                    
                    print(f"为文件 {filename} 第 {run_index} 次运行分配时间限制: {file_time_limit/60:.0f} 分钟，随机种子基数: {run_seed_base}")
                    
                    result = process_file(
                        filepath, 
                        start_time=file_start_time, 
                        total_time_limit=file_time_limit,
                        seed_base=run_seed_base,
                        run_index=run_index
                    )
                    
                    if result:
                        result["运行序号"] = run_index
                        result["随机种子基数"] = run_seed_base
                        file_results.append(result)
                        all_results.append(result)
                    
                    run_elapsed_time = time.time() - file_start_time
                    print(f"文件 {filename} 第 {run_index} 次运行完成，用时: {run_elapsed_time/60:.1f} 分钟")
                    
                    gc.collect()
                    if run_index < NUM_RUNS_PER_FILE:
                        time.sleep(2)
                        gc.collect()
                
                if file_results:
                    distances = []
                    for r in file_results:
                        try:
                            dist_str = r.get("Total distance (Euclidean)", "N/A")
                            if dist_str != "N/A" and dist_str not in ["Validation Failed", "No Feasible Solution", "Processing Error"]:
                                distances.append(float(dist_str))
                        except:
                            pass
                    
                    if distances:
                        best_dist = min(distances)
                        worst_dist = max(distances)
                        avg_dist = sum(distances) / len(distances)
                        print(f"\n文件 {filename} 完成 {len(file_results)}/{NUM_RUNS_PER_FILE} 次运行:")
                        print(f"  最佳距离: {best_dist:.2f}")
                        print(f"  最差距离: {worst_dist:.2f}")
                        print(f"  平均距离: {avg_dist:.2f}")
                    else:
                        print(f"\n文件 {filename} 完成 {len(file_results)}/{NUM_RUNS_PER_FILE} 次运行（部分运行未找到可行解）")
                else:
                    print(f"\n文件 {filename} 的 {NUM_RUNS_PER_FILE} 次运行均未找到可行解")
                
                print(f"\n已处理 {i+1}/{len(all_filepaths)} 个文件，累计结果数: {len(all_results)}")

        if all_results:
            df = pd.DataFrame(all_results)
            if "运行序号" in df.columns:
                df = df.sort_values(by=["文件名", "运行序号"]).reset_index(drop=True)
            else:
                df = df.sort_values(by="文件名").reset_index(drop=True)
            
            output_csv_file = os.path.join(script_dir, f"200_{ISLAND_CONFIG['num_islands']}_parallel_{NUM_RUNS_PER_FILE}runs.csv")
            df.to_csv(output_csv_file, index=False)

            print(f"\n\n批量处理完成！结果已保存到 {output_csv_file}")
            display_cols = ["文件名"]
            if "运行序号" in df.columns:
                display_cols.append("运行序号")
            display_cols.append("Total distance (Euclidean)")
            print(df[display_cols])
            
            if (
                "运行序号" in df.columns
                and "Total distance (Euclidean)" in df.columns
                and "Number of vehicles used" in df.columns
            ):
                print(f"\n{'='*80}")
                print("每个文件的最佳结果统计:")
                print(f"{'='*80}")
                for filename in df["文件名"].unique():
                    file_df = df[df["文件名"] == filename]
                    valid_results = []
                    for idx, row in file_df.iterrows():
                        dist_str = row["Total distance (Euclidean)"]
                        try:
                            if dist_str not in ["N/A", "Validation Failed", "No Feasible Solution", "Processing Error"]:
                                dist_val = float(dist_str)
                                veh_val = row.get("Number of vehicles used", "N/A")
                                valid_results.append((dist_val, row["运行序号"], veh_val))
                        except:
                            pass
                    if valid_results:
                        best_result = min(valid_results, key=lambda x: x[0])
                        best_dist, best_run, best_veh = best_result
                        print(f"  {filename}: 最佳距离 {best_dist:.2f}, 最佳车辆数 {best_veh} (第 {best_run} 次运行)")
        else:
            print("\n\n未能处理任何文件，没有生成结果。")
    except Exception as e:
        print(f"主程序发生错误: {e}")
    finally:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f'\n程序总执行时间: {execution_time/60:.1f} 分钟 ({execution_time:.0f} 秒)')
        print('进程已结束, 退出代码0')


if __name__ == "__main__":
    multiprocessing.freeze_support()
    main()
