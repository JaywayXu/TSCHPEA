from __future__ import annotations
from dataclasses import replace
from warnings import warn
import numpy as np
from pyvrp.PenaltyManager import PenaltyManager, PenaltyParams
from pyvrp.exceptions import PenaltyBoundWarning


class HeterogeneousPenaltyManager(PenaltyManager):

    def _compute(
        self,
        penalty: float,
        feas_percentage: float,
    ) -> float:
        p = self._params
        min_feasible = p.target_feasible - p.feas_tolerance
        max_feasible = p.target_feasible + p.feas_tolerance
        if feas_percentage < min_feasible:
            new_penalty = (
                penalty * p.penalty_increase
            )
            if new_penalty >= p.max_penalty:
                warn(
                    "惩罚值已达到上限。",
                    PenaltyBoundWarning,
                )
        elif feas_percentage > max_feasible:
            new_penalty = (
                penalty * p.penalty_decrease
            )
            if new_penalty <= p.min_penalty:
                warn(
                    "惩罚值已达到下限。",
                    PenaltyBoundWarning,
                )
        else:
            return penalty

        return float(np.clip(
            new_penalty,
            p.min_penalty,
            p.max_penalty,
        ))


def make_island_penalty_params(
    island_id: int,
    num_islands: int,
    design_npe: int |None = None,
) -> PenaltyParams:

    if num_islands < 1:
        raise ValueError("num_islands 必须大于等于 1")

    if design_npe is None:
        design_npe = num_islands


    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} 必须等于 "
            f"num_islands={num_islands}"
        )

    if not 0 <= island_id < num_islands:
        raise ValueError(
            f"island_id={island_id} 必须位于 "
            f"[0, {num_islands - 1}]"
        )

    original = PenaltyParams()
    lower_init = (
        original.target_feasible
        - original.feas_tolerance
    )
    upper_init = (
        original.target_feasible
        + original.feas_tolerance
    )

    delta_ro = (
        upper_init - lower_init
    ) / design_npe

    if design_npe == 1:
        position = 0.0
    else:
        position = (
            island_id / (design_npe - 1)
        )

    delta_inc = (
        original.penalty_increase
        - original.penalty_decrease
    ) / design_npe
    delta_dec = (
                        original.penalty_increase
                        - original.penalty_decrease
                ) / design_npe


    ro_adjustment = (
        position * delta_ro
    )
    increase_adjustment = (
        position * delta_inc
    )
    decrease_adjustment = (
        position * delta_dec
    )

    return replace(
        original,
        target_feasible=(
            original.target_feasible
            + ro_adjustment
        ),
        penalty_increase=(
            original.penalty_increase
            + increase_adjustment
        ),
        penalty_decrease=(
            original.penalty_decrease
            + decrease_adjustment
        ),
    )
