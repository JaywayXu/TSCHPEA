import math
from typing import Tuple, Dict, List
from pyvrp._pyvrp import Solution, CostEvaluator, RandomNumberGenerator
from pyvrp.Population import Population
from pyvrp.GeneticAlgorithm import GeneticAlgorithm
import time
from pyvrp.ProgressPrinter import ProgressPrinter
from pyvrp.Result import Result
from pyvrp.Statistics import Statistics
from pyvrp.stop.StoppingCriterion import StoppingCriterion
import multiprocessing as mp
from multiprocessing import Process, Queue, Manager
import queue
import pickle
import threading
import copy

import warnings

warnings.filterwarnings('ignore')


class MABParentSelection:
    def __init__(
            self, num_arms: int = 5, c: float = 1.0, initial_temperature: float = 1.0, cooling_rate: float = 0.9999,
            custom_vehicle_weight: float = 5.0,
            custom_distance_weight: float = 1.0):
        self.num_arms = num_arms
        self.c = c
        self.pulls = {}
        self.rewards = {}
        self.total_pulls = 0
        self.temperature = initial_temperature
        self.cooling_rate = cooling_rate
        self.best_routes_seen = float('inf')
        self.no_improvement_count = 0
        self.custom_vehicle_weight = custom_vehicle_weight
        self.custom_distance_weight = custom_distance_weight

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:

        self.temperature *= self.cooling_rate

        population._update_fitness(cost_evaluator)

        first_parent = self._select_one_parent(population, rng)

        second_parent = first_parent
        max_attempts = 10
        attempt = 0

        while id(second_parent) == id(first_parent) and attempt < max_attempts:
            second_parent = self._select_one_parent(population, rng)
            attempt += 1

        return first_parent, second_parent

    def _select_one_parent(self, population: Population, rng: RandomNumberGenerator) -> Solution:
        pop_size = len(population)
        if pop_size == 0:
            raise ValueError("种群为空，无法选择父代")

        indices = [rng.randint(pop_size) for _ in range(min(self.num_arms, pop_size))]

        best_solution = None
        best_ucb = float('-inf')

        for idx in indices:
            if idx < population.num_feasible():
                solution = population._feas[idx].solution
            else:
                solution = population._infeas[idx - population.num_feasible()].solution

            solution_id = id(solution)

            if solution_id not in self.pulls:
                self.pulls[solution_id] = 0
                self.rewards[solution_id] = 0.0

            if self.pulls[solution_id] == 0:
                ucb = float('inf')
            else:
                exploitation = self.rewards[solution_id] / self.pulls[solution_id]

                effective_c = self.c * self.temperature
                exploration = effective_c * math.sqrt(math.log(self.total_pulls + 1) / self.pulls[solution_id])

                ucb = exploitation + exploration

            if ucb > best_ucb:
                best_ucb = ucb
                best_solution = solution

        if best_solution:
            solution_id = id(best_solution)
            self.pulls[solution_id] += 1
            self.total_pulls += 1

        return best_solution

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        solution_id = id(solution)

        if solution_id not in self.rewards:
            return

        parent_routes = len(solution.routes())
        parent_distance = solution.distance()
        parent_cost = cost_evaluator.penalised_cost(solution)
        parent_feasible = solution.is_feasible()

        offspring_routes = len(offspring.routes())
        offspring_distance = offspring.distance()
        offspring_cost = cost_evaluator.penalised_cost(offspring)
        offspring_feasible = offspring.is_feasible()

        if offspring_feasible and offspring_routes < self.best_routes_seen:
            self.best_routes_seen = offspring_routes
            self.no_improvement_count = 0
        else:
            self.no_improvement_count += 1

        reward = 0.0

        vehicle_weight = self.custom_vehicle_weight
        if self.no_improvement_count > 10000:
            vehicle_weight *= 0.8

        distance_weight = self.custom_distance_weight

        if offspring_routes < parent_routes:
            routes_improvement = (parent_routes - offspring_routes) / parent_routes
            reward += vehicle_weight * (1.0 + routes_improvement * 2)

            if offspring_feasible and offspring_routes == self.best_routes_seen:
                reward += 2.0
        elif offspring_routes == parent_routes:
            if offspring_distance < parent_distance:
                distance_improvement = (parent_distance - offspring_distance) / parent_distance
                if distance_improvement > 0.1:
                    reward += distance_weight * (0.8 + distance_improvement)
                else:
                    reward += distance_weight * (0.5 + distance_improvement)
            else:
                if offspring_cost < parent_cost:
                    cost_improvement = (parent_cost - offspring_cost) / parent_cost
                    reward += 0.2 * cost_improvement
                else:
                    reward += 0.05
        else:
            if offspring_cost < parent_cost:
                cost_improvement = (parent_cost - offspring_cost) / parent_cost
                if cost_improvement > 0.2:
                    reward += 0.15 * cost_improvement
                else:
                    reward += 0.05 * cost_improvement
            else:
                reward += 0.01

        if offspring_feasible and not parent_feasible:
            reward += 1.5
        elif not offspring_feasible and parent_feasible:
            reward -= 1.0

        if offspring_feasible:
            routes_gap = offspring_routes - self.best_routes_seen
            if routes_gap <= 2:
                reward += 0.2 * (3 - routes_gap)

        self.rewards[solution_id] += reward


class TournamentSelection:

    def __init__(self, tournament_size: int = 5):
        self.tournament_size = tournament_size

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:
        population._update_fitness(cost_evaluator)

        pop_size = len(population)
        num_feas = population.num_feasible()
        num_infeas = pop_size - num_feas

        if num_feas == 0:
            first_parent = self._select_one_parent(population, rng)
            second_parent = first_parent
            max_attempts = 10
            attempt = 0
            while id(second_parent) == id(first_parent) and attempt < max_attempts:
                second_parent = self._select_one_parent(population, rng)
                attempt += 1
            return first_parent, second_parent

        if num_feas == 1:
            first_parent = population._feas[0].solution

            if num_infeas > 0:
                num_to_sample_infeas = min(self.tournament_size, num_infeas)
                infeas_competitors = []
                for _ in range(num_to_sample_infeas):
                    idx = rng.randint(num_infeas)
                    solution = population._infeas[idx].solution
                    fitness = population._infeas[idx].fitness
                    infeas_competitors.append((solution, fitness))
                second_parent, _ = min(infeas_competitors, key=lambda x: x[1])
            else:
                second_parent = self._select_one_parent(population, rng)

            return first_parent, second_parent

        first_parent = self._select_one_parent(population, rng)
        second_parent = first_parent
        max_attempts = 10
        attempt = 0
        while id(second_parent) == id(first_parent) and attempt < max_attempts:
            second_parent = self._select_one_parent(population, rng)
            attempt += 1
        return first_parent, second_parent

    def _select_one_parent(self, population: Population, rng: RandomNumberGenerator) -> Solution:
        pop_size = len(population)
        if pop_size == 0:
            raise ValueError("种群为空，无法选择父代")

        num_feas = population.num_feasible()
        num_infeas = pop_size - num_feas
        num_to_sample = min(self.tournament_size, pop_size)

        num_from_feas = min(num_feas, num_to_sample)
        num_from_infeas = num_to_sample - num_from_feas

        competitors = []

        for _ in range(num_from_feas):
            idx = rng.randint(num_feas)
            solution = population._feas[idx].solution
            fitness = population._feas[idx].fitness
            competitors.append((solution, fitness))

        for _ in range(num_from_infeas):
            idx = rng.randint(num_infeas)
            solution = population._infeas[idx].solution
            fitness = population._infeas[idx].fitness
            competitors.append((solution, fitness))

        best_solution, best_fitness = min(competitors, key=lambda x: x[1])
        return best_solution

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        pass


class HybridSelection:

    def __init__(
            self,
            switch_interval: int = 100,
            tournament_size: int = 5,
            mab_num_arms: int = 8,
            mab_c: float = 1.2,
            initial_temperature: float = 1.5,
            cooling_rate: float = 0.9998,
            custom_vehicle_weight: float = 5.0,
            custom_distance_weight: float = 0.0
    ):
        self.mab_selector = MABParentSelection(
            num_arms=mab_num_arms,
            c=mab_c,
            initial_temperature=initial_temperature,
            cooling_rate=cooling_rate,
            custom_vehicle_weight=custom_vehicle_weight,
            custom_distance_weight=custom_distance_weight
        )
        self.tournament_selector = TournamentSelection(tournament_size=tournament_size)

        self.switch_interval = switch_interval
        self.iterations = 0
        self.current_strategy = "mab"

        self.mab_performance = []
        self.tournament_performance = []
        self.strategy_history = []

        self.last_mab_best = None
        self.last_tournament_best = None

        self.current_best_cost = float('inf')
        self.iterations_without_improvement = 0

    def select(self, population: Population, rng: RandomNumberGenerator,
               cost_evaluator: CostEvaluator) -> Tuple[Solution, Solution]:
        self.iterations += 1

        current_best_cost = self._get_best_cost(population, cost_evaluator)

        if current_best_cost < self.current_best_cost:
            self.current_best_cost = current_best_cost
            self.iterations_without_improvement = 0
        else:
            self.iterations_without_improvement += 1

        if self.iterations % self.switch_interval == 0:
            self._evaluate_and_switch_strategy(population, cost_evaluator)

        if self.current_strategy == "mab":
            return self.mab_selector.select(population, rng, cost_evaluator)
        else:
            return self.tournament_selector.select(population, rng, cost_evaluator)

    def _get_best_cost(self, population: Population, cost_evaluator: CostEvaluator) -> float:
        best_cost = float('inf')

        for i in range(population.num_feasible()):
            sol = population._feas[i].solution
            cost = cost_evaluator.cost(sol)
            if cost < best_cost:
                best_cost = cost

        if best_cost == float('inf') and len(population) > 0:
            for i in range(population.num_feasible(), len(population)):
                idx = i - population.num_feasible()
                sol = population._infeas[idx].solution
                cost = cost_evaluator.penalised_cost(sol)
                if cost < best_cost:
                    best_cost = cost

        return best_cost

    def _get_best_solution(self, population: Population, cost_evaluator: CostEvaluator) -> Tuple[Solution, float, int]:
        best_solution = None
        best_cost = float('inf')
        best_routes = float('inf')

        for i in range(population.num_feasible()):
            sol = population._feas[i].solution
            cost = cost_evaluator.cost(sol)
            if cost < best_cost:
                best_cost = cost
                best_solution = sol
                best_routes = len(sol.routes())

        if best_solution is None and len(population) > population.num_feasible():
            for i in range(population.num_feasible(), len(population)):
                idx = i - population.num_feasible()
                sol = population._infeas[idx].solution
                cost = cost_evaluator.penalised_cost(sol)
                if cost < best_cost:
                    best_cost = cost
                    best_solution = sol
                    best_routes = float('inf')

        return best_solution, best_cost, best_routes

    def _evaluate_and_switch_strategy(self, population: Population, cost_evaluator: CostEvaluator):
        best_solution, best_cost, best_routes = self._get_best_solution(population, cost_evaluator)

        if best_solution is None:
            return

        performance = {
            'cost': best_cost,
            'routes': best_routes,
            'iterations_without_improvement': self.iterations_without_improvement
        }

        if self.current_strategy == "mab":
            self.mab_performance.append(performance)
            self.last_mab_best = performance
        else:
            self.tournament_performance.append(performance)
            self.last_tournament_best = performance

        should_switch = False

        if self.last_mab_best and self.last_tournament_best:
            if self.last_mab_best['routes'] < self.last_tournament_best['routes']:
                should_switch = (self.current_strategy != "mab")
            elif self.last_tournament_best['routes'] < self.last_mab_best['routes']:
                should_switch = (self.current_strategy != "tournament")
            else:
                if self.last_mab_best['cost'] < self.last_tournament_best['cost']:
                    should_switch = (self.current_strategy != "mab")
                elif self.last_tournament_best['cost'] < self.last_mab_best['cost']:
                    should_switch = (self.current_strategy != "tournament")
                else:
                    if self.iterations_without_improvement > self.switch_interval // 2:
                        should_switch = True
        else:
            if not self.last_mab_best:
                should_switch = (self.current_strategy != "mab")
            elif not self.last_tournament_best:
                should_switch = (self.current_strategy != "tournament")

        if self.iterations_without_improvement > self.switch_interval * 2:
            should_switch = True

        if should_switch:
            self.current_strategy = "tournament" if self.current_strategy == "mab" else "mab"
            self.iterations_without_improvement = 0

        self.strategy_history.append(self.current_strategy)

    def update_reward(self, solution: Solution, offspring: Solution, cost_evaluator: CostEvaluator):
        if self.current_strategy == "mab":
            self.mab_selector.update_reward(solution, offspring, cost_evaluator)


class MABGeneticAlgorithm(GeneticAlgorithm):

    def __init__(self, *args, hybrid_params=None, **kwargs):
        super().__init__(*args, **kwargs)

        if hybrid_params is None:
            hybrid_params = {}

        self._selector = HybridSelection(
            switch_interval=hybrid_params.get('switch_interval', 100),
            tournament_size=hybrid_params.get('tournament_size', 5),
            mab_num_arms=hybrid_params.get('num_arms', 8),
            mab_c=hybrid_params.get('c', 1.2),
            initial_temperature=hybrid_params.get('initial_temperature', 1.5),
            cooling_rate=hybrid_params.get('cooling_rate', 0.9998),
            custom_vehicle_weight=hybrid_params.get('custom_vehicle_weight', 5.0),
            custom_distance_weight=hybrid_params.get('custom_distance_weight', 0.0)
        )

    def run(
            self,
            stop: StoppingCriterion,
            collect_stats: bool = True,
            display: bool = False,
            display_interval: float = 5.0,
    ):
        try:
            print_progress = ProgressPrinter(display, display_interval)
        except TypeError:
            print_progress = ProgressPrinter(display)

        print_progress.start(self._data)

        start = time.perf_counter()
        stats = Statistics(collect_stats=collect_stats)
        iters = 0
        iters_no_improvement = 1

        for sol in self._initial_solutions:
            self._pop.add(sol, self._cost_evaluator)

        if hasattr(stop, 'set_population_reference'):
            stop.set_population_reference(self._pop, self._cost_evaluator)

        restart_threshold = 20000
        try:
            restart_threshold = getattr(self._params, "num_iters_no_improvement", restart_threshold)
        except (AttributeError, TypeError):
            print("注意：使用默认重启阈值20000")

        while not stop(self._cost_evaluator.cost(self._best)):
            iters += 1

            if iters_no_improvement == restart_threshold:
                print_progress.restart()

                iters_no_improvement = 1
                self._pop.clear()

                for sol in self._initial_solutions:
                    self._pop.add(sol, self._cost_evaluator)

            curr_best = self._cost_evaluator.cost(self._best)

            parents = self._selector.select(self._pop, self._rng, self._cost_evaluator)
            offspring = self._crossover(
                parents, self._data, self._cost_evaluator, self._rng
            )

            self._improve_offspring(offspring)

            for parent in parents:
                self._selector.update_reward(parent, offspring, self._cost_evaluator)

            new_best = self._cost_evaluator.cost(self._best)

            if new_best < curr_best:
                iters_no_improvement = 1
            else:
                iters_no_improvement += 1

            stats.collect_from(self._pop, self._cost_evaluator)
            print_progress.iteration(stats)

        end = time.perf_counter() - start
        res = Result(self._best, stats, iters, end)

        print_progress.end(res)

        return res


from pyvrp.search import (
    NODE_OPERATORS,
    ROUTE_OPERATORS,
    LocalSearch,
    NeighbourhoodParams,
    compute_neighbours,
    SwapStar,
)


class DiverseIntensityLocalSearch:

    def __init__(self, local_search, intensity_config):
        self.local_search = local_search
        self.intensity_factor = intensity_config['factor']
        self.intensity_name = intensity_config['name']
        self.call_count = 0

    def __call__(self, solution, cost_evaluator):
        improved_solution = solution

        if self.intensity_factor <= 0.5:
            import random
            if random.random() > 0.7:
                improved_solution = self.local_search(improved_solution, cost_evaluator)
        elif self.intensity_factor <= 1.0:
            improved_solution = self.local_search(improved_solution, cost_evaluator)
        elif self.intensity_factor <= 2.0:
            for _ in range(int(self.intensity_factor)):
                new_solution = self.local_search(improved_solution, cost_evaluator)
                if cost_evaluator.cost(new_solution) < cost_evaluator.cost(improved_solution):
                    improved_solution = new_solution
                else:
                    break
        else:
            for _ in range(int(self.intensity_factor)):
                improved_solution = self.local_search(improved_solution, cost_evaluator)

        self.call_count += 1
        return improved_solution

    @property
    def node_operators(self):
        return self.local_search.node_operators

    @property
    def route_operators(self):
        return self.local_search.route_operators

    @property
    def neighbours(self):
        return self.local_search.neighbours

    @neighbours.setter
    def neighbours(self, value):
        self.local_search.neighbours = value

    def add_node_operator(self, op):
        return self.local_search.add_node_operator(op)

    def add_route_operator(self, op):
        return self.local_search.add_route_operator(op)

    def __getattr__(self, name):
        return getattr(self.local_search, name)


def create_hybrid_genetic_algorithm(data,
                                    seed=42,
                                    hybrid_params=None,
                                    custom_neighbourhood_params=NeighbourhoodParams(),
                                    custom_swap_star_params=0.05,
                                    island_id=None,
                                    population_size=50,
                                    num_islands=None,
                                    penalty_config=None
                                    ):
    from pyvrp import PopulationParams
    from pyvrp.solve import SolveParams
    from pyvrp.GeneticAlgorithm import GeneticAlgorithmParams
    from heterogeneous_penalty import (
        HeterogeneousPenaltyManager,
        make_island_penalty_params,
    )
    from pyvrp.Population import Population
    from pyvrp._pyvrp import RandomNumberGenerator, Solution
    from pyvrp.diversity import broken_pairs_distance as bpd
    from pyvrp.crossover import selective_route_exchange as srex
    from pyvrp.crossover import ordered_crossover as ox
    from pyvrp.search import SwapStar

    genetic_params = GeneticAlgorithmParams()
    if num_islands is None:
        raise ValueError(
            "使用异构惩罚时必须传入实际的 num_islands"
        )

    if island_id is None:
        raise ValueError(
            "使用异构惩罚时必须传入 island_id"
        )

    if penalty_config is None:
        penalty_config = {
            "design_npe": num_islands,
        }

    design_npe = penalty_config["design_npe"]

    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} 必须等于 "
            f"num_islands={num_islands}"
        )

    penalty_params = make_island_penalty_params(
        island_id=island_id,
        num_islands=num_islands,
        **penalty_config,
    )

    params = SolveParams(
        genetic=genetic_params,
        penalty=penalty_params,
        neighbourhood=custom_neighbourhood_params,
        population=PopulationParams(
            min_pop_size=population_size
        ),
    )

    rng = RandomNumberGenerator(seed=seed)

    if island_id is not None:
        ls = DiverseSearchConfigGenerator.create_diverse_local_search(
            data, rng, island_id,
            num_islands=num_islands,
            population_size=population_size
        )
    else:
        neighbours = compute_neighbours(data, params.neighbourhood)
        ls = LocalSearch(data, rng, neighbours)

        for node_op in NODE_OPERATORS:
            try:
                if hasattr(node_op, 'supports') and node_op.supports(data):
                    ls.add_node_operator(node_op(data))
                else:
                    ls.add_node_operator(node_op(data))
            except Exception as e:
                print(f"添加节点算子 {node_op.__name__} 时出错: {e}")

        for route_op in ROUTE_OPERATORS:
            try:
                if route_op.__name__ == 'SwapStar':
                    swap_star_instance = SwapStar(data, overlap_tolerance=custom_swap_star_params)
                    ls.add_route_operator(swap_star_instance)
                else:
                    if hasattr(route_op, 'supports') and route_op.supports(data):
                        ls.add_route_operator(route_op(data))
                    else:
                        ls.add_route_operator(route_op(data))
            except Exception as e:
                print(f"添加路径算子 {route_op.__name__} 时出错: {e}")

    pm = HeterogeneousPenaltyManager.init_from(
        data,
        params.penalty,
    )
    pop = Population(bpd, params.population)

    if island_id is not None:
        init = DiverseInitialSolutionGenerator.generate_diverse_initial_solutions(
            data, rng, population_size, island_id
        )
    else:
        init = [Solution.make_random(data, rng) for _ in range(population_size)]

    crossover = srex if data.num_vehicles > 1 else ox

    algo = MABGeneticAlgorithm(
        data, pm, rng, pop, ls, crossover, init,
        params=genetic_params, hybrid_params=hybrid_params
    )

    return algo, rng


class IslandGeneticAlgorithm(MABGeneticAlgorithm):

    def __init__(self, *args, island_id=None, global_best=None, global_best_lock=None, is_distance_optimization=False, num_islands=None, runtime_limit=None, **kwargs):
        super().__init__(*args, **kwargs)

        if num_islands is None:
            raise ValueError(
                "必须传入实际的 num_islands"
            )

        self.island_id = island_id
        self.global_best = global_best
        self.global_best_lock = global_best_lock
        self.migration_counter = 0
        self.is_distance_optimization = is_distance_optimization
        self.num_islands = num_islands
        self.stagnation_counter = 0
        self.last_best_cost = float('inf')
        self.successful_migrations = 0

        self.runtime_limit = runtime_limit
        self.start_time = None
        self.iteration_history = []
        self._last_record_nv = None
        self._last_record_dist = None
        self._last_record_elapsed = None
        self.local_best_solution = None


    def run(self, stop, collect_stats=True, display=False, display_interval=5.0):
        try:
            print_progress = ProgressPrinter(display, display_interval)
        except TypeError:
            print_progress = ProgressPrinter(display)

        print_progress.start(self._data)

        start = time.perf_counter()
        self.start_time = start
        stats = Statistics(collect_stats=collect_stats)
        iters = 0
        iters_no_improvement = 1

        for sol in self._initial_solutions:
            self._pop.add(sol, self._cost_evaluator)

        if hasattr(stop, 'set_population_reference'):
            stop.set_population_reference(self._pop, self._cost_evaluator)

        try:
            if self._best is not None and self._best.is_feasible():
                num_vehicles = len(self._best.routes())
                distance = self._best.distance()
                elapsed = time.perf_counter() - self.start_time
                self.iteration_history.append([
                    self.island_id if self.island_id is not None else -1,
                    0,
                    elapsed,
                    num_vehicles,
                    distance
                ])
                self._last_record_nv = num_vehicles
                self._last_record_dist = distance
                self._last_record_elapsed = elapsed
                try:
                    routes_data = []
                    for route in self._best.routes():
                        route_visits = list(route.visits())
                        routes_data.append(route_visits)
                    self.local_best_solution = Solution(self._data, routes_data)
                except Exception:
                    self.local_best_solution = self._best
        except Exception:
            pass

        restart_threshold = 20000
        try:
            restart_threshold = getattr(self._params, "num_iters_no_improvement", restart_threshold)
        except (AttributeError, TypeError):
            pass

        tournament_selector = TournamentSelection(tournament_size=2)

        while not stop(self._cost_evaluator.cost(self._best)):
            iters += 1
            self.migration_counter += 1

            if iters_no_improvement == restart_threshold:
                print_progress.restart()
                iters_no_improvement = 1
                self._pop.clear()
                for sol in self._initial_solutions:
                    self._pop.add(sol, self._cost_evaluator)

            curr_best = self._cost_evaluator.cost(self._best)

            self._update_stagnation_status(curr_best)

            parents = tournament_selector.select(self._pop, self._rng, self._cost_evaluator)
            offspring = self._crossover(
                parents, self._data, self._cost_evaluator, self._rng
            )

            self._improve_offspring(offspring, stop)


            new_best = self._cost_evaluator.cost(self._best)

            has_improvement = new_best < curr_best
            
            if has_improvement:
                iters_no_improvement = 1
            else:
                iters_no_improvement += 1


            try:
                if self._best is not None and self._best.is_feasible():
                    num_vehicles = len(self._best.routes())
                    distance = self._best.distance()
                    elapsed = time.perf_counter() - self.start_time
                    
                    
                    cond_quality_improve = False
                    if self._last_record_nv is None:
                        cond_quality_improve = True
                    else:
                        prev_nv = self._last_record_nv
                        prev_dist = self._last_record_dist
                        if self.is_distance_optimization:
                            if distance < prev_dist:
                                cond_quality_improve = True
                        else:
                            if num_vehicles < prev_nv:
                                cond_quality_improve = True
                    
                    if cond_quality_improve:
                        self.iteration_history.append([
                            self.island_id if self.island_id is not None else -1,
                            iters,
                            elapsed,
                            num_vehicles,
                            distance
                        ])
                    
                    if cond_quality_improve:
                        self._last_record_nv = num_vehicles
                        self._last_record_dist = distance
                        if self._best is not None and self._best.is_feasible():
                            try:
                                routes_data = []
                                for route in self._best.routes():
                                    route_visits = list(route.visits())
                                    routes_data.append(route_visits)
                                self.local_best_solution = Solution(self._data, routes_data)
                            except Exception as e:
                                self.local_best_solution = self._best
            except Exception as e:
                pass


            stats.collect_from(self._pop, self._cost_evaluator)
            print_progress.iteration(stats)

        try:
            if self._best is not None and self._best.is_feasible():
                final_vehicles = len(self._best.routes())
                final_distance = self._best.distance()
                elapsed_final = time.perf_counter() - self.start_time
                
                should_append_final = True
                if self.iteration_history:
                    last_record = self.iteration_history[-1]
                    if len(last_record) >= 5:
                        last_iter = last_record[1]
                        if iters == last_iter:
                            should_append_final = False
                
                if should_append_final:
                    self.iteration_history.append([
                        self.island_id if self.island_id is not None else -1,
                        iters,
                        elapsed_final,
                        final_vehicles,
                        final_distance
                    ])
        except Exception as e:
            pass

        end = time.perf_counter() - start
        res = Result(self._best, stats, iters, end)
        print_progress.end(res)


        return res

    def _normalized_time(self):
        if self.runtime_limit is None or self.start_time is None:
            return 0.0
        elapsed = time.perf_counter() - self.start_time
        return min(1.0, max(0.0, elapsed / self.runtime_limit))

    def _maybe_inject_global_best(self, iters):
        if self.global_best is None or self.global_best_lock is None:
            return

        if iters % 500 != 0:
            return

        local_veh = float("inf")
        local_dist = float("inf")
        if self._best and self._best.is_feasible():
            local_veh = len(self._best.routes())
            local_dist = self._best.distance()

        with self.global_best_lock:
            gb_routes = self.global_best.get("routes", None)
            gb_veh = self.global_best.get("num_vehicles", float("inf"))
            gb_dist = self.global_best.get("distance", float("inf"))
            gb_owner = self.global_best.get("owner_id", -1)

        if gb_routes is None:
            return

        if gb_owner == self.island_id:
            return

        better = False
        if gb_veh < local_veh:
            better = True
        elif gb_veh == local_veh and gb_dist < local_dist:
            better = True

        if not better:
            return

        try:
            migrated_solution = Solution(self._data, gb_routes)
        except Exception as e:
            print(f"[岛屿 {self.island_id}] 重建全局最优解时出错: {e}")
            return

        if not migrated_solution.is_feasible():
            return

        self._pop.add(migrated_solution, self._cost_evaluator)

        if self._best is None or self._cost_evaluator.cost(migrated_solution) < self._cost_evaluator.cost(self._best):
            self._best = migrated_solution
            self.successful_migrations += 1

    def _maybe_update_global_best(self, has_improvement, iters):
        if self.global_best is None or self.global_best_lock is None:
            return
        if not self._best or not self._best.is_feasible():
            return

        if not has_improvement:
            return

        t = self._normalized_time()
        if t < 0.5:
            period = 200
        else:
            period = 500

        if iters % period != 0:
            return

        local_veh = len(self._best.routes())
        local_dist = self._best.distance()

        with self.global_best_lock:
            gb_routes = self.global_best.get("routes", None)
            gb_veh = self.global_best.get("num_vehicles", float("inf"))
            gb_dist = self.global_best.get("distance", float("inf"))

        if gb_routes is None or gb_veh == float("inf"):
            self._write_global_best(local_veh, local_dist)
            return

        if local_veh < gb_veh:
            self._write_global_best(local_veh, local_dist)
            return

        if local_veh == gb_veh and gb_dist > 0 and gb_dist < float("inf"):
            delta = (gb_dist - local_dist) / gb_dist

            cond_early = (t < 0.5 and delta >= 0.05)
            cond_late = (t >= 0.5 and delta >= 0.01)

            if cond_early or cond_late:
                self._write_global_best(local_veh, local_dist)

    def _write_global_best(self, num_vehicles, distance):
        routes_data = []
        for route in self._best.routes():
            routes_data.append(list(route.visits()))

        with self.global_best_lock:
            self.global_best["routes"] = routes_data
            self.global_best["num_vehicles"] = num_vehicles
            self.global_best["distance"] = distance
            self.global_best["owner_id"] = self.island_id
            self.global_best["timestamp"] = time.time()

    def _update_stagnation_status(self, current_cost):
        if current_cost < self.last_best_cost:
            self.stagnation_counter = 0
            self.last_best_cost = current_cost
        else:
            self.stagnation_counter += 1

class IslandWorker:

    @staticmethod
    def run_island(island_id, data_dict, seed_base, hybrid_params, custom_neighbourhood_params,
                   custom_swap_star_params, stop_time, migration_queue, result_queue,
                   migration_interval=50):

        try:
            data = IslandWorker._rebuild_data_from_dict(data_dict)

            island_seed = seed_base + island_id * 1000

            algo, rng = create_island_genetic_algorithm(
                data=data,
                seed=island_seed,
                hybrid_params=hybrid_params,
                custom_neighbourhood_params=custom_neighbourhood_params,
                custom_swap_star_params=custom_swap_star_params,
                island_id=island_id,
                migration_queue=migration_queue
            )

            algo.migration_interval = migration_interval

            print(f"[岛屿 {island_id}] 开始进化，种子: {island_seed}")

            from pyvrp.stop import MaxRuntime
            stop_criteria = MaxRuntime(stop_time)

            res = algo.run(
                stop=stop_criteria,
                collect_stats=False,
                display=False
            )

            if res.best.is_feasible():
                best_cost = res.best.distance()
                final_data = IslandWorker._serialize_solution(res.best)
                result_queue.put((island_id, best_cost, final_data))
                print(f"[岛屿 {island_id}] 完成，最佳成本: {best_cost:.2f}")
            else:
                print(f"[岛屿 {island_id}] 完成，未找到可行解")

        except Exception as e:
            print(f"[岛屿 {island_id}] 错误: {e}")
            import traceback
            traceback.print_exc()

    @staticmethod
    def _serialize_solution(solution):
        try:
            routes_data = []
            for route in solution.routes():
                route_visits = list(route.visits())
                routes_data.append(route_visits)

            solution_data = {
                'routes': routes_data,
                'distance': solution.distance(),
                'is_feasible': solution.is_feasible()
            }
            return solution_data
        except Exception as e:
            print(f"序列化解决方案时出错: {e}")
            return None

    @staticmethod
    def _rebuild_data_from_dict(data_dict):
        try:
            from pyvrp import Model

            m = Model()

            vehicle_info = data_dict['vehicle']
            m.add_vehicle_type(
                vehicle_info['num_vehicles'],
                capacity=vehicle_info['capacity'],
                tw_early=vehicle_info['tw_early'],
                tw_late=vehicle_info['tw_late']
            )

            depot_info = data_dict['depot']
            m.add_depot(
                x=depot_info['x'],
                y=depot_info['y'],
                tw_early=depot_info['tw_early'],
                tw_late=depot_info['tw_late']
            )

            for client_info in data_dict['clients']:
                m.add_client(
                    x=client_info['x'],
                    y=client_info['y'],
                    tw_early=client_info['tw_early'],
                    tw_late=client_info['tw_late'],
                    delivery=client_info['delivery'],
                    service_duration=client_info['service_duration']
                )

            for edge_info in data_dict['edges']:
                frm = m.locations[edge_info['from_idx']]
                to = m.locations[edge_info['to_idx']]
                m.add_edge(frm, to, distance=edge_info['distance'], duration=edge_info['duration'])

            return m.data()

        except Exception as e:
            print(f"重建数据时出错: {e}")
            raise


class IslandModelSolver:

    def __init__(self, num_islands=4, migration_interval=50):
        self.num_islands = num_islands
        self.migration_interval = migration_interval
        self.processes = []
        self.migration_queue = None
        self.result_queue = None

    def solve(self, data, hybrid_params, custom_neighbourhood_params,
              custom_swap_star_params, runtime_limit, seed_base=42):
        print(f"启动岛屿模型并行求解，{self.num_islands}个岛屿")

        self.migration_queue = Queue(maxsize=100)
        self.result_queue = Queue(maxsize=50)

        try:
            data_dict = self._serialize_data(data)

            self.processes = []
            for island_id in range(self.num_islands):
                p = Process(
                    target=IslandWorker.run_island,
                    args=(
                        island_id, data_dict, seed_base, hybrid_params,
                        custom_neighbourhood_params, custom_swap_star_params,
                        runtime_limit, self.migration_queue, self.result_queue,
                        self.migration_interval
                    )
                )
                p.start()
                self.processes.append(p)
                print(f"启动岛屿 {island_id}")

            best_cost = float('inf')
            best_solution_data = None
            best_island = -1

            for p in self.processes:
                p.join()

            results = []
            while not self.result_queue.empty():
                try:
                    result = self.result_queue.get(timeout=1.0)
                    results.append(result)
                except queue.Empty:
                    break

            for island_id, cost, solution_data in results:
                if cost < best_cost:
                    best_cost = cost
                    best_solution_data = solution_data
                    best_island = island_id

            if best_solution_data is not None:
                print(f"岛屿模型求解完成！最优解来自岛屿 {best_island}，成本: {best_cost:.2f}")
                return {
                    'cost': best_cost,
                    'solution_data': best_solution_data,
                    'best_island': best_island,
                    'all_results': results
                }
            else:
                print("岛屿模型求解完成，但未找到可行解")
                return None

        except Exception as e:
            print(f"岛屿模型求解时出错: {e}")
            self._cleanup_processes()
            raise
        finally:
            self._cleanup_processes()

    def _serialize_data(self, data):
        try:

            raise NotImplementedError("需要在调用层面传递构建参数")

        except Exception as e:
            print(f"序列化数据时出错: {e}")
            raise

    def _cleanup_processes(self):
        try:
            for p in self.processes:
                if p.is_alive():
                    p.terminate()
                    p.join(timeout=1.0)
                    if p.is_alive():
                        p.kill()
        except Exception as e:
            print(f"清理进程时出错: {e}")


class DiverseSearchConfigGenerator:

    @staticmethod
    def get_island_search_config(island_id, data=None, num_islands=None, population_size=50):

        if num_islands is None:
            raise ValueError(
                "必须传入实际的 num_islands"
            )

        import math

        if data is not None:
            V = data.num_locations - data.num_depots
            num_depots = int(data.num_depots)
        else:
            V = 1000
            num_depots = 1

        M = V

        N = population_size
        ND = num_islands
        id_val = island_id % ND
        d = id_val + 1

        alpha_min, alpha_max = 2, 3

        log_pop = math.log(N + 1)
        log_nd = math.log(ND + 1)
        sqrt_m_log_ratio = math.sqrt(M * log_pop / log_nd)
        ns_min = math.ceil(alpha_min * sqrt_m_log_ratio)
        ns_max = math.ceil(alpha_max * sqrt_m_log_ratio)
        denom = max(1, ND - 1)
        NSd_cont = ns_min + (d - 1) / denom * (ns_max - ns_min)
        M_id = math.floor(NSd_cont)
        M_id = max(3, min(150, M_id))

        ln_m = math.log(max(2.0, float(M)))
        ln_1_plus_n = math.log(1 + N)
        weight_wait_time = ln_m / ln_1_plus_n * (d / ND)
        warp_num = max(1.0, float(ND - d + 1))
        weight_time_warp = ln_m / ln_1_plus_n * (warp_num / ND)

        weight_wait_time = max(0.001, min(5.0, weight_wait_time))
        weight_time_warp = max(0.01, min(15.0, weight_time_warp))

        operator_strategies = [
            {
                'focus': 'fine_grained_refinement',
                'excluded_node_ops': [
                    'Exchange20','Exchange22',
                    'Exchange30', 'Exchange31', 'Exchange32', 'Exchange33',
                ],
                'excluded_route_ops': [],
                'swap_star_tolerance': 0.6,
                'description': 'Fine grained refinement：Exchange (1,0),(1,1)；Swap* 容忍度 0.6',
            },
        ]

        search_intensity_configs = [
            {'name': 'light', 'factor': 0.5},
            {'name': 'normal', 'factor': 1.0},
            {'name': 'intensive', 'factor': 2.0},
            {'name': 'extreme', 'factor': 3.0},
        ]

        operator_idx = id_val % len(operator_strategies)
        strategy = operator_strategies[operator_idx]
        swap_star_tol = strategy['swap_star_tolerance']
        intensity_idx = id_val % len(search_intensity_configs)

        sym_ex = strategy['focus'] == 'symmetric_exchange'
        symmetric_proximity = sym_ex or (id_val % 3 == 0)
        symmetric_neighbours = sym_ex or (id_val % 2 == 0)

        neighbourhood_config = {
            'weight_wait_time': weight_wait_time,
            'weight_time_warp': weight_time_warp,
            'num_neighbours': M_id,
            'symmetric_proximity': symmetric_proximity,
            'symmetric_neighbours': symmetric_neighbours,
        }

        operator_config = {
            'focus': strategy['focus'],
            'excluded_node_ops': strategy['excluded_node_ops'],
            'excluded_route_ops': strategy['excluded_route_ops'],
            'description': strategy['description'],
        }

        return {
            'neighbourhood_params': NeighbourhoodParams(**neighbourhood_config),
            'operator_config': operator_config,
            'swap_star_tolerance': swap_star_tol,
            'search_intensity': search_intensity_configs[intensity_idx],
            'strategy_description': (
                f"NS_d(M={M_id},NSmin={ns_min},NSmax={ns_max},NSd_cont={NSd_cont:.3f}) "
                f"w_wait={weight_wait_time:.3f} w_warp={weight_time_warp:.3f} "
                f"{strategy['focus']} Swap*={swap_star_tol} 强度{intensity_idx}"
            ),
        }

    @staticmethod
    def create_diverse_local_search(data, rng, island_id, num_islands=None, population_size=50):

        if num_islands is None:
            raise ValueError(
                "必须传入实际的 num_islands"
            )

        search_config = DiverseSearchConfigGenerator.get_island_search_config(
            island_id, 
            data=data, 
            num_islands=num_islands, 
            population_size=population_size
        )

        neighbours = compute_neighbours(data, search_config['neighbourhood_params'])
        ls = LocalSearch(data, rng, neighbours)

        operator_config = search_config['operator_config']
        excluded_ops = set(operator_config['excluded_node_ops'])

        for node_op in NODE_OPERATORS:
            if node_op.__name__ not in excluded_ops:
                try:
                    if hasattr(node_op, 'supports') and node_op.supports(data):
                        ls.add_node_operator(node_op(data))
                    else:
                        ls.add_node_operator(node_op(data))
                except Exception as e:
                    print(f"[岛屿 {island_id}] 添加节点算子 {node_op.__name__} 时出错: {e}")

        excluded_route_ops = set(operator_config.get('excluded_route_ops', []))
        for route_op in ROUTE_OPERATORS:
            if route_op.__name__ in excluded_route_ops:
                continue
            try:
                if route_op.__name__ == 'SwapStar':
                    swap_star = SwapStar(data, overlap_tolerance=search_config['swap_star_tolerance'])
                    ls.add_route_operator(swap_star)
                else:
                    if hasattr(route_op, 'supports') and route_op.supports(data):
                        ls.add_route_operator(route_op(data))
                    else:
                        ls.add_route_operator(route_op(data))
            except Exception as e:
                print(f"[岛屿 {island_id}] 添加路径算子 {route_op.__name__} 时出错: {e}")



        return ls


class DiverseInitialSolutionGenerator:

    @staticmethod
    def construct_routes_from_order(data, rng, ordering, vehicle_capacity, max_routes):
        clients = data.clients()
        dist_matrix = data.distance_matrix(0)
        duration_matrix = data.duration_matrix(0)
        
        unvisited = list(ordering)[:]
        unvisited_set = set(unvisited)
        routes = []
        
        while unvisited_set and len(routes) < max_routes:
            route = []
            current_capacity = vehicle_capacity
            current_time = 0.0
            current_loc = 0
            
            changed = True
            while changed:
                changed = False
                best_client = None
                best_score = float("inf")
                
                for cid in unvisited:
                    if cid not in unvisited_set:
                        continue
                    
                    c = clients[cid - 1]
                    travel_time = duration_matrix[current_loc][cid]
                    arrival_time = current_time + travel_time
                    
                    if arrival_time <= c.tw_late and c.delivery[0] <= current_capacity:
                        score = dist_matrix[current_loc][cid] + rng.rand() * 1e-3
                        
                        if score < best_score:
                            best_score = score
                            best_client = cid
                
                if best_client is None:
                    break
                
                route.append(best_client)
                unvisited_set.remove(best_client)
                unvisited.remove(best_client)
                
                c = clients[best_client - 1]
                travel_time = duration_matrix[current_loc][best_client]
                arrival_time = current_time + travel_time
                
                current_time = max(c.tw_early, arrival_time) + c.service_duration
                current_capacity -= c.delivery[0]
                current_loc = best_client
                changed = True
            
            if route:
                routes.append(route)
            else:
                break
        
        if unvisited and routes:
            for cid in list(unvisited):
                best_route_idx = 0
                best_cost = float("inf")
                
                for i, route in enumerate(routes):
                    if not route:
                        continue
                    
                    tail = route[-1]
                    delta = (
                        dist_matrix[tail][cid]
                        + dist_matrix[cid][0]
                        - dist_matrix[tail][0]
                    )
                    
                    if delta < best_cost:
                        best_cost = delta
                        best_route_idx = i
                
                routes[best_route_idx].append(cid)
            
            unvisited.clear()
        
        if not routes:
            return Solution.make_random(data, rng)
        
        try:
            return Solution(data, routes)
        except RuntimeError:
            return Solution.make_random(data, rng)

    @staticmethod
    def generate_greedy_solution(data, rng, strategy, vehicle_capacity, max_routes):
        clients = data.clients()
        dist_matrix = data.distance_matrix(0)
        duration_matrix = data.duration_matrix(0)
        
        unvisited = set(range(1, len(clients) + 1))
        routes = []
        
        while unvisited and len(routes) < max_routes:
            route = []
            current_capacity = vehicle_capacity
            current_time = 0.0
            current_loc = 0
            
            while True:
                best_client = None
                best_score = float("inf")
                
                for idx in unvisited:
                    client = clients[idx - 1]
                    travel_time = duration_matrix[current_loc][idx]
                    arrival_time = current_time + travel_time
                    
                    if arrival_time <= client.tw_late and client.delivery[0] <= current_capacity:
                        if strategy == "nearest":
                            base_score = dist_matrix[current_loc][idx]
                        elif strategy == "earliest_due":
                            base_score = client.tw_late
                        elif strategy == "largest_demand":
                            base_score = -client.delivery[0]
                        else:
                            urgency = max(1.0, client.tw_late - arrival_time)
                            base_score = -dist_matrix[current_loc][idx] / urgency
                        
                        score = base_score
                        
                        if score < best_score:
                            best_score = score
                            best_client = idx
                
                if best_client is None:
                    break
                
                route.append(best_client)
                unvisited.remove(best_client)
                
                client = clients[best_client - 1]
                travel_time = duration_matrix[current_loc][best_client]
                arrival_time = current_time + travel_time
                current_time = max(client.tw_early, arrival_time) + client.service_duration
                current_capacity -= client.delivery[0]
                current_loc = best_client
            
            if route:
                routes.append(route)
            else:
                break
        
        if unvisited and routes:
            for client_idx in list(unvisited):
                best_route_idx = 0
                best_cost = float("inf")
                
                for i, route in enumerate(routes):
                    if not route:
                        continue
                    
                    tail = route[-1]
                    insert_cost = (
                        dist_matrix[tail][client_idx]
                        + dist_matrix[client_idx][0]
                        - dist_matrix[tail][0]
                    )
                    
                    if insert_cost < best_cost:
                        best_cost = insert_cost
                        best_route_idx = i
                
                routes[best_route_idx].append(client_idx)
                unvisited.remove(client_idx)
        
        try:
            return Solution(data, routes)
        except RuntimeError:
            return Solution.make_random(data, rng)

    @staticmethod
    def build_random_order(data, rng):
        clients = list(range(1, len(data.clients()) + 1))
        temp_list = clients[:]
        for i in range(len(temp_list) - 1, 0, -1):
            j = rng.randint(i + 1)
            temp_list[i], temp_list[j] = temp_list[j], temp_list[i]
        return temp_list
    
    @staticmethod
    def build_sweep_order(data, rng):
        clients = list(range(data.num_depots, data.num_locations))
        if not clients:
            return []
        
        depot = data.location(0)
        angles = []
        
        for cid in clients:
            loc = data.location(cid)
            angle = math.atan2(loc.y - depot.y, loc.x - depot.x)
            angles.append((angle, cid))
        
        angles.sort()
        start_idx = rng.randint(len(angles))
        ordered = [angles[(start_idx + i) % len(angles)][1] for i in range(len(angles))]
        
        return ordered
    
    @staticmethod
    def build_cluster_order(data, rng):
        clients = list(range(1, len(data.clients()) + 1))
        if not clients:
            return []
        
        num_clusters = min(data.num_vehicles, len(clients))
        if len(clients) >= num_clusters:
            centers = []
            available = clients[:]
            for _ in range(num_clusters):
                idx = rng.randint(len(available))
                centers.append(available.pop(idx))
        else:
            centers = clients[:]
        
        clusters = [[] for _ in range(num_clusters)]
        for cid in clients:
            loc = data.location(cid)
            best_c = 0
            best_dist = float("inf")
            for i, center in enumerate(centers):
                cent_loc = data.location(center)
                dist = ((loc.x - cent_loc.x) ** 2 + (loc.y - cent_loc.y) ** 2) ** 0.5
                if dist < best_dist:
                    best_dist = dist
                    best_c = i
            clusters[best_c].append(cid)
        
        ordering = []
        for cluster in clusters:
            if not cluster:
                continue
            for i in range(len(cluster) - 1, 0, -1):
                j = rng.randint(i + 1)
                cluster[i], cluster[j] = cluster[j], cluster[i]
            ordering.extend(cluster)
        
        return ordering

    @staticmethod
    def generate_random_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            ordering = DiverseInitialSolutionGenerator.build_random_order(data, rng)
            return DiverseInitialSolutionGenerator.construct_routes_from_order(
                data, rng, ordering, vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)

    @staticmethod
    def generate_nearest_neighbor_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            return DiverseInitialSolutionGenerator.generate_greedy_solution(
                data, rng, "nearest", vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_earliest_due_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            return DiverseInitialSolutionGenerator.generate_greedy_solution(
                data, rng, "earliest_due", vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_largest_demand_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            return DiverseInitialSolutionGenerator.generate_greedy_solution(
                data, rng, "largest_demand", vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_distance_urgency_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            return DiverseInitialSolutionGenerator.generate_greedy_solution(
                data, rng, "distance_urgency", vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_sweep_init_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            ordering = DiverseInitialSolutionGenerator.build_sweep_order(data, rng)
            return DiverseInitialSolutionGenerator.construct_routes_from_order(
                data, rng, ordering, vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_cluster_init_solution(data, rng):
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
            ordering = DiverseInitialSolutionGenerator.build_cluster_order(data, rng)
            return DiverseInitialSolutionGenerator.construct_routes_from_order(
                data, rng, ordering, vehicle_capacity, max_routes
            )
        except Exception:
            return Solution.make_random(data, rng)
    
    @staticmethod
    def generate_sweep_solution(data, rng):
        return DiverseInitialSolutionGenerator.generate_sweep_init_solution(data, rng)
    
    @staticmethod
    def generate_clustered_solution(data, rng):
        return DiverseInitialSolutionGenerator.generate_cluster_init_solution(data, rng)

    @staticmethod
    def generate_diverse_initial_solutions(data, rng, population_size, island_id=None):
        solutions = []
        
        strategies = [
            "nearest",
            "earliest_due",
            "largest_demand",
            "distance_urgency",
            "random",
            "sweep",
            "cluster",
        ]
        
        try:
            vehicle_capacity = data.vehicle_type(0).capacity
            max_routes = data.num_vehicles
        except Exception:
            vehicle_capacity = 1000.0
            max_routes = data.num_vehicles
        
        for i in range(population_size):
            try:
                if island_id is not None:
                    strategy_idx = (island_id * 7 + i) % len(strategies)
                else:
                    strategy_idx = i % len(strategies)
                
                strategy = strategies[strategy_idx]
                
                if strategy in ("nearest", "earliest_due", "largest_demand", "distance_urgency"):
                    sol = DiverseInitialSolutionGenerator.generate_greedy_solution(
                        data, rng, strategy, vehicle_capacity, max_routes
                    )
                elif strategy == "random":
                    sol = DiverseInitialSolutionGenerator.generate_random_solution(data, rng)
                elif strategy == "sweep":
                    sol = DiverseInitialSolutionGenerator.generate_sweep_init_solution(data, rng)
                elif strategy == "cluster":
                    sol = DiverseInitialSolutionGenerator.generate_cluster_init_solution(data, rng)
                else:
                    sol = Solution.make_random(data, rng)
                
                solutions.append(sol)
            except Exception as e:
                solutions.append(Solution.make_random(data, rng))

        return solutions

    @staticmethod
    def _get_method_weights_for_island(island_id):
        weight_patterns = [
            [0.7, 0.1, 0.1, 0.05, 0.03, 0.02],
            [0.3, 0.4, 0.1, 0.1, 0.05, 0.05],
            [0.2, 0.1, 0.5, 0.1, 0.05, 0.05],
            [0.2, 0.1, 0.1, 0.4, 0.1, 0.1],
            [0.2, 0.1, 0.1, 0.1, 0.4, 0.1],
            [0.2, 0.1, 0.1, 0.1, 0.1, 0.4],
            [0.3, 0.2, 0.2, 0.1, 0.1, 0.1],
            [0.15, 0.15, 0.15, 0.15, 0.2, 0.2],
            [0.4, 0.15, 0.15, 0.1, 0.1, 0.1],
            [0.1, 0.3, 0.3, 0.1, 0.1, 0.1],
        ]

        pattern_idx = island_id % len(weight_patterns)
        return weight_patterns[pattern_idx]

    @staticmethod
    def _weighted_choice(weights, rng):
        total = sum(weights)
        r = rng.rand() * total

        cumulative = 0
        for i, weight in enumerate(weights):
            cumulative += weight
            if r <= cumulative:
                return i

        return len(weights) - 1


def create_island_genetic_algorithm(data,
                                    seed=42,
                                    hybrid_params=None,
                                    custom_neighbourhood_params=None,
                                    custom_swap_star_params=0.05,
                                    island_id=None,
                                    global_best=None,
                                    global_best_lock=None,
                                    is_distance_optimization=False,
                                    num_islands=None,
                                    population_size=50,
                                    runtime_limit=None,
                                    penalty_config=None
                                    ):
    from pyvrp import PopulationParams
    from pyvrp.solve import SolveParams
    from pyvrp.GeneticAlgorithm import GeneticAlgorithmParams
    from heterogeneous_penalty import (
        HeterogeneousPenaltyManager,
        make_island_penalty_params,
    )
    from pyvrp.Population import Population
    from pyvrp._pyvrp import RandomNumberGenerator, Solution
    from pyvrp.diversity import broken_pairs_distance as bpd
    from pyvrp.crossover import selective_route_exchange as srex
    from pyvrp.crossover import ordered_crossover as ox
    from pyvrp.search import SwapStar
    from pyvrp.search import NeighbourhoodParams

    genetic_params = GeneticAlgorithmParams()

    if num_islands is None:
        raise ValueError(
            "必须传入实际的 num_islands"
        )

    if penalty_config is None:
        penalty_config = {
            'design_npe': num_islands,
        }

    design_npe = penalty_config['design_npe']

    if design_npe != num_islands:
        raise ValueError(
            f"design_npe={design_npe} 必须等于 "
            f"num_islands={num_islands}"
        )

    penalty_params = make_island_penalty_params(
        island_id=island_id,
        num_islands=num_islands,
        **penalty_config,
    )

    current_min_feasible = (
            penalty_params.target_feasible
            - penalty_params.feas_tolerance
    )
    current_max_feasible = (
            penalty_params.target_feasible
            + penalty_params.feas_tolerance
    )

    phase_name = (
        "距离优化"
        if is_distance_optimization
        else "车辆优化"
    )

    print(
        f"[{phase_name}][岛屿 {island_id}] "
        f"num_islands={num_islands}, "
        f"design_npe={design_npe}, "
        f"可行率区间="
        f"[{current_min_feasible:.10f}, "
        f"{current_max_feasible:.10f}], "
        f"penalty_increase="
        f"{penalty_params.penalty_increase:.10f}, "
        f"penalty_decrease="
        f"{penalty_params.penalty_decrease:.10f}",
        flush=True,
    )

    params = SolveParams(
        genetic=genetic_params,
        penalty=penalty_params,
        neighbourhood=custom_neighbourhood_params or NeighbourhoodParams(),
        population=PopulationParams(min_pop_size=population_size),
    )

    rng = RandomNumberGenerator(seed=seed)
    from pyvrp.search import compute_neighbours, LocalSearch, NODE_OPERATORS, ROUTE_OPERATORS

    if island_id is not None:
        ls = DiverseSearchConfigGenerator.create_diverse_local_search(
            data, rng, island_id, 
            num_islands=num_islands, 
            population_size=population_size
        )
    else:
        neighbours = compute_neighbours(data, params.neighbourhood)
        ls = LocalSearch(data, rng, neighbours)

        for node_op in NODE_OPERATORS:
            try:
                if hasattr(node_op, 'supports') and node_op.supports(data):
                    ls.add_node_operator(node_op(data))
                else:
                    ls.add_node_operator(node_op(data))
            except Exception as e:
                print(f"添加节点算子 {node_op.__name__} 时出错: {e}")

        for route_op in ROUTE_OPERATORS:
            try:
                if route_op.__name__ == 'SwapStar':
                    swap_star_instance = SwapStar(data, overlap_tolerance=custom_swap_star_params)
                    ls.add_route_operator(swap_star_instance)
                else:
                    if hasattr(route_op, 'supports') and route_op.supports(data):
                        ls.add_route_operator(route_op(data))
                    else:
                        ls.add_route_operator(route_op(data))
            except Exception as e:
                print(f"添加路径算子 {route_op.__name__} 时出错: {e}")

    pm = HeterogeneousPenaltyManager.init_from(data, params.penalty)
    pop = Population(bpd, params.population)

    init = DiverseInitialSolutionGenerator.generate_diverse_initial_solutions(
        data, rng, population_size, island_id
    )

    crossover = srex if data.num_vehicles > 1 else ox

    algo = IslandGeneticAlgorithm(
        data, pm, rng, pop, ls, crossover, init,
        params=genetic_params,
        hybrid_params=hybrid_params,
        island_id=island_id,
        global_best=global_best,
        global_best_lock=global_best_lock,
        is_distance_optimization=is_distance_optimization,
        num_islands=num_islands,
        runtime_limit=runtime_limit
    )

    return algo, rng


def create_island_model_solver(num_islands=4, migration_interval=50):
    return IslandModelSolver(num_islands=num_islands, migration_interval=migration_interval)
